﻿using Mindflur.IMS.Runners;
using Mindflur.IMS.Runners.Audit;
using Mindflur.IMS.Runners.Review;
using Mindflur.IMS.Runners.WorkItem;
using System.Diagnostics.CodeAnalysis;

namespace Mindflur.IMS.API.Core.Runner
{
    [ExcludeFromCodeCoverage]
    public static class RunnerApplicationServiceRegistration
    {
        public static IServiceCollection AddRunnerApplicationServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<IWorkItemSchedule, ProcessWorkItemSchedule>();
            services.AddScoped<IAuditSchedule, ProcessAuditSchedule>();
            services.AddScoped<IReminders, Reminder>();
            services.AddScoped<IManagementReviewSchedule, ProcessManagementReviewSchedule>();
            return services;
        }
    }
}
