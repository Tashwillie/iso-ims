﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Authentication;
using System.Security.Claims;

namespace Mindflur.IMS.API.Core
{
    [TenantAuthorization]
    [ApiController]
    public class BaseController : ControllerBase
    {
        protected int UserId => User.FindFirstValue("userId") != null ? int.Parse(User.FindFirstValue("userId")) : 00000;

        protected string UserEmail => User.FindFirstValue(ClaimTypes.Email);
        protected string Username => User.FindFirstValue("preferred_username");
        protected int TenantId => int.Parse(User.FindFirstValue("azp"));
    }
}