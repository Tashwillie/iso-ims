﻿namespace Mindflur.IMS.API.Core.CustomException
{
    /// <summary>
    /// Exception type for app exceptions
    /// </summary>
    public class IMSDomainException : Exception
    {
        public IMSDomainException()
        { }

        public IMSDomainException(string message)
            : base(message)
        { }

        public IMSDomainException(string message, Exception innerException)
            : base(message, innerException)
        { }
    }
}