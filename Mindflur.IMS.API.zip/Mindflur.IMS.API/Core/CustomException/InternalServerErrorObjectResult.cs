﻿using Microsoft.AspNetCore.Mvc;

namespace Mindflur.IMS.API.Core.CustomException
{
    public class InternalServerErrorObjectResult : ObjectResult
    {
        public InternalServerErrorObjectResult(object error)
            : base(error)
        {
            StatusCode = StatusCodes.Status500InternalServerError;
        }
    }
}