﻿using Azure.Messaging.ServiceBus;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Options;
using Mindflur.IMS.API.Notification;
using Mindflur.IMS.Application.Contracts.Service;
using Mindflur.IMS.Application.Core;
using Mindflur.IMS.Application.ViewModel.Core;
using System.Text.Json;

namespace Mindflur.IMS.API
{
    public class IMSBackgroundService : IHostedService
    {
        private readonly ILogger<IMSBackgroundService> _logger;

        private readonly IOptions<CoreSettings> _coreSettings;

        private readonly IHubContext<NotificationsHub> _hubContext;

        private readonly ICacheService _cacheService;

        // the client that owns the connection and can be used to create senders and receivers
        private ServiceBusClient _client;

        // the processor that reads and processes messages from the queue
        private ServiceBusProcessor _processor;

        public IMSBackgroundService(ILogger<IMSBackgroundService> logger, IOptions<CoreSettings> coreSettings, IHubContext<NotificationsHub> hubContext, ICacheService cacheService)
        {
            _logger = logger;
            _coreSettings = coreSettings;
            _hubContext = hubContext;
            _cacheService = cacheService;
        }

        public async Task StartAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("IMS Background Service running.");

            var clientOptions = new ServiceBusClientOptions()
            {
                TransportType = ServiceBusTransportType.AmqpWebSockets
            };
            _client = new ServiceBusClient(_coreSettings.Value.SBConnectionString, clientOptions);

            // create a processor that we can use to process the messages
            _processor = _client.CreateProcessor(_coreSettings.Value.NotificationMessageQueueName, new ServiceBusProcessorOptions());

            try
            {
                // add handler to process messages
                _processor.ProcessMessageAsync += MessageHandler;

                // add handler to process any errors
                _processor.ProcessErrorAsync += ErrorHandler;

                // start processing 
                await _processor.StartProcessingAsync();

                _logger.LogInformation("\n Started the receiver...");

                if (stoppingToken.IsCancellationRequested)
                {
                    // stop processing 
                    _logger.LogInformation("\nStopping the receiver...");
                    await _processor.StopProcessingAsync();
                    _logger.LogInformation("Stopped receiving messages");
                }
            }
            catch (Exception ex)
            {
                _logger.LogCritical($"Message listner for queue {_coreSettings.Value.NotificationMessageQueueName} has been failed.", ex);
            }
        }

        // handle received messages
        async Task MessageHandler(ProcessMessageEventArgs args)
        {
            string body = args.Message.Body.ToString();
            string cacheKey = string.Empty;

            _logger.LogInformation($"Notification received => {body}");

            var notificationMessage = JsonSerializer.Deserialize<NotificationMessage>(body)!;

            //should be refreshed only for a tenant
            if (notificationMessage.EventType == NotificationEventType.TenantMaster)
                cacheKey = $"{notificationMessage.Module}-{notificationMessage.TenantId}";

            //should be refreshed for all tenants 
            if (notificationMessage.EventType == NotificationEventType.GlobalMaster)
                cacheKey = $"{notificationMessage.Module}";

            if (!string.IsNullOrWhiteSpace(cacheKey)) 
            {
                _logger.LogInformation($"Purge cache for key {cacheKey}");
                _cacheService.Remove(cacheKey);
            }

            if (notificationMessage.BroadcastLevel != NotificationBroadcastLevel.None) //SignalR notification should not be sent if its none
            {
                await _hubContext.Clients
                      .Group(notificationMessage.SourceIdUserId.ToString())
                      .SendAsync("Notify", notificationMessage);
            }
            // complete the message. message is deleted from the queue. 
            await args.CompleteMessageAsync(args.Message);
        }

        // handle any errors when receiving messages
        Task ErrorHandler(ProcessErrorEventArgs args)
        {
            _logger.LogError("Message error " + args.Exception.ToString());

            return Task.CompletedTask;
        }

        public async Task StopAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("IMS Background Service is stopping.");

            await _processor.DisposeAsync();

            await _client.DisposeAsync();
        }
    }
}
