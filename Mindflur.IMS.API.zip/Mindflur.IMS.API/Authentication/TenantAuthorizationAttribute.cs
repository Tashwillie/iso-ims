﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Mindflur.IMS.API.Authentication
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class TenantAuthorizationAttribute : AuthorizeAttribute, IAuthorizationFilter
    {
        public void OnAuthorization(AuthorizationFilterContext context)
        {
            //ToDo: If current user has a 'super-admin-role' then validation should not restrict to manage things outside of tenant context

            var clientRoleResourceAccess = context.HttpContext.User.Claims.FirstOrDefault(c => c.Type == "resource_access");

            if (clientRoleResourceAccess == null)
            {
                context.Result = new UnauthorizedResult();
            }
            else
            {
                if (clientRoleResourceAccess.Value.Contains("super-admin-role"))
                    return;

                if (context.RouteData.Values["tenantId"] == null) //Hack: Almost all the routes must have tenantId. Remove this line of code in future.
                    return;

                var tenantId = context.RouteData.Values?["tenantId"].ToString();

                var isUserAuthorized = context.HttpContext.User.Claims.Any(c => c.Type == "azp" && c.Value == tenantId);

                if (!isUserAuthorized)
                {
                    context.Result = new UnauthorizedResult();
                }
            }
        }
    }
}