﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Mindflur.IMS.Application.Contracts.Business;
using System.Security.Cryptography;

namespace Mindflur.IMS.API.Authentication
{
    public static class ConfigureAuthenticationServiceExtensions
    {
        private static RsaSecurityKey BuildRSAKey(string publicKeyJWT)
        {
            RSA rsa = RSA.Create();

            rsa.ImportSubjectPublicKeyInfo(

                source: Convert.FromBase64String(publicKeyJWT),
                bytesRead: out _
            );

            var IssuerSigningKey = new RsaSecurityKey(rsa);

            return IssuerSigningKey;
        }

        public static void ConfigureJWT(this IServiceCollection services, IConfiguration configuration)
        {

            var tenantMasterBusiness = services.BuildServiceProvider().GetService<ITenantMasterBusiness>();

            var tenants = tenantMasterBusiness.GetTenantsMaster().Result;

            services.AddTransient<IClaimsTransformation, ClaimsTransformer>();

            var AuthenticationBuilder = services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
            });

            IList<string> validIssuers = new List<string>();
            foreach (var tenant in tenants)
            {
                validIssuers.Add($"{configuration["CoreSettings:IdentityConfiguration:Endpoint"]}/realms/{tenant.TenantId}");
            }

            AuthenticationBuilder.AddJwtBearer(o =>
            {
                o.Audience = configuration["CoreSettings:IdentityConfiguration:Audience"];
                o.Events = new JwtBearerEvents
                {
                    OnMessageReceived = context =>
                    {
                        var accessToken = context.Request.Query["access_token"];

                        var path = context.HttpContext.Request.Path;
                        if (!string.IsNullOrEmpty(accessToken) && path.StartsWithSegments("/hub/notificationhub"))
                        {
                            context.Token = accessToken;
                        }
                        return Task.CompletedTask;
                    }
                };
                o.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidateIssuer = false, //Hack: We should not skip issuer validation, But at this moment, not sure how to add issuer at runtime, so that any new tenant registration would work.
                    ValidIssuers = validIssuers,
                    IssuerSigningKeyResolver = (string token, SecurityToken securityToken, string kid, TokenValidationParameters validationParameters) =>
                    {
                        var tenant = tenants.Where(t => t.Kid == kid).FirstOrDefault();//ToDo: Get tenant implementation must have a cache to always populate the tenants. (Avoid database calls at runtime.)
                        List<SecurityKey> keys = new List<SecurityKey>();
                        if (tenant != null)
                        {
                            var signingKey = BuildRSAKey(tenant.RSAPublicKey);
                            keys.Add(signingKey);
                        }
                        return keys;
                    },
                    //IssuerSigningKey = BuildRSAKey(configuration["CoreSettings:IdentityConfiguration:PublicKeyJWT"]),
                    //https://www.carlrippon.com/asp-net-core-web-api-multi-tenant-jwts/ (validate implementation for multiple-tenant)
                };
                o.SaveToken = true;
                o.RequireHttpsMetadata = true;
            });
        }
    }
}