﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.ViewModel.Core;
using Mindflur.IMS.Application.ViewModel.View;
using Mindflur.IMS.Business;
using System.Net;

namespace Mindflur.IMS.API.Controllers
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/document-change")]
    [ApiController]
    public class DocumentChangeRequestController : BaseController
    {
        private readonly IDocumentChangeRequestBusiness _documentChangeRequestBusiness;

        public DocumentChangeRequestController(IDocumentChangeRequestBusiness documentChangeRequestBusiness)
        {
            _documentChangeRequestBusiness = documentChangeRequestBusiness;
        }

        [HttpGet]
        [Route("list")]
        [ProducesResponseType(typeof(PaginatedItems<DocumentGridView>), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]

        public async Task<IActionResult> GetDocumentChangeRequestList([FromRoute] int tenantId,  [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, int statusId = 0)
        {
            var request = new GetDocumentChangeRequest()
            {
                ListRequests = new GetListRequest()
                {
                    Sort = sort,
                    SortColumn = sortColumn,
                    PerPage = perPage,
                    Page = page
                },
                TenantId = tenantId,
                StatusId = statusId

            };
            var document = await _documentChangeRequestBusiness.GetAllDocumentList(request);
            return Ok(document);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromRoute] int tenantId, [FromBody] PostDocumetChangeRequestView postDocumetChangeRequestView)
        {
            await _documentChangeRequestBusiness.AddDcoumentRequest(postDocumetChangeRequestView, tenantId, UserId);
            return NoContent();
        }

        [HttpGet("{ChangeRequestId}")]
        public async Task<IActionResult> GetDocumentRequestDetails([FromRoute] int tenantId, int ChangeRequestId)
        {

            var rawData = await _documentChangeRequestBusiness.GetDocumentRequestDetails(ChangeRequestId, tenantId);

            return Ok(rawData);
        }

        [HttpPut("{ChangeRequestId}")]

        public async Task<IActionResult> Put([FromRoute] int tenantId, [FromRoute] int ChangeRequestId, [FromBody] PutDocumentChangeRequestView putDocumentChangeRequestView)
        {

            await _documentChangeRequestBusiness.UpdateDocumentRequest(putDocumentChangeRequestView, ChangeRequestId, tenantId,UserId);
            return NoContent();
        }

        [HttpDelete("{ChangeRequestId}")]
        public async Task<IActionResult> Delete([FromRoute] int tenantId, [FromRoute] int ChangeRequestId)
        {
            await _documentChangeRequestBusiness.DeleteDocumentRequest(ChangeRequestId, tenantId);
            return NoContent();
        }
        [HttpPut("{ChangeRequestId}/approve")]
        public async Task<IActionResult> Approve([FromRoute] int ChangeRequestId, [FromRoute] int tenantId, CommentsForDocument document)
        {
            await _documentChangeRequestBusiness.ApproveDocument(ChangeRequestId, UserId, tenantId, document);
            return NoContent();
        }
        [HttpPut("{ChangeRequestId}/reject")]
        public async Task<IActionResult> Rejected([FromRoute] int ChangeRequestId, [FromRoute] int tenantId, CommentsForDocument document)
        {
            await _documentChangeRequestBusiness.RejectDocument(ChangeRequestId, UserId, tenantId, document);
            return NoContent();
        }
    }
}
