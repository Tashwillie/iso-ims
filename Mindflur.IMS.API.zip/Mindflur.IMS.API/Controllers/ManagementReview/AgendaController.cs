﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Data.Models;

namespace Mindflur.IMS.API.Controllers.ManagementReview
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/agenda")]
    [ApiController]
    public class AgendaController : BaseController
    {
        private readonly IManagementReviewBusiness _managementReviewBusiness;

        public AgendaController(IManagementReviewBusiness managementReviewBusiness)
        {
            _managementReviewBusiness = managementReviewBusiness;
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromRoute] int tenantId, [FromBody] PostAgendaView postAgendaView)
        {
            await _managementReviewBusiness.AddAgendas(postAgendaView, UserId, tenantId);
            return Ok();
        }

        [HttpPut("{Id}")]
        public async Task<IActionResult> Put([FromRoute] int tenantId, int Id, [FromBody] PutAgendaView agenda)
        {
            await _managementReviewBusiness.UpdateAgendasById(Id, agenda, UserId, tenantId);
            return NoContent();
        }

        [HttpDelete("{Id}")]
        public async Task<IActionResult> Delete(int Id)
        {
            await _managementReviewBusiness.DeleteAgenda(Id);
            return Ok(string.Format(ControllerConstants.RecordDeletedMessage));
        }

        [HttpGet("Preview/{Id}")]
        public async Task<IActionResult> Preview(int Id)
        {
            var rawData = await _managementReviewBusiness.PreviewAgendas(Id);
            return rawData != null ? Ok(rawData) : BadRequest();
        }
    }
}