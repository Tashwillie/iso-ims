﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Application.ViewModel.View;

namespace Mindflur.IMS.API.Controllers.ManagementReview
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/minutes")]
    [ApiController]
    public class MinutesOfMeetingController : BaseController
    {
        private readonly IMinutesBusiness _minutes;
        private readonly IChartBusiness _chartBusiness;
       
        public MinutesOfMeetingController(IMinutesBusiness minutes, IChartBusiness chartBusiness)
        {
            _minutes = minutes;
            _chartBusiness = chartBusiness;
           
        }

        [HttpGet("donut")]
        public async Task<IActionResult> GetTaskMasterDonutChart([FromRoute] int tenantId, int category = 1)
        {
            if (category >= 1 && category < 6)
            {
                var rawData = await _chartBusiness.GetChartTaskMasterDonuts(category, tenantId);
                return Ok(rawData);
            }
            else
            {
                return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
            }
        }

        [HttpGet]
        public async Task<IActionResult> Minutes([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, [FromQuery] int meetingId = 0, [FromQuery] int agendaId = 0)
        {
            var request = new GetMinutesList()
            {
                ListRequests = new GetListRequest
                {
                    Sort = sort,
                    SortColumn = sortColumn,
                    PerPage = perPage,
                    Page = page,
                },
                MeetingId = meetingId,
                AgendaId = agendaId,
                TenantId = tenantId
            };
            var model = await _minutes.GetMinutesList(request);
            return Ok(model);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromRoute] int tenantId, [FromBody] PostMinutesOfMeeting mm)
        {
            await _minutes.AddMinutesForMeeting(mm, UserId, tenantId);

            return Ok(string.Format(ControllerConstants.RecordsAddedMessage));
        }

        [HttpGet("preview/{Id}")]
        public async Task<IActionResult> Preview([FromRoute] int tenantId, int Id)
        {
            var rawData = await _minutes.GetMinutes(Id, tenantId);
            return rawData != null ? Ok(rawData) : NotFound();
        }

        [HttpPut("{TaskId}")]
        public async Task<IActionResult> Put([FromRoute] int tenantId, int TaskId, [FromBody] PutMinutesOfMeeting mm)
        {
            await _minutes.UpdateMinutesofMeeting(TaskId, mm, UserId, tenantId);
            return NoContent();
        }

        [HttpGet("task/{taskId}")]
        public async Task<IActionResult> GetMinutestoEditData([FromRoute] int tenantId, [FromRoute] int taskId)
        {
            var minutes = await _minutes.GetMinutesDetailtsToEditMinutes(taskId, tenantId);

            return minutes != null ? Ok(minutes) : NotFound();
        }

        [HttpGet("{Id}")]
        public async Task<IActionResult> GetMinutes(int Id)
        {
            var minutes = await _minutes.GetMinutesById(Id);
            return Ok(minutes);
        }

        [HttpDelete("{Id}")]
        public async Task<IActionResult> Delete([FromRoute] int tenantId, int Id)
        {
            await _minutes.DeleteMinutesById(Id, UserId, tenantId);
            return Ok(string.Format(ControllerConstants.RecordDeletedMessage));
        }

        [HttpGet("new/chart/donut")]
        public async Task<IActionResult> GetTaskMasterAllDonutChart([FromRoute] int tenantId)
        {
            var TaskMAsterByStatus = await _chartBusiness.GetChartTaskMasterDonuts(1, tenantId);
            var TaskMAsterByAssignTo = await _chartBusiness.GetChartTaskMasterDonuts(2, tenantId);
            var TaskMAsterByPriority = await _chartBusiness.GetChartTaskMasterDonuts(3, tenantId);
            var TaskMAsterBySource = await _chartBusiness.GetChartTaskMasterDonuts(4, tenantId);
            var TaskMAsterClassification = await _chartBusiness.GetChartTaskMasterDonuts(5, tenantId);
            return Ok(new { TaskMAsterByStatus, TaskMAsterByAssignTo, TaskMAsterByPriority, TaskMAsterBySource, TaskMAsterClassification} );
        }
    }
}