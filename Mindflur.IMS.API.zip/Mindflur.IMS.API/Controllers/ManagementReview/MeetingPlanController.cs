﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.Core.Enums;
using Mindflur.IMS.Application.ViewModel.Custrom;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Application.ViewModel.View;

namespace Mindflur.IMS.API.Controllers.ManagementReview
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/management-review")]
    [ApiController]
    public class MeetingPlanController : BaseController
    {
        private readonly IManagementReviewBusiness _managementReviewBusiness;
        private readonly IParticipantsBusiness _participantBusiness;
        private readonly IChartBusiness _chartBusiness;

        public MeetingPlanController(IManagementReviewBusiness managementReviewBusiness, IParticipantsBusiness participantsBusiness, IChartBusiness chartBusiness)
        {
            _managementReviewBusiness = managementReviewBusiness;
            _participantBusiness = participantsBusiness;
            _chartBusiness = chartBusiness;
        }

        [HttpGet("list")]
        public async Task<IActionResult> GetManagementMeetingReviewGridResult([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0)
        {
            var request = new GetMeetingListRequest()
            {
                ListRequests = new GetListRequest()
                {
                    Sort = sort,
                    SortColumn = sortColumn,
                    PerPage = perPage,
                    Page = page
                },
                TenantId = tenantId
            };
            var model = await _managementReviewBusiness.GetMeetingPlans(request);
            return Ok(model);
        }

        [HttpGet("user/list")]
        public async Task<IActionResult> GetManagementMeetingReviewGridForUser([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0)
        {
            var request = new GetMeetingListRequest()
            {
                ListRequests = new GetListRequest()
                {
                    Sort = sort,
                    SortColumn = sortColumn,
                    PerPage = perPage,
                    Page = page
                },
                TenantId = tenantId,
                ForUserId = UserId
            };
            var model = await _managementReviewBusiness.GetMeetingPlans(request);
            return Ok(model);
        }

        [HttpGet("{meetingId}/agenda-list")]
        public async Task<IActionResult> GetMeetingAgendaList([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, [FromRoute] int meetingId = 0)
        {
            var request = new GetAllMeetingAgendas()
            {
                ListRequests = new GetListRequest
                {
                    Sort = sort,
                    SortColumn = sortColumn,
                    PerPage = perPage,
                    Page = page,
                },
                MeetingId = meetingId,
                TenantId = tenantId
            };
            var model = await _managementReviewBusiness.GetMeetingAgenda(request);
            return Ok(model);
        }

        [HttpGet("{meetingId}/agenda/dropdown")]
        public async Task<IActionResult> GetMeetingAgenda([FromRoute] int tenantId, [FromRoute] int meetingId = 0)
        {
            var request = new GetAllAgendasByMeeting()
            {
                MeetingId = meetingId,
              
                TenantId = tenantId,
            };

           

            var model = await _managementReviewBusiness.GetAllAgendasByMeeting(request);
            return Ok(model);
        }

        [HttpPost("{meetingId}/agenda")]
        public async Task<IActionResult> AddAgendaToMeeting([FromRoute] int tenantId, [FromBody] PostAgendaToMeetingView postAgendaToMeetingView)
        {
            await _managementReviewBusiness.AddAgendaToMeeting(postAgendaToMeetingView, tenantId, UserId);

            return Ok(string.Format(ControllerConstants.RecordCreatedMessage));
        }
        [HttpPost("fileUpload/{meetingId}/agenda/{agendaId}")]
        public async Task<IActionResult> UploadFile(IFormFile files, [FromRoute] int tenantId, [FromRoute] int meetingId, [FromRoute] int agendaId,[FromQuery] AgendaSummaryPostView agendaSummaryPostView)
        {
            await _managementReviewBusiness.AgendaFileUpload(files, tenantId,meetingId, agendaId, agendaSummaryPostView, UserId);
            return NoContent();
        }

       [HttpGet("getfile/{meetingId}/agenda/{agendaId}")]
        public async Task<IActionResult> GetFile([FromRoute] int tenantId, [FromRoute] int meetingId, [FromRoute] int agendaId)
        {
           var file =  await _managementReviewBusiness.GetFile( tenantId, meetingId, agendaId);
            return File(file.Content, "application/octet-stream", file.FileName);
        }
        [HttpDelete("deletefile/{meetingId}/agenda/{agendaId}")]
        public async Task<IActionResult> DeleteFile([FromRoute] int tenantId, [FromRoute] int meetingId, [FromRoute] int agendaId)
        {
            await _managementReviewBusiness.DeleteFile(tenantId, meetingId, agendaId);
            return NoContent();
        }
        [HttpPost]
        public async Task<IActionResult> Post([FromRoute] int tenantId, [FromBody] PostMeetingPlan ma)
        {
            await _managementReviewBusiness.AddNewMeeting(ma, tenantId, UserId);
            return Ok(string.Format(ControllerConstants.MeetingCreatedMessage));
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get([FromRoute] int tenantId, int id)
        {
            var result = await _managementReviewBusiness.GetMeetingPlanById(id, tenantId);
            return Ok(result);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put([FromRoute] int tenantId, int id, [FromBody] PutMeeting meetingPlan)
        {
            await _managementReviewBusiness.UpdateMeetingPlan(id, meetingPlan, tenantId, UserId);
            return NoContent();
        }
        [HttpGet("dropdownlist")]
        public async Task<IActionResult> DropDown([FromRoute] int tenantId, int meetingId)
        {
            var mrmList = await _managementReviewBusiness.GetMRMDropDownList(tenantId, meetingId);
            return Ok(mrmList);
        }
        [HttpPut("{mrmId}/publish")]
        public async Task<IActionResult> Publish([FromRoute] int tenantId, [FromRoute] int mrmId)
        {
            await _managementReviewBusiness.UpdateAsPubluishForMeeting(mrmId, tenantId, UserId);

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete([FromRoute] int tenantId, int id)
        {
            await _managementReviewBusiness.DeleteMeetingById(id, tenantId, UserId);
            return NoContent();
        }

        [HttpPost("participant")]
        public async Task<IActionResult> Post([FromRoute] int tenantId, [FromBody] AddParticipantViewModel addParticipant)
        {
            await _managementReviewBusiness.AddMeetingParticipants(addParticipant, 2, tenantId, UserId);
            return Ok(string.Format(ControllerConstants.ParticipantAddedmessage));
        }

        [HttpGet("{meetingId}/participants")]
        public async Task<IActionResult> Minutes([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, [FromRoute] int meetingId = 0)
        {
            var request = new GetParticipantsList()
            {
                ListRequests = new GetListRequest
                {
                    Sort = sort,
                    SortColumn = sortColumn,
                    PerPage = perPage,
                    Page = page,
                },
                ModuleEntityId = meetingId,
                TenantId = tenantId
            };
            var model = await _participantBusiness.GetMinutesParticipantsList(request, 2);
            return Ok(model);
        }

        [HttpPut("participant/{participantId}")]
        public async Task<IActionResult> UpdateParticipant([FromRoute] int participantId, [FromBody] UpdateParticipantViewModel updateParticipant)
        {
            await _participantBusiness.UpdateParticipants(updateParticipant, participantId, UserId);
            return NoContent();
        }

        [HttpPut("participant/{participantId}/markPresent")]
        public async Task<IActionResult> MarkPresent([FromRoute] int participantId)
        {
            await _participantBusiness.UpdateParticipantsMarkPresent(participantId);
            return NoContent();
        }

        [HttpDelete("participant/{participantId}/deleteParticipant")]
        public async Task<IActionResult> DeletePresent([FromRoute] int participantId)
        {
            await _participantBusiness.DeleteParticipants(participantId, UserId);
            return NoContent();
        }

        [HttpPut("{meetingId:int}/approve")]
        public async Task<IActionResult> Approve([FromRoute] int tenantId, [FromRoute] int meetingId)
        {
            await _managementReviewBusiness.ApproveMeeting(tenantId, meetingId, UserId);
            return NoContent();
        }

        [HttpPut("{meetingId:int}/start")]
        public async Task<IActionResult> Start([FromRoute] int tenantId, [FromRoute] int meetingId)
        {
            await _managementReviewBusiness.StartMeeting(tenantId, meetingId, UserId);

            return NoContent();
        }

        [HttpPut("{meetingId:int}/complete")]
        public async Task<IActionResult> Complete([FromRoute] int tenantId, [FromRoute] int meetingId)
        {
            await _managementReviewBusiness.CompleteMeeting(tenantId, meetingId, UserId);

            return NoContent();
        }

        [HttpPut("{meetingId:int}/report")]
        public async Task<IActionResult> Report([FromRoute] int tenantId, [FromRoute] int meetingId)
        {
            await _managementReviewBusiness.GenerateReport(tenantId, meetingId);

            return NoContent();
        }

        [HttpGet("{meetingId}/audit")]
        public async Task<IActionResult> GetAuditDetailsForMeeting([FromRoute] int tenantId, [FromRoute] int meetingId)
        {
            var auditDetails = await _managementReviewBusiness.GetAuditDetailsForMeeting(tenantId, meetingId);
            return Ok(auditDetails);
        }

        [HttpGet("landingPageCharts")]
        public async Task<IActionResult> getLandingPageCharts([FromRoute] int tenantId, int category = 1)
        {
            if (category >= 1 && category < 6)
            {
                var rawData = await _chartBusiness.GetmanagementReviewLandingPageCharts(category, tenantId);
                return Ok(rawData);
            }
            else
            {
                return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
            }
        }

        [HttpGet("{meetingId}/list/chart")]
        public async Task<IActionResult> getMrmCharts([FromRoute] int tenantId, int meetingId = 0, int category = 1)
        {
            if (category >= 1 && category < 6)
            {
                var rawData = await _chartBusiness.GetMrmTaskCharts(category, meetingId, tenantId);
                return Ok(rawData);
            }
            else
            {
                return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
            }
        }

        [HttpGet("new/chart/landingPageCharts")]
        public async Task<IActionResult> GetAllLandingPageCharts([FromRoute] int tenantId)
        {
            var MeetingByStatus = await _chartBusiness.GetmanagementReviewLandingPageCharts(1, tenantId);
            var MeetingAgendasByStaus = await _chartBusiness.GetmanagementReviewLandingPageCharts(2, tenantId);
            var MeetingMinutesBystatus = await _chartBusiness.GetmanagementReviewLandingPageCharts(3, tenantId);
            var MeetingMinutesByAssignTo = await _chartBusiness.GetmanagementReviewLandingPageCharts(4, tenantId);
            var MeetingMinutesByPriority = await _chartBusiness.GetmanagementReviewLandingPageCharts(5, tenantId);
            return Ok(new { MeetingByStatus, MeetingAgendasByStaus, MeetingMinutesBystatus, MeetingMinutesByAssignTo, MeetingMinutesByPriority });
        }

		[HttpGet("{meetingId}/list/chart/NewChartByMeetingId")]
		public async Task<IActionResult> getMrmChartsByMeetingId([FromRoute] int tenantId, int meetingId = 0)
		{
			var TaskByMeetingId = await _chartBusiness.GetMrmTaskCharts(1, meetingId, tenantId);
			var TaskAssignToByMeetingId = await _chartBusiness.GetMrmTaskCharts(2, meetingId, tenantId);
			var TaskPriorityByMeetingId = await _chartBusiness.GetMrmTaskCharts(3, meetingId, tenantId);

			return Ok(new { TaskByMeetingId, TaskAssignToByMeetingId, TaskPriorityByMeetingId });
		}
	}
}