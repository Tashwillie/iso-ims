﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Application.ViewModel.View;

namespace Mindflur.IMS.API.Controllers.NonConformance
{
	[ApiVersion("1")]
	[Route("api/v{version:apiVersion}/tenant/{tenantId}")]
	[ApiController]
	[Authorize]
	public class NonConformityController : BaseController
	{
		private readonly INonConformanceBusiness _nonConformanceBusiness;
		private readonly IChartBusiness _chartBusiness;

		public NonConformityController(INonConformanceBusiness nonConformanceBusiness, IChartBusiness chartBusiness)
		{
			_chartBusiness = chartBusiness;
			_nonConformanceBusiness = nonConformanceBusiness;
		}

		[HttpGet("non-conformity/chart/donut")]
		public async Task<IActionResult> NonConformanceDonutChart([FromRoute] int tenantId, int category = 1)
		{
			if (category >= 1 && category < 4)
			{
				var rawData = await _chartBusiness.GetChartNonConformanceDonuts(category, tenantId);
				return Ok(rawData);
			}
			else
			{
				return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
			}
		}

		[HttpGet("non-conformity/chart/bar")]
		public async Task<IActionResult> GetNonConformanceBarChart([FromRoute] int tenantId, int category = 1)
		{
			if (category >= 1 && category < 4)
			{
				//Get all non-conformance as open and close
				var rawData = await _chartBusiness.GetChartBarGraph(category, tenantId);
				return Ok(rawData);
			}
			else
			{
				return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
			}
		}

		[HttpGet("non-conformity/donut/chart/tasks")]
		public async Task<IActionResult> GetTasks([FromRoute] int tenantId, int category = 1)
		{
			if (category >= 1 && category < 4)
			{
				var rawData = await _chartBusiness.GetTaskListsCharts(category, tenantId);
				return Ok(rawData);
			}
			else
			{
				return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
			}
		}

		[HttpGet("non-conformity/donut/chart/corrective-action")]
		public async Task<IActionResult> GetAllCA([FromRoute] int tenantId, int category = 1)
		{
			if (category >= 1 && category < 4)
			{
				var rawData = await _chartBusiness.GetALLCorrectiveAction(category, tenantId);
				return Ok(rawData);
			}
			else
			{
				return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
			}
		}

		[HttpPut("non-conformity/nc-open/{workItemId}")]
		public async Task<IActionResult> open([FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			await _nonConformanceBusiness.StartNonconformance(UserId, workItemId, tenantId);
			return NoContent();
		}

		[HttpPut("non-conformity/{workItemId}/metadata")]
		public async Task<IActionResult> PutNonConformanceMetadata([FromRoute] int tenantId, [FromRoute] int workItemId, PutNonConformanceMetadataViewModel nonconformanceMetadataViewModel)
		{
			await _nonConformanceBusiness.UpsertMetadata(nonconformanceMetadataViewModel, workItemId, UserId, tenantId);
			return NoContent();
		}

		[HttpPut("non-conformity/{workItemId}/metadata/review")]
		public async Task<IActionResult> ReviewNonConformanceMetadata(ReviewNonconformanceMetadata reviewNonconformanceMetadata, [FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			await _nonConformanceBusiness.ReviewMetadata(reviewNonconformanceMetadata, tenantId, workItemId, UserId);
			return NoContent();
		}

		[HttpPut("non-conformity/{workItemId}/metadata/reject")]
		public async Task<IActionResult> rejectNonConformanceMetadata(RejectNonconformanceMetadata comments, [FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			await _nonConformanceBusiness.RejectMetadata(comments, tenantId, workItemId, UserId);
			return NoContent();
		}

		[HttpPut("non-conformity/{workItemId}/metadata/close")]
		public async Task<IActionResult> CloseNonConformanceMetadata(CloseNonConformanceMetaData closeNonConformanceMetaData, [FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			await _nonConformanceBusiness.CloseMetadata(closeNonConformanceMetaData, tenantId, workItemId, UserId);
			return NoContent();
		}

		[HttpGet("non-conformity/{workItemId}/metadata")]
		public async Task<IActionResult> GetNonConformanceMetadataToken([FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			var metaData = await _nonConformanceBusiness.GetNonConformanceMetadata(workItemId, tenantId);
			if (metaData == null)
			{
				metaData = new GetNonConformanceMetadataViewWithTokens();
				return Ok(metaData);
			}
			return Ok(metaData);
		}

		[HttpGet("non-conformity/chart/allDonutChart")]
		public async Task<IActionResult> NonConformanceDonutChart([FromRoute] int tenantId)
		{
			var ByDepartment = await _chartBusiness.GetChartNonConformanceDonuts(1, tenantId);
			var ByStatus = await _chartBusiness.GetChartNonConformanceDonuts(2, tenantId);
			var ByTypes = await _chartBusiness.GetChartNonConformanceDonuts(3, tenantId);
			var TaskListByNC = await _chartBusiness.GetTaskListsCharts(2, tenantId);
			var GetCAListForNC = await _chartBusiness.GetALLCorrectiveAction(1, tenantId);
			var GetCAListForIncident = await _chartBusiness.GetALLCorrectiveAction(2, tenantId);
			return Ok(new { ByDepartment, ByStatus, ByTypes, TaskListByNC, GetCAListForNC, GetCAListForIncident });
		}

		[HttpGet("nc-category/dropdown")]
		public async Task<IActionResult> getNcCategoryDropDown([FromRoute] int tenantId)
		{
			var rawData = await _nonConformanceBusiness.GetNcCategoryDropdown(tenantId);
			return Ok(rawData);
		}
	}
}