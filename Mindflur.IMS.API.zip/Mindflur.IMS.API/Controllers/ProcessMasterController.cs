﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.ViewModel.View;
using Mindflur.IMS.Business;

namespace Mindflur.IMS.API.Controllers
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/process")]
    [ApiController]
    public class ProcessMasterController : BaseController
    {
        private readonly IProcessMasterBusiness _processMasterBusiness;

        public ProcessMasterController(IProcessMasterBusiness processMasterBusiness)
        {
            _processMasterBusiness = processMasterBusiness;
        }

        [HttpGet("list")]
        public async Task<IActionResult> GetProcessMasterList([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, int? departmentId = 0, int? processId = 0)
        {
            var result = new ProcessMasterList()
            {
                ListRequests = new GetListRequest()
                {
                    Sort = sort,
                    SortColumn = sortColumn,
                    PerPage = perPage,
                    Page = page
                },
                TenantId = tenantId,
                DepartmentId = departmentId,
                ProcessId = processId
            };
            var model = await _processMasterBusiness.GetProcessMasterList(result);
            return Ok(model);
        }


        [HttpGet("{processId}")]
        public async Task<IActionResult> GetRequestDetails([FromRoute] int tenantId, int processId)
       {

            var rawData = await _processMasterBusiness.GetProcessMastertDetails( tenantId, processId);

            return Ok(rawData);
        }

        [HttpGet("dropdown")]

        public async Task<IActionResult> GetProcessMasterDropDown([FromRoute] int tenantId)
        {
            var process = await _processMasterBusiness.GetParentProcessId(tenantId);
            return Ok(process);
        }

        [HttpPost]
        public async Task<IActionResult> AddProcessMaster([FromRoute] int tenantId, PostProcessMaster postProcessMaster )
        {
            await _processMasterBusiness.AddProcessMaster(postProcessMaster, tenantId, UserId);
            return NoContent();
        }

        [HttpPut("{processId}")]
        public async Task<IActionResult> PutProcessMaster([FromRoute] int tenantId, [FromRoute] int processId ,[FromBody] PutProcessMaster putProcessMaster)
        {
            await _processMasterBusiness.UpdatedProcessMaster(putProcessMaster, processId, tenantId, UserId);
            return NoContent();
        }
        [HttpDelete("{processId}")]
        public async Task<IActionResult> Delete([FromRoute] int tenantId, [FromRoute] int processId)
        {
            await _processMasterBusiness.DeleteProcessMaster(processId, tenantId);
            return NoContent();
        }
    }
}
