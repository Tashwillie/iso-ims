﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel;
using Mindflur.IMS.Application.ViewModel.Model;
using System.Net;

namespace Mindflur.IMS.API.Controllers.Task
{
	[ApiVersion("1")]
	[Route("api/v{version:apiVersion}/tenant/{tenantId}/task")]
	[ApiController]
	public class TaskMetaDataController : BaseController
	{
		private readonly ITaskMasterBusiness _taskMasterBusiness;
		private readonly IChartBusiness _chartBusiness;

		public TaskMetaDataController(ITaskMasterBusiness taskMasterBusiness, IChartBusiness chartBusiness)
		{
			_taskMasterBusiness = taskMasterBusiness;
			_chartBusiness = chartBusiness;
		}

		[HttpGet("bar")]
		public async Task<IActionResult> GetAllTaskMasterChart([FromRoute] int tenantId, int category = 1)
		{
			if (category == 1)
			{
				var rawData = await _chartBusiness.GetChartBarGraph(category, tenantId);
				return Ok(rawData);
			}
			else
			{
				return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
			}
		}

		[HttpGet("chart/donut")]
		public async Task<IActionResult> TaskMasterDonutChart([FromRoute] int tenantId, int category = 1)
		{
			if (category >= 1 && category < 6)
			{
				var rawData = await _chartBusiness.GetChartTaskMasterDonuts(category, tenantId);
				return Ok(rawData);
			}
			else
			{
				return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
			}
		}

		[HttpPut("{workItemId}")]
		[ProducesResponseType((int)HttpStatusCode.OK)]
		public async Task<IActionResult> Post([FromRoute] int tenantId, [FromRoute] int workItemId, [FromBody] PostViewTask postTaskView)
		{
			await _taskMasterBusiness.UpsertTaskMetaData(postTaskView, tenantId, workItemId, UserId);
			return Ok();
		}

		[HttpDelete]
		[Route("{taskId:int}")]
		[ProducesResponseType((int)HttpStatusCode.NoContent)]
		[ProducesResponseType((int)HttpStatusCode.NotFound)]
		public async Task<IActionResult> Delete(int taskId)
		{
			await _taskMasterBusiness.DeleteTasks(taskId);

			return NoContent();
		}

		[HttpGet("{workItemId}/metadata")]
		public async Task<IActionResult> GetRiskMetaData([FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			var task = await _taskMasterBusiness.GetTaskMetaData(tenantId, workItemId);

			return Ok(task);
		}

		[HttpGet("new/chart/donut")]
		public async Task<IActionResult> GetAllTaskDonutChart([FromRoute] int tenantId)
		{
			var TaskMasterByStatus = await _chartBusiness.GetChartTaskMasterDonuts(1, tenantId);
			var TaskMasterByAssignTo = await _chartBusiness.GetChartTaskMasterDonuts(2, tenantId);
			var TaskMasterByPriority = await _chartBusiness.GetChartTaskMasterDonuts(3, tenantId);
			var TaskMasterByBySource = await _chartBusiness.GetChartTaskMasterDonuts(4, tenantId);
			var TaskMasterByClassification = await _chartBusiness.GetChartTaskMasterDonuts(5, tenantId);

			return Ok(new { TaskMasterByStatus, TaskMasterByAssignTo, TaskMasterByPriority, TaskMasterByBySource, TaskMasterByClassification });
		}

		[HttpPut("{workItemId}/task/approve")]
		public async Task<IActionResult> TaskMetaDataReview(TaskMetaDataComments comments, [FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			await _taskMasterBusiness.ApproveTaskMetaData(comments, workItemId, tenantId, UserId);
			return NoContent();
		}

		[HttpPut("{workItemId}/task/reject")]
		public async Task<IActionResult> rejectTaskMetadata(RejectTaskMetadata comments, [FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			await _taskMasterBusiness.RejectMetadata(comments, tenantId, workItemId, UserId);
			return NoContent();
		}

		[HttpPut("{workItemId}/task/start")]
		public async Task<IActionResult> Start([FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			await _taskMasterBusiness.StartMetaData(tenantId, workItemId, UserId);
			return NoContent();
		}

		[HttpGet("ReviewerList/{WorkItemId}")]
		public async Task<IActionResult> GetTokenByParentTokenId([FromRoute] int WorkItemId)
		{
			var data = await _taskMasterBusiness.GetReviewerLists(WorkItemId);
			if (data == null)
			{
				return BadRequest(string.Format(ControllerConstants.NoRecordsForIdErrorMessage, data));
			}
			else
			{
				return Ok(data);
			}
		}

		[HttpPut("{phaseId}/close/phase")]
		public async Task<IActionResult> ClosePhase([FromRoute] int tenantId, [FromRoute] int phaseId)
		{
			await _taskMasterBusiness.ClosePhases(phaseId, tenantId, UserId);
			return NoContent();
		}

		[HttpPut("{projectId}/close/project")]
		public async Task<IActionResult> CloseProject([FromRoute] int tenantId, [FromRoute] int projectId)
		{
			await _taskMasterBusiness.CloseProjects(projectId, tenantId, UserId);
			return NoContent();
		}
	}
}