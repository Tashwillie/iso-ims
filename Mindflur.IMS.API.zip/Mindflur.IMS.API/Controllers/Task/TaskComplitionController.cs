﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Mindflur.IMS.Data;

namespace Mindflur.IMS.API.Controllers.Task
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/task-completion")]
    [ApiController]
    public class TaskComplitionController : ControllerBase
    {
        private readonly IMSDEVContext _context;

        public TaskComplitionController(IMSDEVContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var taskCompletes = await _context.TaskComplitions.ToListAsync();
            return Ok(taskCompletes);
        }
    }
}