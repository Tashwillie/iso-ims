﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.Application.Contracts.Business;

namespace Mindflur.IMS.API.Controllers.ControlCenter
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}")]
    [ApiController]
    public class UserPointsController : ControllerBase
    {
        private readonly IUserPointsBusiness _userPointsBusiness;

        public UserPointsController(IUserPointsBusiness userPointsBusiness)
        {
            _userPointsBusiness = userPointsBusiness;
        }

        [HttpGet("users/{userId}/points")]
        public async Task<IActionResult> GetPointsByUserID([FromRoute] int userId = 0)
        {
            var getUsers = await _userPointsBusiness.GetPointsByUserId(userId);
            return Ok(getUsers);
        }

        [HttpGet("points")]
        public async Task<IActionResult> GetPoints()
        {
            var getuserlist = await _userPointsBusiness.GetPoints();
            return Ok(getuserlist);
        }
    }
}