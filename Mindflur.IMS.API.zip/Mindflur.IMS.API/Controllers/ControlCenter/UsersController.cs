﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.View;

namespace Mindflur.IMS.API.Controllers.ControlCenter
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/users")]
    [ApiController]
    public class UsersController : BaseController
    {
        private readonly IUserBusiness _userBusiness;
        private readonly ITenantMasterBusiness _tenantMasterBusiness;

        public UsersController(IUserBusiness userBusiness, ITenantMasterBusiness tenantMasterBusiness)
        {
            _userBusiness = userBusiness;
            _tenantMasterBusiness = tenantMasterBusiness;
        }

        [HttpGet]
        public async Task<IActionResult> Get([FromRoute] int tenantId)
        {
            var rawData = await _userBusiness.GetAllUsers(tenantId);
            return Ok(rawData);
        }

        [HttpGet("list")]
        public async Task<IActionResult> GetList([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, int? departmentId = 0, int? status = 0, int? roleId = 0)
        {
            var request = new GetUserRequest()
            {
                ListRequests = new GetListRequest
                {
                    Sort = sort,
                    Page = page,
                    PerPage = perPage,
                    SortColumn = sortColumn
                },
                TenantId = tenantId,
                DepartmentId = departmentId,
                StatusId = status,
                RoleId = roleId
            };
            var rawData = await _userBusiness.GetAllUsersByTenantId(request);
            return Ok(rawData);
        }

        [HttpGet("department/{DepartmentId}")]
        public async Task<IActionResult> UsersByDepartmentId([FromRoute] int tenantId, int DepartmentId)
        {
            var rawData = await _userBusiness.GetUserByDepartmentId(DepartmentId, tenantId);
            return Ok(rawData);
        }

        [HttpGet("Preview/{Id}")]
        public async Task<IActionResult> Preview(int Id, [FromRoute] int tenantId)
        {
            var rawData = await _userBusiness.GetUserDetails(Id, tenantId);

            return rawData != null ? Ok(rawData) : NotFound();
        }

        [HttpGet("Preview2/{Id}")]
        public async Task<IActionResult> Preview2([FromRoute] int tenantId,int Id)
        {
            var rawData = await _userBusiness.GetUserDetail(Id, tenantId);

            return rawData != null ? Ok(rawData) : NotFound();
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] AddNewUserViewModel addNewUserViewModel, [FromRoute] int tenantId)
        {
            var tenant = await _tenantMasterBusiness.GetTenantById(tenantId);

            await _userBusiness.AddUser(addNewUserViewModel, tenant, UserId);

            return Ok(string.Format(ControllerConstants.RecordCreatedMessage));
        }

        [HttpPut("{Id}")]
        public async Task<IActionResult> Put([FromRoute] int tenantId, int Id, [FromBody] UpdatedUserViewModel updateUserViewModel)
        {
            var tenant = await _tenantMasterBusiness.GetTenantById(tenantId);
            await _userBusiness.UpdateUser(updateUserViewModel, tenant, Id, tenantId, UserId);
            return NoContent();
        }

        [HttpGet("List_Of_Task_by_UserId/{Id}")]
        public async Task<IActionResult> Task([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, int Id = 0)
        {
            var request = new GetTaskListByUserId()
            {
                ListRequests = new GetListRequest
                {
                    Sort = sort,
                    Page = page,
                    PerPage = perPage,
                    SortColumn = sortColumn
                },
                ActionId = Id,
                TenantId = tenantId
            };

            var model = await _userBusiness.GetTasksByUserId(request);

            return Ok(model);
        }

        [HttpDelete("{Id}")]
        public async Task<IActionResult> Delete(int Id, int tenantId)
        {
            await _userBusiness.DeleteUser(Id, tenantId);
            return NoContent();
        }

        [HttpPost("{userId}/password")]
        public async Task<IActionResult> ChangePassword([FromRoute] int tenantId, [FromRoute] int userId, ChangeUserPasswordView changeUserPassword)
        {
            await _userBusiness.ChangeUserPassword(tenantId, userId, changeUserPassword);

            return NoContent();
        }

        [HttpGet("{userId}/mrm/list")]
        public async Task<IActionResult> GetListOfMeeting([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, int userId = 0)
        {
            var request = new GetTaskListByUserId()
            {
                ListRequests = new GetListRequest
                {
                    Sort = sort,
                    Page = page,
                    PerPage = perPage,
                    SortColumn = sortColumn
                },
                ActionId = userId,
                TenantId = tenantId
            };
            var model = await _userBusiness.GetManagementReviewList(request);
            return Ok(model);
        }
    }
}