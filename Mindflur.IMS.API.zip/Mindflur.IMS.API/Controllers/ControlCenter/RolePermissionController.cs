﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.ViewModel.View;

namespace Mindflur.IMS.API.Controllers.ControlCenter
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}")]
    [ApiController]
    public class RolePermissionController : ControllerBase
    {
        private readonly IRolePermissionBusiness _rolePermissionBusiness;

        public RolePermissionController(IRolePermissionBusiness rolePermission)
        {
            _rolePermissionBusiness = rolePermission;
        }

        [HttpPut("role/{roleId}/permissions")]
        public async Task<IActionResult> Put([FromRoute] int tenantId, [FromRoute] int roleId, [FromBody] UpsertPermissionModel upsertPermissionModel)
        {
            await _rolePermissionBusiness.UpsertRolePermissions(tenantId, roleId, upsertPermissionModel);

            return NoContent();
        }

        [HttpGet("role/{roleId}/permissions/list")]
        public async Task<IActionResult> GetpermissionList([FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, [FromRoute] int tenantId = 0, [FromRoute] int roleId = 0)
        {
            var request = new GetPermissionList()
            {
                ListRequests = new GetListRequest
                {
                    Sort = sort,
                    SortColumn = sortColumn,
                    PerPage = perPage,
                    Page = page,
                },
                TenantId = tenantId,
                RoleId = roleId,
            };
            var model = await _rolePermissionBusiness.GetPermissionList(request);
            return Ok(model);
        }

        [HttpGet("role/{roleId}/permissions")]
        public async Task<IActionResult> Permission([FromRoute] int tenantId, [FromRoute] int roleId)
        {
            var permissions = await _rolePermissionBusiness.GetPermissionList(tenantId, roleId);

            return Ok(permissions);
        }
    }
}