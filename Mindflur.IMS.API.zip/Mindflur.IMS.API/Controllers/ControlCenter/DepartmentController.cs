﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Application.ViewModel.View;

namespace Mindflur.IMS.API.Controllers.ControlCenter
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/department")]
    [ApiController]
    public class DepartmentController : BaseController
    {
        private readonly IDepartmentMasterBusiness _departmentMasterBusiness;

        public DepartmentController(IDepartmentMasterBusiness departmentMasterBusiness)
        {
            _departmentMasterBusiness = departmentMasterBusiness;
        }

        [HttpGet("list")]
        public async Task<IActionResult> GetDepartmentList([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0)
        {
            var result = new DepartmentMasterList()
            {
                ListRequests = new GetListRequest()
                {
                    Sort = sort,
                    SortColumn = sortColumn,
                    PerPage = perPage,
                    Page = page
                },
                TenantId = tenantId
            };
            var model = await _departmentMasterBusiness.GetDepartmentList(result);
            return Ok(model);
        }

        [HttpGet("dropdown")]
        public async Task<IActionResult> GetDepartmentDropDown([FromRoute] int tenantId)
        {
            var dept = await _departmentMasterBusiness.GetDepartmentByTenant(tenantId);
            return Ok(dept);
        }

        [HttpPost]
        public async Task<IActionResult> AddDepartment([FromRoute] int tenantId, PostDepartments departmentMaster)
        {
            await _departmentMasterBusiness.AddDepartment(tenantId, departmentMaster);
            return NoContent();
        }

        [HttpPut("{deptartmentId}")]
        public async Task<IActionResult> UpdateDepartment([FromRoute] int tenantId, [FromRoute] int deptartmentId, PostDepartments postDepartments)
        {
            await _departmentMasterBusiness.UpdateDepartment(tenantId, deptartmentId, postDepartments);
            return NoContent();
        }

        [HttpGet("{departmentId}")]
        public async Task<IActionResult> GetDepartmentbyId([FromRoute] int tenantId, [FromRoute] int departmentId)
        {
            var dept = await _departmentMasterBusiness.GetDepartmentById(tenantId, departmentId);
            return Ok(dept);
        }

        [HttpDelete("{departmentId}")]
        public async Task<IActionResult> Delete([FromRoute] int tenantId, [FromRoute] int departmentId)
        {
            await _departmentMasterBusiness.DeleteDepartmentById(tenantId, departmentId);
            return NoContent();
        }
    }
}