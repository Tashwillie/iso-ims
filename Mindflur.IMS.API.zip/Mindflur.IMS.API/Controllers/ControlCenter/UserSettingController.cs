﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Mindflur.IMS.Data;

namespace Mindflur.IMS.API.Controllers.ControlCenter
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/user-setting")]
    [ApiController]
    public class UserSettingController : ControllerBase
    {
        private readonly IMSDEVContext _context;

        public UserSettingController(IMSDEVContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var userSettings = await _context.UserSettingMasters.ToListAsync();
            await _context.SaveChangesAsync();
            return Ok(userSettings);
        }
    }
}