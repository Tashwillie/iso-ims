﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Enums;
using Mindflur.IMS.Application.ViewModel.Model;

namespace Mindflur.IMS.API.Controllers.ControlCenter
{
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/tenant-theme")]
    [ApiController]
    public class TenantThemeController : BaseController
    {
        private readonly ITenantThemeBusiness _tenantThemeBusiness;
        private readonly IFileRepositoryBusiness _fileRepositoryBusiness;

        public TenantThemeController(ITenantThemeBusiness tenantThemeBusiness, IFileRepositoryBusiness fileRepositoryBusiness)
        {
            _tenantThemeBusiness = tenantThemeBusiness;
            _fileRepositoryBusiness = fileRepositoryBusiness;
        }

        [HttpGet]
        public async Task<IActionResult> Get([FromRoute] int tenantId)
        {
            var rawData = await _tenantThemeBusiness.GetTheme(tenantId);
            return Ok(rawData);
        }

        [HttpPut()]
        public async Task<IActionResult> Put([FromRoute] int tenantId, PutTenantTheme putTenantTheme)
        {
            await _tenantThemeBusiness.UpdateTheme(tenantId, putTenantTheme, UserId);
            return NoContent();
        }

        [HttpPost("icon")]
        public async Task<IActionResult> UploadIconFile([FromRoute] int tenantId, IFormFile files)
        {
            var postFileRepositoryView = new PostFileRepositoryView();
            postFileRepositoryView.SourceId = (int)IMSModules.SiteIcon;
            postFileRepositoryView.SourceItemId = (int)IMSModules.TenantTheme;
            var fileRepo = await _fileRepositoryBusiness.AddFile(files, tenantId, postFileRepositoryView, UserId);

            var tenantTheme = new PutIconTenantTheme();
            tenantTheme.SiteIconPath = fileRepo.FileRepositoryId;

            await _tenantThemeBusiness.UpdateIconTenantTheme(tenantId, tenantTheme, UserId);

            return NoContent();
        }

        [HttpPost("logo")]
        public async Task<IActionResult> UploadLogoFile([FromRoute] int tenantId, IFormFile files)
        {
            var postFileRepositoryView = new PostFileRepositoryView();
			postFileRepositoryView.SourceId = (int)IMSModules.SiteLogo;
			postFileRepositoryView.SourceItemId = (int)IMSModules.TenantTheme;
			var fileRepo = await _fileRepositoryBusiness.AddFile(files, tenantId, postFileRepositoryView, UserId);

            var tenantTheme = new PutIconTenantTheme();
            tenantTheme.SiteLogoPath = fileRepo.FileRepositoryId;

            await _tenantThemeBusiness.UpdateLogoTenantTheme(tenantId, tenantTheme, UserId);

            return NoContent();
        }

        [HttpPost("coverPath")]
        public async Task<IActionResult> UploadLoginCoverPage([FromRoute] int tenantId, IFormFile files)
        {
            var postFileRepositoryView = new PostFileRepositoryView();
            postFileRepositoryView.SourceId = 194;
            postFileRepositoryView.SourceItemId = 27;
            var fileRepo = await _fileRepositoryBusiness.AddFile(files, tenantId, postFileRepositoryView, UserId);

            var tenantTheme = new PutIconTenantTheme();
            tenantTheme.SiteCoverPath = fileRepo.FileRepositoryId;

            await _tenantThemeBusiness.UpdateCoverTenantTheme(tenantId, tenantTheme, UserId);

            return NoContent();
        }

        [HttpGet("icon")]
        public async Task<IActionResult> IconDownload([FromRoute] int tenantId)
        {
            var file = await _tenantThemeBusiness.GetIcon(tenantId);
            return Ok(file);
        }

        [HttpGet("logo")]
        public async Task<IActionResult> LogoDownload([FromRoute] int tenantId)
        {
            var file = await _tenantThemeBusiness.GetLogo(tenantId);

            return Ok(file);
        }

        [HttpGet("coverPath")]
        public async Task<IActionResult> CoverPathDownload([FromRoute] int tenantId)
        {
            var file = await _tenantThemeBusiness.GetCoverPath(tenantId);

            return Ok(file);
        }

		[HttpGet("TenantLogoPath")]
		public async Task<IActionResult> GetTenantIconPath([FromRoute] int tenantId)
		{
			var rawData = await _tenantThemeBusiness.GetTenantIconBytenant(tenantId);

			return Ok(rawData);
		}
	}
}