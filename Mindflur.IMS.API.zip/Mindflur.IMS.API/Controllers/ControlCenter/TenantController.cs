﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Application.ViewModel.View;

namespace Mindflur.IMS.API.Controllers.ControlCenter
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant")]
    [ApiController]
    public class TenantController : BaseController
    {
        private readonly ITenantMasterBusiness _tenantMasterBusiness;
        

        public TenantController(ITenantMasterBusiness tenantMasterBusiness)
        {
            _tenantMasterBusiness = tenantMasterBusiness;
            
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var rawData = await _tenantMasterBusiness.GetTenantsView();
            return Ok(rawData);
        }

        [HttpGet("list")]
        public async Task<IActionResult> GetList([FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0)
        {
            var request = new GetListRequest()
            {
                Sort = sort,
                SortColumn = sortColumn,
                PerPage = perPage,
                Page = page
            };

            var model = await _tenantMasterBusiness.GetAllTenantsView(request);
            return Ok(model);
        }

        [HttpGet("{tenantId}")]
        public async Task<IActionResult> GetByTenantId(int tenantId)
        {
            var rawData = await _tenantMasterBusiness.GetTenantViewById(tenantId);
            return Ok(rawData);
        }

        //[Authorize(Roles = "super-admin-role")]
        [HttpPost()]
        public async Task<IActionResult> Post([FromBody] CreateTenantViewModel tenant)
        {
            await _tenantMasterBusiness.AddTenant(tenant, UserId);

           return Ok(string.Format(ControllerConstants.TenantOrRealmCreatedMessage));
            
        }

        [HttpPut("{tenantId}")]
        public async Task<IActionResult> Put([FromBody] updateTenantViewModel tenant, int tenantId)
        {
            await _tenantMasterBusiness.UpdateTenant(tenant, UserId, tenantId);

            return NoContent();
        }
    }
}