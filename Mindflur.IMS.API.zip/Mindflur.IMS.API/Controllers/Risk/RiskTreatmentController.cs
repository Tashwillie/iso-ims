﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Application.ViewModel.View;

namespace Mindflur.IMS.API.Controllers.Risk
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/risk-treatment")]
    [ApiController]
    public class RiskTreatmentController : BaseController
    {
        private readonly IRiskTreatmentBusiness _riskTreatmentBusiness;
        private readonly IChartBusiness _chartBusiness;

        public RiskTreatmentController(IRiskTreatmentBusiness riskTreatmentBusiness, IChartBusiness chartBusiness)
        {
            _chartBusiness = chartBusiness;

            _riskTreatmentBusiness = riskTreatmentBusiness;
        }


        [HttpGet("chart/donut")]
        public async Task<IActionResult> RiskTreatmentDonutChart([FromRoute] int tenantId, int category = 1)
        {
            if (category >= 1 && category < 4)
            {
                var rawData = await _chartBusiness.GetChartRiskTreatmentDounutChart(category, tenantId);
                return Ok(rawData);
            }
            else
            {
                return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
            }
        }
        [HttpGet]
        public async Task<IActionResult> Get([FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0)
        {

            var request = new GetListRequest()
            {

                Page = page,
                Sort = sort,
                SortColumn = sortColumn,
                PerPage = perPage
            };
            var rawData = await _riskTreatmentBusiness.GetRiskTreatment(request);
            return Ok(rawData);

        }

        [HttpGet("Preview/{Id}")]
        public async Task<IActionResult> Preview(int Id)
        {

            var rawData = await _riskTreatmentBusiness.GetRiskTreatmentPreview(Id);
            return Ok(rawData);

        }

        [HttpPost]
        public async Task<IActionResult> Post([FromRoute] int tenantId, [FromBody] RiskTreatmentPostView riskTreatment)
        {

            await _riskTreatmentBusiness.AddRiskTreatment(riskTreatment, UserId, tenantId);
            return Ok(string.Format(ControllerConstants.RecordCreatedMessage));

        }

        [HttpGet("{Id}")]
        public async Task<IActionResult> Get(int Id)


        {

            var riskTreatment = await _riskTreatmentBusiness.GetRiskTreatmentById(Id);
            return Ok(riskTreatment);

        }
        [HttpGet("{inherentRiskId}/RiskTreatment")]
        public async Task<IActionResult> Get([FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, [FromRoute] int inherentRiskId = 0)
        {
            var request = new GetCAList()
            {
                ListRequests = new GetListRequest
                {
                    Sort = sort,
                    Page = page,
                    PerPage = perPage,
                    SortColumn = sortColumn
                },
                ActionId = inherentRiskId
            };
            var riskTreatment = await _riskTreatmentBusiness.GetRiskTreatmentByInherentRiskId(request);
            return Ok(riskTreatment);
        }

        [HttpPut("{Id}")]
        public async Task<IActionResult> Put([FromRoute] int tenantId, int Id, [FromBody] RiskTreamentPutViewModel riskTreatment)
        {

            await _riskTreatmentBusiness.UpdateRiskTraetment(riskTreatment, Id, UserId, tenantId);
            return NoContent();

        }

        [HttpPut("{id}/review")]
        public async Task<IActionResult> ReviewTretment(CommentsForReviewViewModel commentsForReviewViewModel, [FromRoute] int tenantId, [FromRoute] int id)
        {
            await _riskTreatmentBusiness.ReviewRiskTreatment(commentsForReviewViewModel, tenantId, id, UserId);
            return NoContent();
        }



        [HttpDelete("{Id}")]
        public async Task<IActionResult> Delete([FromRoute] int tenantId, int Id)
        {

            await _riskTreatmentBusiness.DeleteRiskTreatment(Id, UserId, tenantId);
            return NoContent();

        }

        [HttpGet ("new/chart/donut")]
        public async Task<IActionResult> RiskTreatmentAllDonutChart([FromRoute] int tenantId)
        {
            var RiskTreatmentByStatus = await _chartBusiness.GetChartRiskTreatmentDounutChart(1, tenantId);           
           
            return Ok(new { RiskTreatmentByStatus });
        }
    }
}