﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Application.ViewModel.View;
using Mindflur.IMS.Business;

namespace Mindflur.IMS.API.Controllers.Risk
{
	[ApiVersion("1")]
	[Route("api/v{version:apiVersion}/tenant/{tenantId}/risk-assessment")]
	[ApiController]
	public class RiskAssesmentMasterController : BaseController
	{
		private readonly IRiskAssesmentMasterBusiness _riskAssesmentMasterBusiness;


		public RiskAssesmentMasterController(IRiskAssesmentMasterBusiness riskAssesmentMasterBusiness)
		{
			_riskAssesmentMasterBusiness = riskAssesmentMasterBusiness;
		}


		[HttpGet]
		public async Task<IActionResult>GetRiskGrid([FromQuery] string sortColumn, [FromQuery] string sort,   [FromQuery] int perPage = 10, [FromQuery] int page = 0, [FromQuery] int riskId = 0)
		{
			var request = new GetRiskAssesmentRequestList()
			{
				ListRequests = new GetListRequest()
				{
					Sort = sort,
					SortColumn = sortColumn,
					PerPage = perPage,
					Page = page
				},
				RiskId = riskId
			};
				
				
			
			
			var model = await _riskAssesmentMasterBusiness.GetRiskList(request);
			return Ok(model);
		}

		[HttpGet("risk/{riskId}")]
		public async Task<IActionResult> Preview( [FromRoute] int riskId)
		{
			var rawData = await _riskAssesmentMasterBusiness.GetRiskListByRiskId(riskId);
			return Ok(rawData);
		}


		[HttpPut("risk/{riskId}")]
		public async Task<IActionResult> UpsertRiskAssessment([FromRoute]int riskId, PostRiskAssesmentView editRiskAssessmentView)
		{
			await _riskAssesmentMasterBusiness.UpsertRiskAssessment(editRiskAssessmentView, riskId, UserId);

            return NoContent();
		}
		[HttpDelete("{id}")]
        public async Task<IActionResult> DeleteRiskAssessment([FromRoute] int id)
        {
            await _riskAssesmentMasterBusiness.DeleteRiskAssessment( id);

            return NoContent();
        }
    }
	
}

