﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Application.ViewModel.View;
using Mindflur.IMS.Business;

namespace Mindflur.IMS.API.Controllers.Risk
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}")]
    [ApiController]
    public class RiskController : BaseController
    {
        private readonly IRiskBusiness _riskBusiness;
        private readonly IChartBusiness _chartBusiness;

        public RiskController(IRiskBusiness riskManagementInherentRiskBusiness, IChartBusiness chartBusiness)
        {
            _chartBusiness = chartBusiness;

            _riskBusiness = riskManagementInherentRiskBusiness;
        }

        [HttpGet("risk/chart/donut")]
        public async Task<IActionResult> InherentRiskDonutChart([FromRoute] int tenantId, int category = 1)
        {
            if (category >= 1 && category <= 4)
            {
                var rawData = await _chartBusiness.GetChartInherentRiskDounutChart(category, tenantId);
                return Ok(rawData);
            }
            else
            {
                return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
            }
        }

        [HttpPut("risk/{workItemId}/metadata")]
        public async Task<IActionResult> UpdatePutRiskMetadata([FromRoute] int tenantId, [FromRoute] int workItemId, PutRiskMetadataViewModel putRiskMetadataViewModel)
        {
            await _riskBusiness.UpdateRiskMetaData(putRiskMetadataViewModel, workItemId, UserId, tenantId);
            return NoContent();
        }

		[HttpGet("risk/{workItemId}/metadata")]

		public async Task<IActionResult> GetRiskMetaData([FromRoute] int tenantId, [FromRoute] int workItemId)
        {
            var risk = await _riskBusiness.GetRiskMetaData(tenantId, workItemId);
          
            return Ok(risk);
        }


        [HttpPut("risk/{workItemId}/metadata/review")]

        public async Task<IActionResult> ReviewRiskMetadata(ReviewRiskMetadata reviewRiskMetadata, [FromRoute] int tenantId, [FromRoute] int workItemId)
        {
            await _riskBusiness.ReviewMetadata(reviewRiskMetadata, tenantId, workItemId, UserId);
            return NoContent();
        }


        [HttpPut("risk/{workItemId}/metadata/reject")]
        public async Task<IActionResult> rejectRiskMetadata(RejectRiskMetadata comments, [FromRoute] int tenantId, [FromRoute] int workItemId)
        {
            await _riskBusiness.RejectMetadata(comments, tenantId, workItemId, UserId);
            return NoContent();
        }

        [HttpPut("risk/{workItemId}/metadata/approve")]
        public async Task<IActionResult> CloseRiskMetadata(CloseRiskMetaData closeRsikMetaData, [FromRoute] int tenantId, [FromRoute] int workItemId)
        {
            await _riskBusiness.CloseMetadata(closeRsikMetaData, tenantId, workItemId, UserId);
            return NoContent();
        }


        [HttpGet("risk/new/chart/donut")]

        public async Task<IActionResult> InherentRiskAllDonutChart([FromRoute] int tenantId)
        {
            var InherentRiskByDepartment = await _chartBusiness.GetChartInherentRiskDounutChart(1, tenantId);
            var InherentRiskByRiskType = await _chartBusiness.GetChartInherentRiskDounutChart(2, tenantId);
            var InherentRiskByRiskStatus = await _chartBusiness.GetChartInherentRiskDounutChart(3, tenantId);
            var InherentAllRiskTreatmentByStatus = await _chartBusiness.GetChartInherentRiskDounutChart(4, tenantId);

			return Ok(new {InherentRiskByDepartment,InherentRiskByRiskType,InherentRiskByRiskStatus, InherentAllRiskTreatmentByStatus });

        }

		[HttpPut("risk/{workItemId}/riskTreatment/submit")]
		public async Task<IActionResult> submitTreatment(SubmitRiskMetaData submitRiskMetaData,  int tenantId, int workItemId)
		{
			await _riskBusiness.SubmitTreatmentMetadata(submitRiskMetaData, tenantId, workItemId, UserId);
			return NoContent();
		}

	}
}