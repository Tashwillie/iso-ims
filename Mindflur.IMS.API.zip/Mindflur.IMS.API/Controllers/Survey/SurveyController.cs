﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.Application.ViewModel.View;
using Mindflur.IMS.Data;

namespace Mindflur.IMS.API.Controllers.Survey
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/survey-master")]
    [ApiController]
    public class SurveyController : ControllerBase
    {
        private readonly IMSDEVContext _context;

        public SurveyController(IMSDEVContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Get([FromRoute] int tenantId)
        {
            var model = (from sv in _context.SurveyMasters
                         select new SurveyMasterView
                         {
                             Id = sv.Id,
                             GroupTitle = sv.GroupTitle,
                             HasComment = sv.HasComment,
                             ParentId = sv.ParentId,
                             SubGroupHasComment = sv.SubGroupHasComment,
                             Description = sv.Description
                         }).AsQueryable();

            return Ok(model);
        }
    }
}