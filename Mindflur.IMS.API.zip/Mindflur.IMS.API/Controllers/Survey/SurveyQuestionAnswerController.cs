﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Data.Models;

namespace Mindflur.IMS.API.Controllers.Survey
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/survey-que_ans")]
    [ApiController]
    public class SurveyQuestionAnswerController : BaseController
    {
        private readonly ISurveyQuetionAnswerBusiness _surveyQuetionAnswerBusiness;

        public SurveyQuestionAnswerController(ISurveyQuetionAnswerBusiness surveyQuetionAnswerBusiness)
        {
            _surveyQuetionAnswerBusiness = surveyQuetionAnswerBusiness;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var question = await _surveyQuetionAnswerBusiness.GetAllSurveyQuestionAnswe();
            return Ok(question);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] SurveyQuestionAnswer questionAnswer)
        {
            await _surveyQuetionAnswerBusiness.AddSurveyQuestionAnswe(questionAnswer);
            return Ok(string.Format(ControllerConstants.RecordCreatedMessage));
        }

        [HttpPut("{Id}")]
        public async Task<IActionResult> Put([FromRoute] int Id, [FromBody] SurveyQuestionAnswer questionAnswer)
        {
            await _surveyQuetionAnswerBusiness.UpdateSurveyQuestionAnswer(questionAnswer, Id);
            return NoContent();
        }

        [HttpGet("{surveyId}")]
        public async Task<IActionResult> GetSurveyQuestionAnswer([FromRoute] int tenantId, [FromRoute] int surveyId)
        {
            var surveylist = await _surveyQuetionAnswerBusiness.GetListForQuestionnsAndOptions(surveyId, tenantId);
            return Ok(surveylist);
        }
    }
}