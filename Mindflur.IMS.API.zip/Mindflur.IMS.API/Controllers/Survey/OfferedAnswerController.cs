﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Data.Models;

namespace Mindflur.IMS.API.Controllers.Survey
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/offered-answer")]
    [ApiController]
    public class OfferedAnswerController : ControllerBase
    {
        private readonly IOfferedAnswerMasterBusiness _offeredAnswerMasterBusiness;

        public OfferedAnswerController(IOfferedAnswerMasterBusiness offeredAnswerMasterBusiness)
        {
            _offeredAnswerMasterBusiness = offeredAnswerMasterBusiness;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var offeredAnswer = await _offeredAnswerMasterBusiness.getAllOfferedAnswer();
            return Ok(offeredAnswer);
        }

        [HttpGet("Id")]
        public async Task<IActionResult> Get(int Id)
        {
            var offeredAnswer = await _offeredAnswerMasterBusiness.getOfferedANswerById(Id);
            return Ok(offeredAnswer);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] OfferedAnswerMaster offeredAnswer)
        {
            await _offeredAnswerMasterBusiness.AddOfferedAnswer(offeredAnswer);
            return Ok(string.Format(ControllerConstants.RecordCreatedMessage));
        }

        [HttpPut]
        public async Task<IActionResult> Put(int Id, [FromBody] PutQuestionMasterView offeredAnswer)
        {
            await _offeredAnswerMasterBusiness.UpdateOfferedAnswer(offeredAnswer, Id);
            return Ok(string.Format(ControllerConstants.RecordUpdatedMessage));
        }

        [HttpDelete]
        public async Task<IActionResult> Delete(int Id)
        {
            await _offeredAnswerMasterBusiness.DeleteOfferedAnswer(Id);
            return Ok(string.Format(ControllerConstants.RecordDeletedMessage)); ;
        }
    }
}