﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.View;

namespace Mindflur.IMS.API.Controllers.Survey
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/survey-response")]
    [ApiController]
    public class SurveyResponseController : BaseController
    {
        private readonly ISurveyResponseBusiness _surveyResponseBusiness;

        public SurveyResponseController(ISurveyResponseBusiness surveyResponseBusiness)
        {
            _surveyResponseBusiness = surveyResponseBusiness;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var response = await _surveyResponseBusiness.getAllSurveyResponse();
            return Ok(response);
        }

        [HttpPut("{surveyId}")]
        public async Task<IActionResult> Post([FromBody] SurveyResponsePostView surveyResponse, [FromRoute] int surveyId)
        {
            await _surveyResponseBusiness.UpsertSurveyResponse(surveyResponse, UserId, surveyId);
            return Ok(string.Format(ControllerConstants.RecordCreatedMessage));
        }
    }
}