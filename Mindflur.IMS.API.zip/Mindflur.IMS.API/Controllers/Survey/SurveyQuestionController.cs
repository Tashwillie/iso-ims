﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.View;
using Mindflur.IMS.Business;
using Mindflur.IMS.Data.Models;

namespace Mindflur.IMS.API.Controllers.Survey
{
	[ApiVersion("1")]
	[Route("api/v{version:apiVersion}/tenant/{tenantId}/survey-questions")]
	[ApiController]
	public class SurveyQuestionController : ControllerBase
	{
		private readonly ISurveyQuestionBusiness _surveyQuestionBusiness;

		public SurveyQuestionController(ISurveyQuestionBusiness surveyQuestionBusiness)
		{
			_surveyQuestionBusiness = surveyQuestionBusiness;
		}

		[HttpPost("{surveyId}")]
		public async Task<IActionResult> Post([FromBody] SurveyQuestionPostView surveyQuestion, [FromRoute] int surveyId)
		{
			await _surveyQuestionBusiness.AddSurveyQuestion(surveyQuestion, surveyId);
			return Ok(string.Format(ControllerConstants.RecordCreatedMessage));
		}

		[HttpGet("{surveyId}")]
		public async Task<IActionResult> GetTokenList([FromRoute] int tenantId, [FromRoute] int surveyId,[FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0)
		{
			var request = new GetSuvreyQuestionList()
			{
				ListRequests = new GetListRequest
				{
					Sort = sort,
					Page = page,
					PerPage = perPage,
					SortColumn = sortColumn
				},
				
				SurveyId = surveyId

			};
			var data = await _surveyQuestionBusiness.GetAllSurveyQuestionsPaginated(request, surveyId);
			return Ok(data);
		}
		[HttpGet("preview/{surveyQuestionId}")]
		public async Task<IActionResult> preview([FromRoute] int tenantId, int surveyQuestionId)
		{
			var masterData = await _surveyQuestionBusiness.GetSurveyQuestionPreview(tenantId, surveyQuestionId);
			return Ok(masterData);
		}
		[HttpPut("{Id}")]
		public async Task<IActionResult> Put([FromRoute] int Id, [FromBody] PutQuestionbyId putQuestionbyId)
		{
			await _surveyQuestionBusiness.UpdateSurveyQuestionAnswer(putQuestionbyId, Id);
			return NoContent();
		}
		[HttpDelete("{id}")]
		public async Task<IActionResult> Delete(int id, [FromRoute] int tenantId)
		{
			await _surveyQuestionBusiness.DeleteSurveyQuestionData(id, tenantId);
			return NoContent();
		}
	}
}