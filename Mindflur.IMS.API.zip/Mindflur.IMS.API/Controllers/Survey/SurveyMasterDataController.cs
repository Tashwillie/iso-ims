﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.View;
using Mindflur.IMS.Business;

namespace Mindflur.IMS.API.Controllers.Survey
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/survey-masterData")]
    [ApiController]
    public class SurveyMasterDataController : BaseController
    {
        private readonly ISurveyMasterDatumBusiness _surveyMasterDatumBusiness;
        private readonly IChartBusiness _chartBusiness;

        public SurveyMasterDataController(ISurveyMasterDatumBusiness surveyMasterDatumBusiness, IChartBusiness chartBusiness)
        {
            _surveyMasterDatumBusiness = surveyMasterDatumBusiness;
            _chartBusiness = chartBusiness;
        }

        [HttpGet("Chart/donut/{surveyId}")]
        public async Task<IActionResult> GetChart([FromRoute] int tenantId, [FromRoute] int surveyId, int category = 1)
        {
            if (category == 1)
            {
                var rawData = await _chartBusiness.GetResponseBySurveyQuestionId(category, surveyId, tenantId);
                return Ok(rawData);
            }
            else
            {
                return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
            }
        }

        [HttpGet]
        public async Task<IActionResult> Get([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0)
        {
            var request = new GetSurveyListRequest()
            {
                ListRequests = new GetListRequest()
                {
                    Sort = sort,
                    SortColumn = sortColumn,
                    PerPage = perPage,
                    Page = page
                },
                TenantId = tenantId
            };
            var surveyData = await _surveyMasterDatumBusiness.getAllSurveyData(request);
            return Ok(surveyData);
        }

        [HttpGet("user/list")]
        public async Task<IActionResult> GetListForUser([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0)
        {
            var request = new GetSurveyListRequest()
            {
                ListRequests = new GetListRequest()
                {
                    Sort = sort,
                    SortColumn = sortColumn,
                    PerPage = perPage,
                    Page = page
                },
                TenantId = tenantId,
                CreatedBy = UserId
            };
            var surveyData = await _surveyMasterDatumBusiness.getAllSurveyData(request);
            return Ok(surveyData);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] SurveyMasterPostView masterDatum, [FromRoute] int tenantId)
        {
            await _surveyMasterDatumBusiness.AddSurveyDatas(masterDatum, UserId, tenantId);
            return Ok(string.Format(ControllerConstants.RecordCreatedMessage));
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put([FromRoute] int id, [FromRoute] int tenantId, [FromBody] SurveyMasterDataUpdateView masterDatum)
        {
            await _surveyMasterDatumBusiness.UpdateSurveyDatas(masterDatum, id, UserId, tenantId);
            return NoContent();
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id, [FromRoute] int tenantId)
        {
            var masterData = await _surveyMasterDatumBusiness.GetSurveyDataById(id, tenantId);
            return Ok(masterData);
        }

        [HttpGet("preview/{id}")]
        public async Task<IActionResult> preview( [FromRoute] int tenantId, int id)
        {
            var masterData = await _surveyMasterDatumBusiness.GetSurveyDataPreviewById( tenantId, id);
            return Ok(masterData);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id, [FromRoute] int tenantId)
        {
            await _surveyMasterDatumBusiness.DeleteSurveyData(id, UserId, tenantId);
            return NoContent();
        }

        [HttpGet("QuestionsBySurveyId/{id}")]
        public async Task<IActionResult> GetQuestions([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, [FromRoute] int id
            =0)
        {
            var request = new GetSurveyListRequest()
            {
                ListRequests = new GetListRequest()
                {
                    Sort = sort,
                    SortColumn = sortColumn,
                    PerPage = perPage,
                    Page = page
                },
                TenantId = tenantId
            };
            var rawData = await _surveyMasterDatumBusiness.getQuestionBySurveyId(request, id);
            return Ok(rawData);
        }

        [HttpGet("surveyResponseBySurveyId/{id}")]
        public async Task<IActionResult> GetSurveyResponse([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, [FromRoute] int id = 0)
        {
            var request = new GetSurveyListRequest()
            {
                ListRequests = new GetListRequest()
                {
                    Sort = sort,
                    SortColumn = sortColumn,
                    PerPage = perPage,
                    Page = page
                },
                TenantId = tenantId
            };
            var rawData = await _surveyMasterDatumBusiness.getSurveyResponseBySurveyId(request, id);
            return Ok(rawData);
        }

        [HttpGet("ResponsesBySurveyId/{Id}")]
        public async Task<IActionResult> GetBySurveyId([FromRoute] int tenantId, [FromRoute] int Id)
        {
            var rawData = await _surveyMasterDatumBusiness.getResponseBySurveyId(Id, tenantId);
            return Ok(rawData);
        }

        [HttpGet("Chart/donut/survey")]
        public async Task<IActionResult> GetChart([FromRoute] int tenantId, int category = 1)
        {
            if (category >= 1 && category < 4)
            {
                var rawData = await _chartBusiness.GetDonutForSurveyMasterData(category, tenantId);
                return Ok(rawData);
            }
            else
            {
                return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
            }
        }
        [HttpPut("Survey-Master/{SurveyId}/submit")]
        public async Task<IActionResult> SubmitSurveyMaster(int tenantId, int SurveyId, ApproveSurveyMaster comment)
        {
            await _surveyMasterDatumBusiness.SubmitSurveyMaster(comment,tenantId, SurveyId, UserId);
            return NoContent();
        }
        [HttpPut("Survey-Master/{SurveyId}/approve")]
        public async Task<IActionResult> ApproveSurveyMaster(ApproveSurveyMaster comment, int tenantId, int SurveyId)
        {
            await _surveyMasterDatumBusiness.ApproveSurveyMaster(comment, tenantId, SurveyId, UserId);
            return NoContent();
        }

        [HttpPut("Survey-Master/{SurveyId}/reject")]
        public async Task<IActionResult> RejectSurveyMaster(ApproveSurveyMaster comment, int tenantId, int SurveyId)
        {
            await _surveyMasterDatumBusiness.RejectSurveyMaster(comment, tenantId, SurveyId, UserId);
            return NoContent();
        }
		/*[HttpGet("GetSupplierReportDetail/{SurveyId}")]
        public async Task<IActionResult> GetSupplierReportDetails([FromRoute] int SurveyId, [FromRoute] int tenantId)
        {
            var rawData = await _surveyMasterDatumBusiness.GetSupplierReportDetails(SurveyId, tenantId);
            return Ok(rawData);
        }*/

		
		[HttpGet("Survey-Master/{SurveyId}/chart/donut")]
		public async Task<IActionResult> GetSurveyMasterResponceDonutChart([FromRoute] int SurveyId, [FromRoute] int tenantId)
        {
            var TotalMAxResponse = await _chartBusiness.GetSurveyMasterResponceDonutChart(1,SurveyId, tenantId);
			var TotalMinResponse = await _chartBusiness.GetSurveyMasterResponceDonutChart(2, SurveyId, tenantId);
            return Ok (new {  TotalMAxResponse, TotalMinResponse });
		}
	}
}