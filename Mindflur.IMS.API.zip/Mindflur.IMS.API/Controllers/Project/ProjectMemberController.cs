﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Data.Models;

namespace Mindflur.IMS.API.Controllers.Project
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/project-member")]
    [ApiController]
    public class ProjectMemberController : ControllerBase
    {
        private readonly IProjectMemberBusiness _projectMemberBusiness;

        public ProjectMemberController(IProjectMemberBusiness projectMemberBusiness)
        {
            _projectMemberBusiness = projectMemberBusiness;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var member = await _projectMemberBusiness.GetAllMembers();
            return Ok(member);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] ProjectMember projectMember)
        {
            await _projectMemberBusiness.AddProjectMember(projectMember);
            return Ok(string.Format(ControllerConstants.RecordCreatedMessage));
        }

        [HttpPut]
        public async Task<IActionResult> Put(int Id, [FromBody] PutProjectMember projectMember)
        {
            await _projectMemberBusiness.UpdateProjectMember(projectMember, Id);
            return Ok(string.Format(ControllerConstants.RecordUpdatedMessage));
        }

        [HttpGet("Id")]
        public async Task<IActionResult> Get(int Id)
        {
            var member = await _projectMemberBusiness.GetMembersById(Id);
            return Ok(member);
        }

        [HttpDelete]
        public async Task<IActionResult> Delete(int Id)
        {
            await _projectMemberBusiness.DeleteProjectMember(Id);
            return Ok(string.Format(ControllerConstants.RecordDeletedMessage));
        }
    }
}