﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Application.ViewModel.View;

namespace Mindflur.IMS.API.Controllers.Project
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/projects")]
    [ApiController]
    public class ProjectMetaDataController : BaseController
    {
        private readonly IProjectsBusiness _projectsBusiness;
        private readonly IChartBusiness _chartBusiness;

        public ProjectMetaDataController(IProjectsBusiness projectsBusiness, IChartBusiness chartBusiness)
        {
            _chartBusiness = chartBusiness;
            _projectsBusiness = projectsBusiness;
        }

        [HttpGet("chart/donut")]
        public async Task<IActionResult> ProjectDonutChart([FromRoute] int tenantId, int category = 1)
        {
            if (category >= 1 && category < 4)
            {
                var rawData = await _chartBusiness.GetChartProjectManagementDounutChart(category, tenantId);
                return Ok(rawData);
            }
            else
            {
                return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
            }
        }

        [HttpGet("task/status/chart/donut")]
        public async Task<IActionResult> ProjectTaskStatusDonutChart([FromRoute] int tenantId, int category = 1)
        {
            if (category == 1)
            {
                var rawData = await _chartBusiness.GetProjectTaskStatusDounutChart(category, tenantId);
                return Ok(rawData);
            }
            else
            {
                return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
            }
        }

       

       

        [HttpGet("{workItemId}/metadata")]
        public async Task<IActionResult> Get([FromRoute] int tenantId, int workItemId)
        {
            var project = await _projectsBusiness.GetProjectMetaData(workItemId, tenantId);
            return Ok(project);
        }

        [HttpPut("{workItemId}/metadata")]
        public async Task<IActionResult> Put([FromRoute] int tenantId, [FromRoute] int workItemId, [FromBody] PutProjectmanagementView putProject)
        {
            await _projectsBusiness.UpdateProjectMetaData(putProject, workItemId, UserId, tenantId);
            return NoContent();
        }


        [HttpGet("new/chart/donut")]
        public async Task<IActionResult> AllDonutChart([FromRoute] int tenantId)
        {
            var ProjectsByStatus = await _chartBusiness.GetChartProjectManagementDounutChart(1,tenantId);
            var ProjectsByPriority = await _chartBusiness.GetChartProjectManagementDounutChart(2, tenantId);
            var ProjectByPhase = await _chartBusiness.GetChartProjectManagementDounutChart(4, tenantId);
            var ProjectByTask = await _chartBusiness.GetChartProjectManagementDounutChart(5, tenantId);



			return Ok(new { ProjectsByStatus, ProjectsByPriority, ProjectByPhase, ProjectByTask });
        }

    }
}