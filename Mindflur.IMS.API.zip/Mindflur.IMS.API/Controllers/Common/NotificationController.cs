﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.API.Notification;
using Mindflur.IMS.Application.ViewModel.Core;

namespace Mindflur.IMS.API.Controllers.Common
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/notification")]
    public class NotificationController : BaseController
    {
        private readonly IHubContext<NotificationsHub> _hubContext;

        public NotificationController(IHubContext<NotificationsHub> hubContext)
        {
            _hubContext = hubContext;
        }

        [HttpPut("test/notify")]
        public async Task<IActionResult> PublishNotification(NotificationMessage notificationMessage)
        {
            await _hubContext.Clients
               .Group(notificationMessage.SourceIdUserId.ToString())
               .SendAsync("Notify", notificationMessage);

            return NoContent();
        }
    }
}