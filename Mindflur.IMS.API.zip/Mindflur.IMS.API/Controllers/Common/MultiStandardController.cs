﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Data;
using Mindflur.IMS.Data.Models;

namespace Mindflur.IMS.API.Controllers.Common
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/multi-standard")]
    [ApiController]
    public class MultiStandardController : ControllerBase
    {
        private readonly IMSDEVContext _context;

        public MultiStandardController(IMSDEVContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var multiStandards = await _context.ProgramStandards.ToListAsync();
            return Ok(multiStandards);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] ProgramStandard programStandard)
        {
            await _context.ProgramStandards.AddAsync(programStandard);
            await _context.SaveChangesAsync();
            return Ok(programStandard);
        }

        [HttpGet("{Id}")]
        public async Task<IActionResult> Get(int Id)
        {
            var multi = await _context.ProgramStandards.FindAsync(Id);
            return multi == null ? NotFound(string.Format(ControllerConstants.IdNotFoundErrorMessage)) : Ok(multi);
        }

        [HttpPut("{Id}")]
        public async Task<IActionResult> Put(int Id, [FromBody] ProgramStandard programStandard)
        {
            var programStandards = await _context.ProgramStandards.FindAsync(Id);
            if (programStandards == null)
            {
                return NotFound(string.Format(ControllerConstants.IdNotFoundErrorMessage));
            }
            else
            {
                programStandards.MasterDataStandardId = programStandard.MasterDataStandardId;
                programStandards.AuditProgramId = programStandard.AuditProgramId;
                await _context.SaveChangesAsync();
                return NoContent();
            }
        }

        [HttpDelete("{Id}")]
        public async Task<IActionResult> Delete(int Id)
        {
            var multi = await _context.ProgramStandards.FindAsync(Id);
            if (multi == null)
            {
                return NotFound(string.Format(ControllerConstants.IdNotFoundErrorMessage));
            }
            else
            {
                _context.ProgramStandards.Remove(multi);
                await _context.SaveChangesAsync();
                return Ok(string.Format(ControllerConstants.IdDeletedErrorMessage));
            }
        }
    }
}