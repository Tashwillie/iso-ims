﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.View;

namespace Mindflur.IMS.API.Controllers.Common
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/master/data")]
    [ApiController]
    public class MasterDataController : ControllerBase
    {
        private readonly IMasterDataBusiness _masterDataBusiness;

        public MasterDataController(IMasterDataBusiness masterDataBusiness)
        {
            _masterDataBusiness = masterDataBusiness;
        }

        [HttpGet("list")]
        public async Task<IActionResult> getListOfMasterData([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, int? masterDataGroupId = 0)
        {
            var request = new GetMasterDataList()
            {
                ListRequests = new GetListRequest
                {
                    Sort = sort,
                    Page = page,
                    PerPage = perPage,
                    SortColumn = sortColumn
                },
                TenantId = tenantId,
                MasterDataGroupId = masterDataGroupId
            };
            var masterDataList = await _masterDataBusiness.getMasterDataList(request);
            return Ok(masterDataList);
        }

        [HttpGet]
        public async Task<IActionResult> Get([FromRoute] int tenantId)
        {
            var rawData = await _masterDataBusiness.GetMasterData(tenantId);
            return Ok(rawData);
        }



        [HttpGet("{Id}")]
        public async Task<IActionResult> Get([FromRoute] int tenantId, int masterDataGroupId)
        {
            var task = await _masterDataBusiness.GetMasterDataById(masterDataGroupId, tenantId);
            return Ok(task);
        }

        [HttpPut("{Id}")]
        public async Task<IActionResult> Put([FromRoute] int tenantId, int Id, [FromBody] MasterDataView masterDataView)
        {
            await _masterDataBusiness.UpdateMasterData(masterDataView, Id, tenantId);
            return NoContent();
        }

        [HttpDelete("{Id}")]
        public async Task<IActionResult> Delete([FromRoute] int tenantId, int Id)
        {
           
            return NoContent();
        }

        [HttpGet("MasterGroupId/{masterDataGroupId}")]
        public async Task<IActionResult> getDataByGroupId([FromRoute] int tenantId, int masterDataGroupId)
        {
            var rawData = await _masterDataBusiness.getDataByMasterGroupId(tenantId, masterDataGroupId);
            return Ok(rawData);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromRoute] int tenantId, MasterDataView masterDataView)
        {
            await _masterDataBusiness.addMasterData(masterDataView, tenantId);
            return Ok(string.Format(ControllerConstants.RecordCreatedMessage));
        }

        [HttpGet("preview/{Id}")]
        public async Task<IActionResult> Preview([FromRoute] int tenantId, int Id)
        {
            var rawData = await _masterDataBusiness.getPreviewData(tenantId, Id);
            return Ok(rawData);
        }
    }
}