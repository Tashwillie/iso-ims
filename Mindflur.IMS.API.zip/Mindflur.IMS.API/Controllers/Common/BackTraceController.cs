﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;

namespace Mindflur.IMS.API.Controllers.Common
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/trace")]
    [ApiController]
    public class BackTraceController : BaseController
    {
       

        public BackTraceController()
        {
           
        }

    }
}