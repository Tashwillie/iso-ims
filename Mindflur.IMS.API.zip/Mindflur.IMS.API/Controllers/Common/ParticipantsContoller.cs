﻿using Microsoft.AspNetCore.Mvc;

namespace Mindflur.IMS.API.Controllers.Common
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}")]
    [ApiController]
    public class ParticipantsContoller : ControllerBase
    {
        

        public ParticipantsContoller()
        {
           
        }
    }
}