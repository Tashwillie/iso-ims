﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.ViewModel.View;

namespace Mindflur.IMS.API.Controllers.Common
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/activityLog")]
    [ApiController]
    public class ActivityLogController : BaseController
    {
        private readonly IActivityLogBusiness _activityLogBusiness;

        public ActivityLogController(IActivityLogBusiness activityLogBusiness)
        {
            _activityLogBusiness = activityLogBusiness;
        }

        [HttpGet("list")]
        public async Task<IActionResult> GetActivityLogs([FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, [FromRoute] int tenantId = 0, int? controllerId = 0, int? actionId = 0, int? entityId = 0, DateTime? startDate = null, DateTime? endDate = null)
        {
            var requestModel = new ListActivityRequestModel()
            {
                GridProperties = new GetListRequest()
                {
                    Sort = sort,
                    SortColumn = sortColumn,
                    PerPage = perPage,
                    Page = page
                },
                TenatId = tenantId,
                ControllerId = controllerId,
                ActionId = actionId,
                EntityId = entityId,
                StartDate = startDate,
                EndDate = endDate
            };

            var logs = await _activityLogBusiness.GetActivityLogs(requestModel);
            return Ok(logs);
        }

        [HttpGet("{activityLogId}")]
        public async Task<IActionResult> GetActivityLogById([FromRoute] int activityLogId)
        {
            var logs = await _activityLogBusiness.GetActivityLogById(activityLogId);
            return Ok(logs);
        }

        [HttpGet("controllerList")]
        public async Task<IActionResult> GetController()
        {
            var controllers = await _activityLogBusiness.ControllerList();
            return Ok(controllers);
        }

        [HttpGet("actionList")]
        public async Task<IActionResult> GetAction()
        {
            var actions = await _activityLogBusiness.ActionList();
            return Ok(actions);
        }

        [HttpGet("controller/{controllerId}/action/{actionId}")]
        public async Task<IActionResult> GetEntitiy([FromRoute] int tenantId, [FromRoute] int controllerId, [FromRoute] int actionId)
        {
            var entityList = await _activityLogBusiness.EntitiyList(controllerId, actionId, tenantId);
            return Ok(entityList);
        }
    }
}