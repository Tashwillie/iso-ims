﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.Application.Contracts.Business;

namespace Mindflur.IMS.API.Controllers.Common
{
    [Route("api/v{version:apiVersion}")]
    [ApiController]
    public class PublicOnlyController : ControllerBase
    {
        private readonly ITenantThemeBusiness _tenantThemeBusiness;

        public PublicOnlyController(ITenantThemeBusiness tenantThemeBusiness)
        {
            //Note: PublicOnlyController would never have any authentication
            _tenantThemeBusiness = tenantThemeBusiness;
        }

        [HttpGet("tenant/{shortCode}/theme")]
        [ResponseCache(Duration = 86400, Location = ResponseCacheLocation.Any, NoStore = false)]
        public async Task<IActionResult> Get([FromRoute] string shortCode)
        {
            var rawData = await _tenantThemeBusiness.GetThemeByShortCode(shortCode);
            return Ok(rawData);
        }
    }
}