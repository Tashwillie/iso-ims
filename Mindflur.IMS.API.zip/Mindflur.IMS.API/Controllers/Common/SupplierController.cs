﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Application.ViewModel.View;

namespace Mindflur.IMS.API.Controllers.Common
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/supplier-master")]
    [ApiController]
    public class SupplierController : BaseController
    {
        private readonly ISupplierMasterBusiness _supplierMasterBusiness;
        private readonly IChartBusiness _chartBusiness;

        public SupplierController(ISupplierMasterBusiness supplierMasterBusiness, IChartBusiness chartBusiness)
        {
            _supplierMasterBusiness = supplierMasterBusiness;
            _chartBusiness = chartBusiness;
        }

        [HttpGet]
        public async Task<IActionResult> Get([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0)
        {
            var request = new GetSupplierListRequest()
            {
                ListRequests = new GetListRequest()
                {
                    Sort = sort,
                    SortColumn = sortColumn,
                    PerPage = perPage,
                    Page = page
                },
                TenantId = tenantId
            };
            var supplier = await _supplierMasterBusiness.getAllSupplierDetails(request);
            return Ok(supplier);
        }

        [HttpGet("departmentId/list")]
        public async Task<IActionResult> GetSurveyGridByUser([FromRoute] int tenantId, [FromRoute] int departmentId,  [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0)
        {
            var request = new GetSupplierListRequest()
            {
                ListRequests = new GetListRequest()
                {
                    Sort = sort,
                    SortColumn = sortColumn,
                    PerPage = perPage,
                    Page = page
                },
                TenantId = tenantId,
                ForUserId = UserId,
                DepartmentId = departmentId
            };
            var supplier = await _supplierMasterBusiness.getAllSupplierDetails(request);
            return Ok(supplier);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id, [FromRoute] int tenantId)
        {
            var supplier = await _supplierMasterBusiness.getAllSupplierDetailById(id, tenantId);
            return Ok(supplier);
        }

        [HttpGet("Preview/{id}")]
        public async Task<IActionResult> Preview(int id, [FromRoute] int tenantId)
        {
            var supplier = await _supplierMasterBusiness.getSupplierPreviewById(id, tenantId);
            return Ok(supplier);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] PostSupplierView postSupplierView, [FromRoute] int tenantId)
        {
            await _supplierMasterBusiness.AddSupplierDetails(postSupplierView, UserId, tenantId);
            return Ok("Created");
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> put(int id, [FromBody] PutSupplierView supplierMaster, [FromRoute] int tenantId)
        {
            await _supplierMasterBusiness.UpdateSupplierDetails(id, supplierMaster, UserId, tenantId);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id, [FromRoute] int tenantId)
        {
            await _supplierMasterBusiness.deleteSupplierDetails(id, UserId, tenantId);
            return NoContent();
        }

        [HttpGet("dropdown")]
        public async Task<IActionResult> GetSupplierDropdown([FromRoute] int tenantId)
        {
            var suppliers = await _supplierMasterBusiness.GetSupplierDropDown(tenantId);
            return Ok(suppliers);
        }

        [HttpGet("landingPageCharts")]
        public async Task<IActionResult> GetCharts([FromRoute] int tenantId, int category = 1)
        {
            if (category >= 1 && category < 4)
            {
                var suppliers = await _chartBusiness.GetSupplierCharts(category, tenantId);
                return Ok(suppliers);
            }
            else
            {
                return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
            }
        }
    }
}