﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;

namespace Mindflur.IMS.API.Controllers.Common
{
	[ApiVersion("1")]
	[Route("api/v{version:apiVersion}/tenant/{tenantId}/opportunities")]
	[ApiController]
	public class OpportunitiesController : BaseController
	{
		private readonly IOpportunitiesMasterBusiness _opportunitiesMasterBusiness;

		public OpportunitiesController(IOpportunitiesMasterBusiness opportuniesMasterBusiness)
		{
			_opportunitiesMasterBusiness = opportuniesMasterBusiness;
		}

		[HttpGet("dropdown")]
		public async Task<IActionResult> GetDropDown([FromRoute] int tenantId)
		{
			var opportunities = await _opportunitiesMasterBusiness.GetDropDown(tenantId);
			return Ok(opportunities);
		}

		[HttpGet("{id}")]
		public async Task<IActionResult> GetById([FromRoute] int id, [FromRoute] int tenantId)
		{
			var opportunities = await _opportunitiesMasterBusiness.GetOpportunitiesById(id, tenantId);
			return Ok(opportunities);
		}
	}
}