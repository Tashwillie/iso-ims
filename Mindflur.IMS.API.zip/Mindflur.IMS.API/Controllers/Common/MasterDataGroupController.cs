﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Data;
using Mindflur.IMS.Data.Models;

namespace Mindflur.IMS.API.Controllers.Common
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/master-dataGroup")]
    [ApiController]
    public class MasterDataGroupController : ControllerBase
    {
        private readonly IMSDEVContext _context;

        public MasterDataGroupController(IMSDEVContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var masterDataGroups = await (from masterDataGroup in _context.MasterDataGroups
                                          select new
                                          {
                                              masterDataGroup.Id,
                                              masterDataGroup.Name,
                                          }).ToListAsync();
            return Ok(masterDataGroups);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] MasterDataGroup masterDataGroup)
        {
            await _context.MasterDataGroups.AddAsync(masterDataGroup);
            await _context.SaveChangesAsync();
            return StatusCode(StatusCodes.Status201Created);
        }

        [HttpGet("{Id}")]
        public async Task<IActionResult> Get(int Id)
        {
            var masterDataGroups = await _context.MasterDataGroups.FindAsync(Id);
            return masterDataGroups == null ? NotFound(string.Format(ControllerConstants.UnsupportedIdForDatabase)) : Ok(masterDataGroups);
        }

        [HttpPut("{Id}")]
        public async Task<IActionResult> Put(int Id, [FromBody] MasterDataGroup masterDataGroup)
        {
            var masterDataGroups = await _context.MasterDataGroups.FindAsync(Id);
            if (masterDataGroups == null)
            {
                return NotFound(string.Format(ControllerConstants.UnsupportedIdForDatabase));
            }
            else
            {
                masterDataGroups.Name = masterDataGroup.Name;
                await _context.SaveChangesAsync();
                return NoContent();
            }
        }

        [HttpDelete("{Id}")]
        public async Task<IActionResult> Delete(int Id)
        {
            var masterDataGroup = await _context.MasterDataGroups.FindAsync(Id);
            if (masterDataGroup == null)
            {
                return NotFound(string.Format(ControllerConstants.NoRecordsForIdErrorMessage));
            }
            else
            {
                _context.MasterDataGroups.Remove(masterDataGroup);
                await _context.SaveChangesAsync();
                return Ok(string.Format(ControllerConstants.RecordDeletedMessage));
            }
        }
    }
}