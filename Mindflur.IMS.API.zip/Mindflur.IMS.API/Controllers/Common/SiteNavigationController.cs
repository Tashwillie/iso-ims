﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Data;
using Mindflur.IMS.Data.Models;

namespace Mindflur.IMS.API.Controllers.Common
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/navigation")]
    [ApiController]
    public class SiteNavigationController : ControllerBase
    {
        private readonly IMSDEVContext _context;

        public SiteNavigationController(IMSDEVContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var navigation = await _context.SiteNavigations.ToListAsync();
            return Ok(navigation);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] SiteNavigation navigation)
        {
            await _context.SiteNavigations.AddAsync(navigation);
            await _context.SaveChangesAsync();
            return Ok(navigation);
        }

        [HttpGet("{Id}")]
        public async Task<IActionResult> Get(int Id)
        {
            var navigation = await _context.SiteNavigations.FindAsync(Id);
            return navigation == null ? NotFound(string.Format(ControllerConstants.IdNotFoundErrorMessage)) : Ok(navigation);
        }

        [HttpPut("{Id}")]
        public async Task<IActionResult> Post(int Id, [FromBody] SiteNavigation navigation)
        {
            var navigations = await _context.SiteNavigations.FindAsync(Id);
            if (navigations == null)
            {
                return NotFound(string.Format(ControllerConstants.IdNotFoundErrorMessage));
            }
            else
            {
                navigations.NavigationId = navigation.NavigationId;
                navigations.Header = navigation.Header;
                navigations.Title = navigation.Title;
                navigations.NavigationLink = navigation.NavigationLink;
                navigations.Actions = navigation.Actions;
                navigations.Resource = navigation.Resource;
                await _context.SaveChangesAsync();
                return NoContent();
            }
        }

        [HttpDelete("{Id}")]
        public async Task<IActionResult> Delete(int Id)
        {
            var navigations = await _context.SiteNavigations.FindAsync(Id);
            if (navigations == null)
            {
                return NotFound(string.Format(ControllerConstants.IdNotFoundErrorMessage));
            }
            else
            {
                _context.SiteNavigations.Remove(navigations);
                await _context.SaveChangesAsync();
                return NoContent();
            }
        }
    }
}