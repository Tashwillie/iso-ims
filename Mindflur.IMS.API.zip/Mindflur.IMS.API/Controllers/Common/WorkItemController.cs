﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.Core.Enums;
using Mindflur.IMS.Application.ViewModel.View;

namespace Mindflur.IMS.API.Controllers.Common
{
	[ApiVersion("1")]
	[Route("api/v{version:apiVersion}/tenant/{tenantId}/work-item")]
	[ApiController]
	[Authorize]
	public class WorkItemController : BaseController
	{
		private readonly IWorkItemBusiness _workItemBusiness;
		private readonly IInternalAuditBusiness _internalAuditBusiness;
		private readonly IChartBusiness _chartBusiness;

		public WorkItemController(IWorkItemBusiness workItemBusiness, IChartBusiness chartBusiness, IInternalAuditBusiness internalAuditBusiness)
		{
			_workItemBusiness = workItemBusiness;
			_internalAuditBusiness = internalAuditBusiness;
			_chartBusiness = chartBusiness;
		}

		[HttpPost("internal-audit/{sourceItemId}")]
		public async Task<IActionResult> AddFindingsPost([FromRoute] int tenantId, [FromRoute] int sourceItemId, FindingPostView findingPostView)
		{
			await _workItemBusiness.AddFinding(findingPostView, sourceItemId, UserId, tenantId, HttpContext.Request.Path);
			return NoContent();
		}

		[HttpPost]
		public async Task<IActionResult> WorkitemPost([FromRoute] int tenantId, WorkItemPostView workitemPostView)
		{
			await _workItemBusiness.AddWorkitem(workitemPostView, UserId, tenantId, HttpContext.Request.Path);
			return NoContent();
		}

		[HttpGet("internal-audit/{internalAuditId}/previous")]
		public async Task<IActionResult> GetPastWorkItems([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromRoute] int internalAuditId, [FromQuery] int perPage = 10, [FromQuery] int page = 0)
		{
			var actualStartDate = await _internalAuditBusiness.GetAuditCreatedDate(internalAuditId);

			var auditprogramId = await _internalAuditBusiness.GetAuditIdFromCreatedOnDate((DateTime)actualStartDate.AuditStartDate);
			var request = new GetWorkItemGridRequest()
			{
				ListRequests = new GetListRequest()
				{
					Sort = sort,
					SortColumn = sortColumn,
					PerPage = perPage,
					Page = page
				},

				TenantId = tenantId,
				SourceId = (int)IMSModules.InternalAudit,
				AuditActualStart = actualStartDate.AuditStartDate,
				AuditCreatedOn = actualStartDate.CreatedOn,
				SourceItemId = auditprogramId.AuditId
			};
			var model = await _workItemBusiness.GetPastWorkItemList(request);

			return Ok(model);
		}

		[HttpGet]
		public async Task<IActionResult> Get([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, int sourceId = 0, int sourceItemId = 0, [FromQuery] int categoryId = 0)
		{
			var request = new GetWorkItemGridRequest()
			{
				ListRequests = new GetListRequest()
				{
					Sort = sort,
					SortColumn = sortColumn,
					PerPage = perPage,
					Page = page
				},

				TenantId = tenantId,
				SourceId = sourceId,
				SourceItemId = sourceItemId,
				CategoryId = categoryId
			};

			var model = await _workItemBusiness.GetWorkItemList(request);

			return Ok(model);
		}

		[HttpGet("assignedUser")]
		public async Task<IActionResult> GetAssignedUserList([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, int sourceId = 0, int sourceItemId = 0, [FromQuery] int categoryId = 0)
		{
			var request = new GetWorkItemGridRequest()
			{
				ListRequests = new GetListRequest()
				{
					Sort = sort,
					SortColumn = sortColumn,
					PerPage = perPage,
					Page = page
				},

				TenantId = tenantId,
				SourceId = sourceId,
				SourceItemId = sourceItemId,
				AssignTo = UserId,
				CategoryId = categoryId
			};

			var model = await _workItemBusiness.GetWorkItemList(request);

			return Ok(model);
		}

		[HttpGet("ownedUser")]
		public async Task<IActionResult> GetOwnedUserList([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, int sourceId = 0, int sourceItemId = 0, [FromQuery] int categoryId = 0)
		{
			var request = new GetWorkItemGridRequest()
			{
				ListRequests = new GetListRequest()
				{
					Sort = sort,
					SortColumn = sortColumn,
					PerPage = perPage,
					Page = page
				},

				TenantId = tenantId,
				SourceId = sourceId,
				SourceItemId = sourceItemId,
				CreatedBy = UserId,
				CategoryId = categoryId
			};

			var model = await _workItemBusiness.GetWorkItemList(request);

			return Ok(model);
		}

		[HttpGet("workItembyUserId")]
		public async Task<IActionResult> GetUserList([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, int sourceId = 0, int sourceItemId = 0, int userId = 0, [FromQuery] int categoryId = 0)
		{
			var request = new GetWorkItemGridRequest()
			{
				ListRequests = new GetListRequest()
				{
					Sort = sort,
					SortColumn = sortColumn,
					PerPage = perPage,
					Page = page
				},

				TenantId = tenantId,
				SourceId = sourceId,
				SourceItemId = sourceItemId,
				UserId = userId,
				CategoryId = categoryId
			};

			var model = await _workItemBusiness.GetWorkItemList(request);

			return Ok(model);
		}

		[HttpPut("{workItemId}")]
		public async Task<IActionResult> Put([FromRoute] int tenantId, [FromRoute] int workItemId, WorkItemPutView workItemPutView)
		{
			await _workItemBusiness.UpdateWorkItem(workItemPutView, UserId, workItemId, tenantId, HttpContext.Request.Path);
			return NoContent();
		}

		[HttpPut("{workItemId}/risk")]
		public async Task<IActionResult> PutDetails([FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			await _workItemBusiness.AddNcToRisk(tenantId, workItemId, UserId, HttpContext.Request.Path);
			return NoContent();
		}

		[HttpGet("{workItemId}/preview")]
		public async Task<IActionResult> Preview([FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			var rawData = await _workItemBusiness.GetPreviewWorkItem(workItemId, tenantId);
			return Ok(rawData);
		}

		[HttpDelete("{workItemId}")]
		public async Task<IActionResult> Delete([FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			await _workItemBusiness.DeleteWorkItem(workItemId, UserId, tenantId);
			return NoContent();
		}

		[HttpGet("Donutchart")]
		public async Task<IActionResult> GetChart([FromRoute] int tenantId, int sourceId, int category = 1)
		{
			if (category >= 1 && category < 5)
			{
				var rawData = await _chartBusiness.GetWorkItemStatus(category, sourceId, tenantId);
				return Ok(rawData);
			}
			else
			{
				return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
			}
		}

		[HttpGet("nonconformance/dropdown")]
		public async Task<IActionResult> GetNcDropDown([FromRoute] int tenantId)
		{
			var rawData = await _workItemBusiness.GetNcDropDown(tenantId);
			return Ok(rawData);
		}

		[HttpGet("incident/dropdown")]
		public async Task<IActionResult> GetIncidentDropDown([FromRoute] int tenantId)
		{
			var rawData = await _workItemBusiness.GetIncidentDropDown(tenantId);
			return Ok(rawData);
		}	
	}
}