﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Application.ViewModel.View;

namespace Mindflur.IMS.API.Controllers.Common
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/controller")]
    [ApiController]
    public class ControllerMasterController : BaseController
    {
        private readonly IControllerMasterBusiness _controllerMasterBusiness;

        public ControllerMasterController(IControllerMasterBusiness controllerMasterBusiness)
        {
            _controllerMasterBusiness = controllerMasterBusiness;
        }

        [HttpGet("list")]
        public async Task<IActionResult> Get([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0)
        {
            var request = new GetControllerListRequest()
            {
                ListRequests = new GetListRequest()
                {
                    Sort = sort,
                    SortColumn = sortColumn,
                    PerPage = perPage,
                    Page = page
                },
                TenantId = tenantId
            };
            var model = await _controllerMasterBusiness.GetControllerList(request);
            return Ok(model);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromRoute] int tenantId, [FromBody] PostControllerView controllerMaster)
        {
            await _controllerMasterBusiness.AddController(controllerMaster, tenantId);
            return Ok();
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetControllerById([FromRoute] int tenantId, [FromRoute] int id)
        {
            var controller = await _controllerMasterBusiness.GetControllerById(tenantId, id);
            return Ok(controller);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put([FromRoute] int tenantId, [FromRoute] int id, [FromBody] PostControllerView controller)
        {
            await _controllerMasterBusiness.UpdateController(controller, tenantId, id);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete([FromRoute] int tenantId, [FromRoute] int id)
        {
            await _controllerMasterBusiness.DeleteController(tenantId, id);
            return NoContent();
        }
    }
}