﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel;
using Mindflur.IMS.Application.ViewModel.View;
using Mindflur.IMS.Business;

namespace Mindflur.IMS.API.Controllers.Common
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}")]
    [ApiController]
    public class TokenController : BaseController
    {
        private readonly ICommonTokenBusiness _tokenbusiness;
        public TokenController(ICommonTokenBusiness tokenBusiness)
        {
            _tokenbusiness= tokenBusiness;
        }

        [HttpGet("token/list")]
        public async Task<IActionResult> GetTokenList([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, int? parentTokenId = 0)
        {
            var request = new GetTokenListRequest()
            {
                ListRequests = new GetListRequest
                {
                    Sort = sort,
                    Page = page,
                    PerPage = perPage,
                    SortColumn = sortColumn
                },
               
                ParentTokenId = parentTokenId
            };
            var data = await _tokenbusiness.GetAllTokenByTenantId(request);
            return Ok(data);
        }

        [HttpGet("token/{parentTokenId}")]
        public async Task<IActionResult> GetTokens([FromRoute] int tenantId, [FromRoute] int parentTokenId)
        {
            //Should return Ilist of TokenView
            var data = await _tokenbusiness.GetTokenDetails(parentTokenId, tenantId);
            if(data == null)
            {
                return BadRequest(string.Format(ControllerConstants.NoRecordsForIdErrorMessage, data));
            }
            else
            {
                return Ok(data);
            }
        }

        [HttpPost("token")]
        public async Task<IActionResult> Post([FromRoute] int tenantId, [FromBody] AddPostView tokenView)
        {
             await _tokenbusiness.AddToken( tokenView, tenantId);
            return NoContent();
        }


        [HttpPut("token/{tokenId}")]
        public async Task<IActionResult> Put([FromRoute] int tenantId, [FromRoute] int tokenId, [FromBody] AddPostView tokenView)
        {
            
            await _tokenbusiness.UpdateToken(tokenView, tokenId, tenantId);
            return NoContent();
        }

        [HttpDelete("token/{tokenId}")]
        public async Task<IActionResult> Delete([FromRoute] int tenantId, [FromRoute] int tokenId)
        {
            await _tokenbusiness.DeleteToken(tokenId, tenantId);
            return NoContent();
        }

        [HttpGet("token/{tokenId}/detail")]
        public async Task<IActionResult> Detail([FromRoute] int tenantId, int tokenId)
        {
           

           var rawData= await _tokenbusiness.GetDetails(tokenId,tenantId); 

			return Ok(rawData);
        }
		[HttpGet("token/lists")]
		public async Task<IActionResult> GetTokenByParentTokenId([FromRoute] int tenantId)
		{
			
			var data = await _tokenbusiness.getResponseByParentTokenId(tenantId);
			if (data == null)
			{
				return BadRequest(string.Format(ControllerConstants.NoRecordsForIdErrorMessage, data));
			}
			else
			{
				return Ok(data);
			}
		}

        [HttpGet("token/ncSource")]
        public async Task<IActionResult> GetTokenDropdown([FromRoute] int tenantId)
        {
            var rawData = await _tokenbusiness.GetTokenDropdown(tenantId);
            return Ok(rawData);
        }
	}
}