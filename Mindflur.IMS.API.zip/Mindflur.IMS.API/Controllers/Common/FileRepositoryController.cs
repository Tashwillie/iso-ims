﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Application.ViewModel.View;

namespace Mindflur.IMS.API.Controllers.Common
{
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/file-repository")]
    [ApiController]
    public class FileRepositoryController : BaseController
    {
        private readonly IFileRepositoryBusiness _fileRepositoryBusiness;

        public FileRepositoryController(IFileRepositoryBusiness fileRepositoryBusiness)
        {
            _fileRepositoryBusiness = fileRepositoryBusiness;
        }

        [HttpGet("list")]
        public async Task<IActionResult> Get([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, int? sourceId=0,  int? sourceItemId = 0)
        {
            var request = new GetFileListRequest()
            {
                ListRequests = new GetListRequest
                {
                    Sort = sort,
                    Page = page,
                    PerPage = perPage,
                    SortColumn = sortColumn
                },
                TenantId = tenantId,
                SourceId= sourceId,
                SourceItemId = sourceItemId
			};
            var file = await _fileRepositoryBusiness.GetFiles(request);
            return Ok(file);
        }

        [HttpDelete("{fileId}")]
        public async Task<IActionResult> Delete([FromRoute] int tenantId, int fileId)
        {
            await _fileRepositoryBusiness.DeleteFile(fileId, tenantId);
            return NoContent();
        }

        [HttpGet("{sourceId}/list")]
        public async Task<IActionResult> GetList([FromRoute] int tenantId, int sourceId)
        {
            var rawData = await _fileRepositoryBusiness.GetFilesBySourceId(tenantId, sourceId);           
            return Ok(rawData);
        }
		[HttpGet("source/{sourceId}/sourceItemId/{sourceItemId}/lists")]
		public async Task<IActionResult> GetFileList([FromRoute] int tenantId,int sourceId, int sourceItemId)
		{
			var rawData = await _fileRepositoryBusiness.GetFilesByAttachmentMasterId(sourceItemId,sourceId, tenantId);
			return Ok(rawData);
		}

		[HttpPost()]
        public async Task<IActionResult> UploadFile(IFormFile files, [FromRoute] int tenantId, [FromQuery] PostFileRepositoryView postFileRepositoryView)
        {
            postFileRepositoryView.IsPrivate = postFileRepositoryView.IsPrivate;
            await _fileRepositoryBusiness.AddFile(files, tenantId, postFileRepositoryView, UserId);

            return NoContent();
        }

        [HttpGet("{fileId}")]
        public async Task<IActionResult> GetFileContent([FromRoute] int tenantId, [FromRoute] int fileId)
        {
            var file = await _fileRepositoryBusiness.DownloadFile(fileId: fileId, tenantId: tenantId);
           

            return File(file.Content, "application/octet-stream", file.FileName);
        }
    }
}