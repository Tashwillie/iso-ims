﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;

namespace Mindflur.IMS.API.Controllers.Common
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/multiFile")]
    [ApiController]
    public class MultipleFileUpoadController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public MultipleFileUpoadController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpPost]
        public async Task<IActionResult> MultipleFileUpload(List<IFormFile> files)
        {
            string blobstorageconnection = _configuration.GetValue<string>("PublicContainerName");

            CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(blobstorageconnection);

            CloudBlobClient blobClient = cloudStorageAccount.CreateCloudBlobClient();

            CloudBlobContainer publicBlobContainer = blobClient.GetContainerReference(_configuration.GetValue<string>("PublicContainerName"));

            foreach (var formFile in files)
            {
                byte[] data;
                string systemFileName = formFile.FileName;
                await using var target = new MemoryStream();
                formFile.CopyTo(target);
                data = target.ToArray();
                CloudBlockBlob cloudBlockBlob = publicBlobContainer.GetBlockBlobReference(systemFileName);
                await cloudBlockBlob.UploadFromByteArrayAsync(data, 0, data.Length);
            }

            return Ok();
        }
    }
}