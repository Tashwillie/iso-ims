﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Data;
using Mindflur.IMS.Data.Models;

namespace Mindflur.IMS.API.Controllers.Common
{
    [Route("api/email/notification")]
    [ApiController]
    public class EmailNotificationController : ControllerBase
    {
        private readonly IMSDEVContext _context;

        public EmailNotificationController(IMSDEVContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var emailNotification = await _context.EmailNotifications.ToListAsync();
            return Ok(emailNotification);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] EmailNotification email)
        {
            await _context.EmailNotifications.AddAsync(email);
            await _context.SaveChangesAsync();
            return Ok(email);
        }

        [HttpGet("{Id}")]
        public async Task<IActionResult> Get(int Id)
        {
            var emailNotification = await _context.EmailNotifications.FindAsync(Id);
            return emailNotification == null ? NotFound("Id Not Found") : Ok(emailNotification);
        }

        [HttpPut("{Id}")]
        public async Task<IActionResult> Put([FromBody] EmailNotification email, int Id)
        {
            var emailNotification = await _context.EmailNotifications.FindAsync(Id);
            if (emailNotification == null)
            {
                return NotFound(string.Format(ControllerConstants.IdNotFoundErrorMessage));
               
            }
            else
            {
                emailNotification.ModuleName = email.ModuleName;
                emailNotification.Response = email.Response;
                await _context.SaveChangesAsync();
                return NoContent();
            }
        }

        [HttpDelete("{Id}")]
        public async Task<IActionResult> Delete(int Id)
        {
            var emailNotification = await _context.EmailNotifications.FindAsync(Id);
            if (emailNotification == null)
            {
                return NotFound(string.Format(ControllerConstants.IdNotFoundErrorMessage));
            }
            else
            {
                _context.EmailNotifications.Remove(emailNotification);
                await _context.SaveChangesAsync();
                return NoContent();
            }
        }
    }
}