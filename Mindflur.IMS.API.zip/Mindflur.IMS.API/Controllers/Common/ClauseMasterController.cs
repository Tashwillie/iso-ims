﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.InternalAuditLayouts.Component;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Application.ViewModel.View;
using System.Drawing.Text;

namespace Mindflur.IMS.API.Controllers.Common
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/clause/new")]
    [ApiController]
    public class ClauseMasterController : BaseController
    {
        private readonly IClauseBusiness _clauseBusiness;
        public ClauseMasterController(IClauseBusiness clauseBusiness)
        {
           _clauseBusiness= clauseBusiness;
        }

        [HttpGet("list")]
        public async Task<IActionResult> GetClausesList([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, int? standardId = 0, int? parentId = 0)
        {
            var request = new GetClauseListRequest()
            {
                ListRequests = new GetListRequest
                {
                    Sort = sort,
                    Page = page,
                    PerPage = perPage,
                    SortColumn = sortColumn
                },
                TenantId = tenantId,
               StandardId= standardId,
               ParentId= parentId
                
            };
            var model = await _clauseBusiness.TokenList(request);
            return Ok(model);
        }

        [HttpGet("{parentId}")]
        public async Task<IActionResult> GetTokens([FromRoute] int tenantId, [FromRoute] int parentId)
        {
            var parentFinding = await _clauseBusiness.GetClauseByParentId(parentId, tenantId);
            return Ok(parentFinding);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromRoute] int tenantId, [FromBody] PostClauseView clauseView)
        {
          await _clauseBusiness.AddClause(clauseView, tenantId);
            return NoContent();
        }

        [HttpPut("{clauseId}")]
        public async Task<IActionResult> Put([FromRoute] int tenantId, [FromRoute] int clauseId, [FromBody] PostClauseView tokenView)
        {
            await _clauseBusiness.UpdateClauses(tokenView, clauseId, tenantId);
            return NoContent();
        }

        [HttpDelete("{clauseId}")]
        public async Task<IActionResult> Delete([FromRoute] int tenantId, [FromRoute] int clauseId)
        {
            await _clauseBusiness.DeleteClauseById(clauseId, tenantId);
            return NoContent();
        }

        [HttpGet("{clauseId}/detail")]
        public async Task<IActionResult> ClauseIdDetail([FromRoute] int tenantId, int clauseId)
        {
            var ClauseFinding = await _clauseBusiness.GetClauseByClauseId(clauseId, tenantId);
            return Ok(ClauseFinding);
        }

     

		[HttpGet("dropdown")]
		public async Task<IActionResult> GetClause([FromRoute] int tenantId)
		{
			var clauses = await _clauseBusiness.GetClausesResponseAsync(tenantId);
			return Ok(clauses);
		}

        [HttpGet("tree")]
        public async Task<IActionResult> GetClauseTree([FromRoute] int tenantId)
        {
            var clauses = await _clauseBusiness.GetClausesTreeResponseAsync(tenantId);
            return Ok(clauses);
        }


        [HttpGet("Standard/{standardId}")]
        public async Task<IActionResult> GetStandardList([FromRoute] int standardId)
        {
            var RawData = await _clauseBusiness.GetClauseByStandardId(standardId);
            return Ok(RawData);
        }

        [HttpGet("clausemaster/{clauseNumberText}")]
        public async Task<IActionResult> GetClausenNmberTextList([FromRoute] string clauseNumberText)
        {
            var RawData = await _clauseBusiness.GetClausenNmberText(clauseNumberText);
            return Ok(RawData);
        }

    }
}