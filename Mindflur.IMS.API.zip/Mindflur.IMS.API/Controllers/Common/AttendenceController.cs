﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Data.Models;

namespace Mindflur.IMS.API.Controllers.Common
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/meeting/attendance")]
    [ApiController]
    public class AttendenceController : ControllerBase
    {
        private readonly IManagementReviewBusiness _managementReviewBusiness;

        public AttendenceController(IManagementReviewBusiness managementReviewBusiness)
        {
            _managementReviewBusiness = managementReviewBusiness;
        }

        [HttpGet("{mrmId}")]
        public async Task<IActionResult> GetAttendanceList(int mrmId = 0)
        {
            var model = await _managementReviewBusiness.GetAttendanceList(mrmId);
            return model != null ? Ok(model) : NotFound();
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] PostAttendenceView meetingAttendence)
        {
            await _managementReviewBusiness.AddAttendenceToMeeting(meetingAttendence);
            return Ok(meetingAttendence);
        }

        [HttpPut("{Id}")]
        public async Task<IActionResult> Put(int Id, [FromBody] MeetingAttendence meetingAttendence)
        {
            await _managementReviewBusiness.EditMeetingAttendenceById(Id, meetingAttendence);
            return NoContent();
        }

        [HttpDelete("{Id}")]
        public async Task<IActionResult> Delete(int Id)
        {
            await _managementReviewBusiness.DeleteAttendenceById(Id);
            return NoContent();
        }
    }
}