﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Auth;
using Mindflur.IMS.Application.Core.Exceptions;
using Mindflur.IMS.Data.Models;
using System.IdentityModel.Tokens.Jwt;

namespace Mindflur.IMS.API.Controllers.Common
{
    public class AuthRequest
    {
        public string username { get; set; }

        public string password { get; set; }
    }

    public class RefreshTokenRequest
    {
        public string RefreshToken { get; set; }
    }

    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}")]
    [ApiController]
    public class AuthenticationController : Controller
    {
       
        private readonly IKeyClockBusiness _authenticationBusiness;
        private readonly ITenantMasterBusiness _tenantMasterBusiness;
        private readonly IUserBusiness _userBusiness;
        private readonly IRolePermissionBusiness _rolePermissionBusiness;

        public AuthenticationController( ITenantMasterBusiness tenantMasterBusiness, IKeyClockBusiness authenticationBusiness, IUserBusiness userBusiness, IRolePermissionBusiness rolePermissionBusiness)
        {
            
            _authenticationBusiness = authenticationBusiness;
            _tenantMasterBusiness = tenantMasterBusiness;
            _userBusiness = userBusiness;
            _rolePermissionBusiness = rolePermissionBusiness;
        }

        [HttpPost("tenant/{tenantId}/protocol/openid-connect/token")]
        public async Task<IActionResult> GetToken([FromBody] AuthRequest authRequest, [FromRoute] string tenantId)
        {
            TenanttMaster tenant = await _tenantMasterBusiness.GetTenantByShortCode(tenantId);

            if (tenant == null)
            {
                return Unauthorized();
            }

            var authenticationResponse = await _authenticationBusiness.GetAuthToken(tenant.TenantId.ToString(), authRequest.username, authRequest.password);
            if (authenticationResponse.AccessToken == null)
            {
                return Unauthorized();
            }

            var authResponse = await GetAuthResponse(tenant: tenant, authRequest.username, authenticationResponse);

            return Ok(authResponse);
        }

        [HttpPost("tenant/{tenantId}/protocol/openid-connect/refresh-token")]
        public async Task<IActionResult> GetRefresh([FromBody] RefreshTokenRequest refreshTokenRequest, [FromRoute] string tenantId)
        {
            TenanttMaster tenant = await _tenantMasterBusiness.GetTenantByShortCode(tenantId);

            if (tenant == null)
            {
                return Unauthorized();
            }
            var authenticationResponse = await _authenticationBusiness.GetRefreshToken(tenant.TenantId.ToString(), refreshTokenRequest.RefreshToken);
            if (authenticationResponse.AccessToken == null)
            {
                return Unauthorized();
            }
            //Extract token username from access token
            var username = new JwtSecurityToken(jwtEncodedString: authenticationResponse.AccessToken).Claims.FirstOrDefault(c => c.Type == "preferred_username").Value;

            var authResponse = await GetAuthResponse(tenant: tenant, username, authenticationResponse);

            return Ok(authResponse);
        }

        private async Task<AuthResponse> GetAuthResponse(TenanttMaster tenant, string username, AuthToken authToken)
        {
            var usersDetail = await _userBusiness.GetByUsername(tenant.TenantId, username);
            if (usersDetail != null) 
            {
                var abilities = await _rolePermissionBusiness.GetUserAbilities(tenant.TenantId, usersDetail.RoleId, usersDetail.RoleName);

                var activeUser = new ActiveUser()
                { Ability = abilities, Email = usersDetail.EmailAddress, FullName = usersDetail.FirstName + " " + usersDetail.LastName, Role = usersDetail.RoleName, UserId = usersDetail.UserId, Username = usersDetail.Username, TenantId = tenant.TenantId, TenantName = tenant.Name, TenantShortCode = tenant.ShortCode };

                var authResponse = new AuthResponse();
                authResponse.Token = authToken;
                authResponse.User = activeUser;

                return authResponse;
            }
            throw new NotFoundException(username, $"User not found for tenant {tenant.Name}");            
        }
    }
}