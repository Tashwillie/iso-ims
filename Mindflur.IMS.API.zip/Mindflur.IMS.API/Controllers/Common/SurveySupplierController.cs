﻿using DocumentFormat.OpenXml.Office2013.Excel;
using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.ViewModel.View;
using Mindflur.IMS.Business;

namespace Mindflur.IMS.API.Controllers.Common
{
	[ApiVersion("1")]
	[Route("api/v{version:apiVersion}/tenant/{tenantId}/surveysupplier")]
	[ApiController]
	public class SurveySupplierController : BaseController
	{
		private readonly ISurveySupplierMappingBusiness _surveySupplierMappingBusiness;

		public SurveySupplierController(ISurveySupplierMappingBusiness surveySupplierMappingBusiness)
		{
			_surveySupplierMappingBusiness = surveySupplierMappingBusiness;
		}

		[HttpPost("{supplierId}")]
		public async Task<IActionResult> Post([FromRoute] int tenantId, SupplierSurveyPostView supplierSurveyPostView, [FromRoute] int supplierId)
		{
			await _surveySupplierMappingBusiness.AddSurveyToSupplier(tenantId, supplierSurveyPostView, UserId, supplierId);
			return NoContent();
		}

		[HttpGet]
        public async Task<IActionResult> Get([FromRoute] int tenantId, [FromQuery] int supplierId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0)
        {
            var request = new GetListSurveySupplier()
            {
                ListRequests = new GetListRequest()
                {
                    Sort = sort,
                    SortColumn = sortColumn,
                    PerPage = perPage,
                    Page = page
                },
                TenantId = tenantId,
                SupplierId = supplierId
            };
            var surveyData = await _surveySupplierMappingBusiness.GetAllSurveyForSupplier(request);
            return Ok(surveyData);
        }
		[HttpGet("ownedUser/{supplierId}")]
		public async Task<IActionResult> GetAllSurveyForSupplierByCreatedBy([FromRoute] int tenantId, [FromRoute] int supplierId,[FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0)
		{
			var request = new GetListSurveySupplier()
			{
				ListRequests = new GetListRequest()
				{
					Sort = sort,
					SortColumn = sortColumn,
					PerPage = perPage,
					Page = page
				},
                SupplierId = supplierId,

                TenantId = tenantId,
				CreatedById = UserId
			};
			var surveyData = await _surveySupplierMappingBusiness.GetAllSurveyForSupplier(request);
			return Ok(surveyData);
		}
		[HttpGet("assignedUser/{supplierId}")]
		public async Task<IActionResult> GetAllSurveyForSupplierByAssignedby([FromRoute] int tenantId, [FromRoute] int supplierId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0)
		{
			var request = new GetListSurveySupplier()
			{
				ListRequests = new GetListRequest()
				{
					Sort = sort,
					SortColumn = sortColumn,
					PerPage = perPage,
					Page = page
				},
				SupplierId = supplierId,
				TenantId = tenantId,
				AssignedById = UserId
			};
			var surveyData = await _surveySupplierMappingBusiness.GetAllSurveyForSupplier(request);
			return Ok(surveyData);
		}

		[HttpGet("{surveyId}/GetSupplierIdBySurveyID")]
		public async Task<IActionResult> GetSupplierId(int surveyId, [FromRoute] int tenantId)
		{
			var supplier = await _surveySupplierMappingBusiness.getSupplierId(surveyId, tenantId);
			return Ok(supplier);
		}


	}
}