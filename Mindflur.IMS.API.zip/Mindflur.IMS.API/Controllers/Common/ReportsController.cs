﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.Application.AuditPlanReportt.AuditPlanDataSource;
using Mindflur.IMS.Application.AuditPlanReportt.AuditPlanModel;
using Mindflur.IMS.Application.CorrectiveActionLayout;
using Mindflur.IMS.Application.CorrectiveActionLayout.DataSource;
using Mindflur.IMS.Application.DocumentChangeRequestReport.DataSource;
using Mindflur.IMS.Application.DocumentChangeRequestReport.Model;
using Mindflur.IMS.Application.IncidentManagementLayout;
using Mindflur.IMS.Application.InternalAuditLayouts.DataSource;
using Mindflur.IMS.Application.Layouts;
using Mindflur.IMS.Application.ManagementReviewReports.AgendaLayouts;
using Mindflur.IMS.Application.ManagementReviewReports.MinutesOfMEeetingLayout;
using Mindflur.IMS.Application.NonConformanceLayouts;
using Mindflur.IMS.Application.NonConformanceLayouts.NcDataSource;
using Mindflur.IMS.Application.ObservationReport.ObservationDataSource;
using Mindflur.IMS.Application.ObservationReport.ObservationModel;
using Mindflur.IMS.Application.SupplierReports.DataSource;
using Mindflur.IMS.Application.SupplierReports.Model;
using QuestPDF.Fluent;

namespace Mindflur.IMS.API.Controllers.Common
{
	[ApiVersion("1")]
	[Route("api/v{version:apiVersion}/tenant/{tenantId}")]
	[ApiController]
	public class ReportsController : ControllerBase
	{
		
		private readonly IInternalAuditDataSourceBusiness _internalAuditReportBusiness;
		private readonly IMRMAgendaReportBusiness _agendaReportBusiness;
		private readonly IMrmMinutesBusiness _mrmMinutesBusiness;
		private readonly ICorrectiveActionReportBusiness _correctiveActionReportBusiness;
		private readonly INonConfermanceDataSourceBusiness _nonConfermanceDataSourceBusiness;
		private readonly IDocumentChangeRequestSourceBusiness _documentChangeRequestReportBusiness;
		private readonly IObservationReportBuisiness _observationReportBuisiness;
		private readonly IIncidentDataSourceBusiness _incidentDataSourceBusiness;
		private readonly IAuditPlanReportBuisiness _auditPlanReportBuisiness;
		private readonly ISupplierSourceBusiness _supplierSourceBusiness;

		public ReportsController( IObservationReportBuisiness observationReportBuisiness, IInternalAuditDataSourceBusiness internalAuditReportBusiness,IMRMAgendaReportBusiness agendaReportBusiness
			, IMrmMinutesBusiness mrmMinutesBusiness, ICorrectiveActionReportBusiness correctiveActionReportBusiness, ISupplierSourceBusiness supplierSourceBusiness,
			 INonConfermanceDataSourceBusiness nonConfermanceDataSourceBusiness,IDocumentChangeRequestSourceBusiness documentChangeRequestSourceBusiness,IIncidentDataSourceBusiness incidentDataSourceBusiness, IAuditPlanReportBuisiness auditPlanReportBuisiness)
		{
			_observationReportBuisiness = observationReportBuisiness;
			
			_internalAuditReportBusiness = internalAuditReportBusiness;
			_agendaReportBusiness = agendaReportBusiness;	
			_correctiveActionReportBusiness= correctiveActionReportBusiness;
			_mrmMinutesBusiness= mrmMinutesBusiness;
			_nonConfermanceDataSourceBusiness = nonConfermanceDataSourceBusiness;
			_documentChangeRequestReportBusiness = documentChangeRequestSourceBusiness;
			_incidentDataSourceBusiness = incidentDataSourceBusiness;
			_auditPlanReportBuisiness= auditPlanReportBuisiness;
			_supplierSourceBusiness= supplierSourceBusiness;

        }


		[HttpGet("Incident/ReportGenerate/{incidentId}")]
		public async Task<IActionResult> GenerateIncidentReport(int incidentId, int tenantId)
		{
			var model = await _incidentDataSourceBusiness.GetReport(incidentId, tenantId);
			var Report = new IncidentReportNew(model);
			var pdfReport = Report.GeneratePdf();
			var stream = new MemoryStream(pdfReport);
			return new FileStreamResult(stream, "application/pdf")
			{
				FileDownloadName = "IncidentManagementReport.pdf"
			};


			return NoContent();
		}

        [HttpGet("DocumentChangeRequest/ReportGenerate/{documentId}")]
        public async Task<IActionResult> GenerateDocumentChangeRequestReport(int documentId, int tenantId)
        {
            var model = await _documentChangeRequestReportBusiness.GetChangeRequestReport(documentId, tenantId);
            var Report = new ChangeRequest(model);
            var pdfReport = Report.GeneratePdf();
            var stream = new MemoryStream(pdfReport);
            return new FileStreamResult(stream, "application/pdf")
            {
                FileDownloadName = "DocumentChangeRequest.pdf"
            };


            return NoContent();
        }

        [HttpGet("MrmMinutes/ReportGenerate/{meetingId}")]
		public async Task<IActionResult> GenerateMrmMiniteReport(int meetingId, int tenantId)
		{
			var model = await _mrmMinutesBusiness.GetMrmMinutesReport(meetingId, tenantId);
			var Report = new MinutesReport(model);
            var pdfReport = Report.GeneratePdf();
            var stream = new MemoryStream(pdfReport);
            return new FileStreamResult(stream, "application/pdf")
            {
                FileDownloadName = "MRM_MinutesReport.pdf"
            };
           

			return NoContent();
		}



		[HttpGet("ObservationReport/ReportGenerate/{observationId}")]
		public async Task<IActionResult> GenerateObservationReport(int observationId, int tenantId)
		{
			var model = await _observationReportBuisiness.GetReport( observationId, tenantId);
			var Report = new ObservationReport(model);
			var pdfReport = Report.GeneratePdf();
			var stream = new MemoryStream(pdfReport);
			return new FileStreamResult(stream, "application/pdf")
			{
				FileDownloadName = "ObservationReport.pdf"
			};
			return NoContent();
		}

		[HttpGet("MRM/ReportGenerate/{meetingId}")]
		public async Task<IActionResult> GenerateMRMAgendaReport(int meetingId, int tenantId)
		{
			var model = await _agendaReportBusiness.GetMRMAgendaReport(meetingId, tenantId);
			var Report = new AgendaReport(model);
			var pdfReport = Report.GeneratePdf();

			// Converting the byte array to a PDF and returning it
			var stream = new MemoryStream(pdfReport);
			return new FileStreamResult(stream, "application/pdf")
			{
				FileDownloadName = "MRM_AgendaReport.pdf"
			};

			return NoContent();
		}
		[HttpGet("Nonconformance/ReportGenerate/{ncId}")]
		public async Task<IActionResult>GenerateNonconfermanceReport(int ncId, int tenantId)
		{
			try
			{
				var model = await _nonConfermanceDataSourceBusiness.GetNcReport(ncId, tenantId);
				var Report = new NonConformanceReport(model);
				var pdfReport = Report.GeneratePdf();
                var stream = new MemoryStream(pdfReport);
                return new FileStreamResult(stream, "application/pdf")
                {
                    FileDownloadName = "NonconformanceReport.pdf"
                };

            }
			catch (Exception ex)
			{
				throw ex;
			}
			return NoContent();
		}

		[HttpGet("ReportGenerate/{auditId}")]
		public async Task<IActionResult> GenerateReport([FromRoute]int auditId,int tenantId)
		{
			try
			{
                var model = await _internalAuditReportBusiness.GetReport(auditId,tenantId);
                var Report = new InternalAuditReport(model);
                
                var pdfReport = Report.GeneratePdf();

                // Converting the byte array to a PDF and returning it
                var stream = new MemoryStream(pdfReport);
                return new FileStreamResult(stream, "application/pdf")
                {
                    FileDownloadName = "InternalAuditReport.pdf"
                };
            }
			catch (Exception ex)
			{
				throw ex;
			}
			
			return NoContent();
		}
		[HttpGet("Corrective-Action/ReportGenerate/{correctiveActionId}")]
		public async Task<IActionResult> GenerateCAReport([FromRoute] int correctiveActionId, int tenantId)
		{
			try
			{
				var model = await _correctiveActionReportBusiness.GetReport(correctiveActionId, tenantId);
				var Report = new CorrectiveActionReport(model);

				var pdfReport = Report.GeneratePdf();

				// Converting the byte array to a PDF and returning it
				var stream = new MemoryStream(pdfReport);
				return new FileStreamResult(stream, "application/pdf")
				{
					FileDownloadName = "CorrectiveAction.pdf"
				};
			}
			catch (Exception ex)
			{
				throw ex;
			}

			return NoContent();
		}
		[HttpGet("AuditPlan/ReportGenerate/{auditId}")]
		public async Task<IActionResult> GenerateAudiPlanReport(int auditId, int tenantId)
		{
			var model = await _auditPlanReportBuisiness.GetAuditPlanReport(auditId, tenantId);
			var Report = new AuditPlanReport(model);
			var pdfReport = Report.GeneratePdf();
			var stream = new MemoryStream(pdfReport);
			return new FileStreamResult(stream, "application/pdf")
			{
				FileDownloadName = "AuditPlan.pdf"
			};
			return NoContent();
		}

        [HttpGet("Supplier/ReportGenerate/{surveyId}")]
        public async Task<IActionResult> GenerateSupplierReport(int surveyId, int tenantId)
        {
            var model = await _supplierSourceBusiness.GetReports(surveyId, tenantId);
            var Report = new SupplierReports(model);
            var pdfReport = Report.GeneratePdf();
            var stream = new MemoryStream(pdfReport);
            return new FileStreamResult(stream, "application/pdf")
            {
                FileDownloadName = "Supplier_Report.pdf"
            };

            return NoContent();
        }
		
    }
}