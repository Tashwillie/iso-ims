﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.ViewModel.Model;

namespace Mindflur.IMS.API.Controllers.Audit
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/audit/clause")]
    [ApiController]
    public class AuditClauseController : ControllerBase
    {
        
        private readonly IAuditClauseBusiness _auditClauseBusiness;

        public AuditClauseController(IAuditClauseBusiness auditClauseBusiness)
        {
          
            _auditClauseBusiness = auditClauseBusiness;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var auditClauses = await _auditClauseBusiness.GetAuditableItemClause();
            return Ok(auditClauses);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] PostAuditClause ac)
        {
            var clause = await _auditClauseBusiness.AddAuditableItemClause(ac);
            return Ok(clause);
        }

        [HttpGet("{Id}")]
        public async Task<IActionResult> Get(int Id)
        {
            var auditClauses = await _auditClauseBusiness.GetAuditableItemClauseById(Id);
            return Ok(auditClauses);
        }

        [HttpPut("{Id}")]
        public async Task<IActionResult> Put(int Id, [FromBody] PutAuditClauseViewModel putAuditClause)
        {
            //Check if the Audit Item Exists
            await _auditClauseBusiness.UpdateAuditableItemClause(Id, putAuditClause);
            return NoContent();
        }

        [HttpDelete("{Id}")]
        public async Task<IActionResult> Delete(int Id)
        {
            await _auditClauseBusiness.DeleteAuditableItemsClause(Id);
            return NoContent();
        }
    }
}