﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Application.ViewModel.View;

namespace Mindflur.IMS.API.Controllers.Audit
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/audit/items")]
    [ApiController]
    public class AuditItemController : BaseController
    {

        private readonly IAuditClauseBusiness _auditClauseBusiness;

        public AuditItemController(IAuditClauseBusiness auditClauseBusiness)
        {
            
            _auditClauseBusiness = auditClauseBusiness;
        }

        [HttpGet]
        public async Task<IActionResult> Get([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, [FromQuery] int auditId = 0)
        {
            var result = new AuditItemListView()
            {
                ListRequests = new GetListRequest()
                {
                    Sort = sort,
                    SortColumn = sortColumn,
                    PerPage = perPage,
                    Page = page
                },
                AuditProgramId = auditId,
                TenantId = tenantId
            };

            var model = await _auditClauseBusiness.GetAuditItems(result);
            return Ok(model);

            /* */
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromRoute] int tenantId, [FromBody] PostAuditableItemView ai)
        {
            await _auditClauseBusiness.AddAuditableItems(ai, UserId, tenantId);
            return Ok(ai);
        }

        [HttpGet("participant/{moduleEntityId}/{moduleId}")]
        public async Task<IActionResult> GetParticipantList([FromRoute] int moduleEntityId, [FromRoute] int moduleId)
        {
            var items = await _auditClauseBusiness.GetParticipantList(moduleEntityId, moduleId);
            return Ok(items);
        }

        [HttpGet("auditProgram/{auditId}")]
        public async Task<IActionResult> GetAuditItemsByProgramId([FromRoute] int auditId)
        {
            var items = await _auditClauseBusiness.GetAuditItemsByProgram(auditId);
            return Ok(items);
        }

        [HttpGet("{Id}")]
        public async Task<IActionResult> Get(int Id)
        {
            var auditableItem = await _auditClauseBusiness.GetAuditableItemsById(Id);
            return Ok(auditableItem);
        }

        [HttpGet("Preview/{Id}")]
        public async Task<IActionResult> preview(int Id)
        {
            var auditableItem = await _auditClauseBusiness.GetAuditableItemsPreview(Id);
            return Ok(auditableItem);
        }


        [HttpPut("{Id}")]
        public async Task<IActionResult> Put([FromRoute] int tenantId, int Id, [FromBody] PutAuditableItemViewModel ai)
        {
            await _auditClauseBusiness.EditAuditableItems(Id, ai, UserId, tenantId);

            return NoContent();
        }
        [HttpPut("{id}/start")]
        public async Task<IActionResult> StartAuditableItem(CommentsForReviewViewModel comments, [FromRoute] int tenantId, [FromRoute] int id)
        {
            await _auditClauseBusiness.StartAuditItem(comments, tenantId, id, UserId);
            return NoContent();
        }

        [HttpPut("{id}/close")]
        public async Task<IActionResult> CloseAuditableItem(CommentsForReviewViewModel comments, [FromRoute] int tenantId, [FromRoute] int id)
        {
            await _auditClauseBusiness.CloseAuditItem(comments, tenantId, id, UserId);
            return NoContent();
        }

        [HttpDelete("{Id}")]
        public async Task<IActionResult> Delete([FromRoute] int tenantId, int Id)
        {
            await _auditClauseBusiness.DeleteAuditableItems(Id, tenantId, UserId);
            return NoContent();
        }

       
    }
}