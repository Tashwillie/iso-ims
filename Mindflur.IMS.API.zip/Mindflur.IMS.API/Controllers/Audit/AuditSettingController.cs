﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.ViewModel.Model;

namespace Mindflur.IMS.API.Controllers.Audit
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/audit/settings")]
    [ApiController]
    public class AuditSettingController : BaseController
    {
        private readonly IAuditSettingBusiness _auditSettingBusiness;

        public AuditSettingController(IAuditSettingBusiness auditSettingBusiness)
        {
            _auditSettingBusiness = auditSettingBusiness;
        }

        [HttpGet()]
        public async Task<IActionResult> Get([FromRoute] int tenantId)
        {
            var data = await _auditSettingBusiness.getAuditSetting(tenantId);
            return Ok(data);
        }

        [HttpPut()]
        public async Task<IActionResult> Put([FromRoute] int tenantId, PutAuditSettingView auditSettingView)
        {
            await _auditSettingBusiness.updateAuditSetting(tenantId, auditSettingView);
            return NoContent();
        }
    }
}