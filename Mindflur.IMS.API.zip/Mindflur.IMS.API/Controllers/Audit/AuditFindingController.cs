﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Application.ViewModel.View;
using Mindflur.IMS.Business;

namespace Mindflur.IMS.API.Controllers.Audit
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/audit")]
    [ApiController]
    public class AuditFindingController : BaseController
    {
        private readonly IInternalAuditBusiness _internalAuditBusiness;
        private readonly IChartBusiness _chartBusiness;
        private readonly IAuditFindingBusiness _auditFindingBusiness;

        public AuditFindingController(IInternalAuditBusiness internalAuditBusiness, IChartBusiness chartBusiness,IAuditFindingBusiness auditFindingBusiness)
        {
            _internalAuditBusiness = internalAuditBusiness;
            _chartBusiness = chartBusiness;
                _auditFindingBusiness = auditFindingBusiness;
        }

        [HttpGet]
        public async Task<IActionResult> Get([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0)
        {
            var request = new GetAuditFindingListRequest()
            {
                ListRequests = new GetListRequest()
                {
                    Sort = sort,
                    SortColumn = sortColumn,
                    PerPage = perPage,
                    Page = page
                },
                TenantId = tenantId
            };
            var model = await _auditFindingBusiness.GetAuditFindings(request);
            return Ok(model);
        }

        [HttpGet("auditFinding/{auditId}")]
        public async Task<IActionResult> Get([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, [FromRoute] int auditId = 0)
        {
            var result = new AuditFindingViewForAudit()
            {
                ListRequests = new GetListRequest()
                {
                    Sort = sort,
                    SortColumn = sortColumn,
                    PerPage = perPage,
                    Page = page
                },
                AuditProgramId = auditId,
                TenantId = tenantId
            };

            var model = await _auditFindingBusiness.GetAuditFindingByAuditId(result);
            return Ok(model);
            /* */
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromRoute] int tenantId, [FromBody] PostAuditFindingView auditFinding)
        {
            await _auditFindingBusiness.AddAuditFinding(auditFinding, UserId, tenantId, HttpContext.Request.Path);
            return Ok(auditFinding);
        }

        [HttpGet("{Id}")]
        public async Task<IActionResult> Get(int Id)
        {
            var auditFindings = await _auditFindingBusiness.GetAuditFindingById(Id);
            return Ok(auditFindings);
        }

        [HttpGet("Preview/{Id}")]
        public async Task<IActionResult> Preview([FromRoute] int tenantId, int Id)
        {
            var auditFindings = await _auditFindingBusiness.GetAuditFindingPreview(Id, tenantId);
            return auditFindings != null ? Ok(auditFindings) : NotFound();
        }

        [HttpPut("{Id}")]
        public async Task<IActionResult> Put([FromRoute] int tenantId, int Id, [FromBody] PutAuditFindingViewModel audit)
        {
            await _auditFindingBusiness.UpdateAuditFinding(audit, Id, UserId, tenantId);
            return NoContent();
        }

        [HttpDelete("{Id}")]
        public async Task<IActionResult> Delete([FromRoute] int tenantId, int Id)
        {
            await _auditFindingBusiness.DeleteAuditFindingById(Id, tenantId, UserId);
            return NoContent();
        }

        [HttpGet("{auditId}/findings/classification/chart/donut")]
        public async Task<IActionResult> GetChart(int category, [FromRoute] int tenantId, [FromRoute] int auditId  )
        {
            if (category >= 1 && category < 4)
            {
                var rawData = await _chartBusiness.GetAuditFindingDounutChart(category, tenantId, auditId);
                return Ok(rawData);
            }
            else
            {
                return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
            }
        }

        [HttpGet("{auditId}/findings/department/chart/donut")]
        public async Task<IActionResult> GetChartByDepartment(int category, [FromRoute] int tenantId, [FromRoute] int auditId)
         {
            if (category == 1)
            {
                var rawData = await _chartBusiness.GetAuditFindingByDepartmentDounutChart(category, tenantId, auditId); 
                return Ok(rawData);
            }
            else
            {
                return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
            }
        }

        [HttpGet("{auditId}Finding-type/cause/chart/bar")]
        public async Task<IActionResult> GetComplianceByClause([FromRoute] int tenantId, [FromRoute] int auditId, int category = 1)
        {
            if (category == 1)
            {
                var rawData = await _chartBusiness.GetAuditFindingsBarGraph(auditId, category, tenantId);
                return Ok(rawData);
            }
            else
            {
                return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
            }
        }

        [HttpGet("findings/classification/riskType/chart/donut")]
        public async Task<IActionResult> GetChartByRiskType([FromRoute] int tenantId, int category = 1)
        {
            if (category >= 1 && category < 4)
            {
                var rawData = await _chartBusiness.GetAuditFindingByRiskTypeDounutChart(category, tenantId);
                return Ok(rawData);
            }
            else
            {
                return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
            }
        }

        [HttpGet("findings/classification/riskTypeWithDepartment/chart/donut")]
        public async Task<IActionResult> GetFindingCategoryWithRiskRatingByDepartment([FromRoute] int tenantId, int category = 1)
        {
            if (category >= 1 && category < 4)
            {
                var rawData = await _chartBusiness.getAuditFindingCategoryWithRiskRatingByDepartment(category, tenantId);
                return Ok(rawData);
            }
            else
            {
                return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
            }
        }

        [HttpGet("findings/classification/chart/donut")]
        public async Task<IActionResult> GetFindingChart([FromRoute] int tenantId, int category = 1)
        {
            if (category >= 1 && category < 4)
            {
                var rawData = await _chartBusiness.GetAuditFindingClassificationDounutChart(category, tenantId);
                return Ok(rawData);
            }
            else
            {
                return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
            }
        }

         [HttpGet("new/chart/donut")]
        public async Task<IActionResult> GetAllDonutChart([FromRoute] int tenantId)
        {
            
            var AuditFindingByClassifications = await _chartBusiness.GetAuditFindingClassificationDounutChart(1, tenantId);
            var AuditFindingCategoryByStatus = await  _chartBusiness.GetAuditFindingClassificationDounutChart(2,tenantId);
            var AuditFindingDepartment = await _chartBusiness.getAuditFindingCategoryWithRiskRatingByDepartment(1, tenantId);



            return Ok( new { AuditFindingByClassifications , AuditFindingCategoryByStatus, AuditFindingDepartment });
        }

        [HttpGet("{auditId}/new/chart/donut")]
        public async Task<IActionResult> GetAuditIdAllDonutChart([FromRoute] int tenantId, [FromRoute] int auditId)
        {
            var AuditIdByClassification = await _chartBusiness.GetAuditFindingDounutChart(1, tenantId, auditId);
            var AuditIdByStatus = await _chartBusiness.GetAuditFindingDounutChart(2, tenantId, auditId);
            var AuditIdByDepartment = await _chartBusiness.GetAuditFindingByDepartmentDounutChart(1, tenantId, auditId);
            return Ok(new {AuditIdByClassification , AuditIdByStatus , AuditIdByDepartment });
        }

        [HttpGet("{auditId}/AuditFindingList")]
		public async Task<IActionResult> GetAllFindings(int tenantId, int auditId)
		{
			var data = await _auditFindingBusiness.GetAllFindings(tenantId, auditId);
			return Ok(data);
		}
	}
   
}