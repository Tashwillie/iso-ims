﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.ViewModel.View;
using Mindflur.IMS.Business;
using Mindflur.IMS.Data.Models;

namespace Mindflur.IMS.API.Controllers.Audit
{
	[ApiVersion("1")]
	[Route("api/v{version:apiVersion}/tenant/{tenantId}/checklist/questions")]
	[ApiController]
	public class ChecklistController : ControllerBase
	{
		private readonly IAuditCheckListQuestionBusiness _auditCheckListQuestionBusiness;

		public ChecklistController(IAuditCheckListQuestionBusiness auditCheckListQuestionBusiness)
		{
			_auditCheckListQuestionBusiness = auditCheckListQuestionBusiness;
		}

		[HttpGet("list")]
		public async Task<IActionResult> GetCheckListMasterList([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, int? standardId = 0, int?  clauseId = 0)
		{
			var result = new CheckListView()
			{
				ListRequests = new GetListRequest()
				{
					Sort = sort,
					SortColumn = sortColumn,
					PerPage = perPage,
					Page = page
				},
				TenantId = tenantId,
				StandardId= standardId,
				ClauseId = clauseId
            };
			var model = await _auditCheckListQuestionBusiness.GetCheckListMasterList(result);
			return Ok(model);
		}

		[HttpGet]
		public async Task<IActionResult> Get()
		{
			var checklist = await _auditCheckListQuestionBusiness.GetChecklistQuestions();
			return Ok(checklist);
		}

		[HttpPost]
		public async Task<IActionResult> Post([FromRoute] int tenantId, [FromBody] PostCheckListView postCheckListView)
		{
			await _auditCheckListQuestionBusiness.AddChecklistQuestionsMaster(postCheckListView, tenantId);
			return Ok(postCheckListView);
		}

		[HttpGet("{Id}")]
		public async Task<IActionResult> GetCheckListDetalis([FromRoute] int tenantId, [FromRoute] int Id)
		{
			var questions = await _auditCheckListQuestionBusiness.GetChecklistMasterById( tenantId, Id);

			return Ok(questions);
		}

        [HttpGet("{auditProgramId}/list")]
        public async Task<IActionResult> GetCheckList([FromRoute] int tenantId, [FromRoute] int auditProgramId)
        {
            var rawData = await _auditCheckListQuestionBusiness.GetChecklistAuditProgramId(tenantId, auditProgramId);

            return Ok(rawData);
        }


		[HttpGet("dropdown")]
        public async Task<IActionResult> GetCheckListDropdown([FromRoute] int tenantId)
        {

            var rawData = await _auditCheckListQuestionBusiness.GetCheckListDropdown(tenantId);

            return Ok(rawData);
        }


        [HttpPut("{Id}")]
		public async Task<IActionResult> Put([FromRoute] int tenantId, [FromRoute]int Id,[FromBody] PutCheckListView putCheckListView)
		{
			await _auditCheckListQuestionBusiness.UpdateCheckList(putCheckListView, Id, tenantId);
			return NoContent();
		}

		[HttpDelete("{Id}")]
		public async Task<IActionResult> Delete([FromRoute] int tenantId, [FromRoute] int Id)
		{
			await _auditCheckListQuestionBusiness.DeleteChecklistQuestion(Id, tenantId);
			return NoContent();
		}
	}
}