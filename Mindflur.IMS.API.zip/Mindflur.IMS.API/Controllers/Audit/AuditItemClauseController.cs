﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Data.Models;

namespace Mindflur.IMS.API.Controllers.Audit
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/clause")]
    [ApiController]
    public class AuditItemClauseController : ControllerBase
    {
    
        private readonly IAuditClauseBusiness _auditClauseBusiness;

        public AuditItemClauseController(IAuditClauseBusiness auditClauseBusiness)
        {
           
            _auditClauseBusiness = auditClauseBusiness;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var clauses = await _auditClauseBusiness.GetAuditItemClauses();
            return Ok(clauses);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] AuditItemClause clauses)
        {
            var clause = await _auditClauseBusiness.AddAuditItemClause(clauses);
            return Ok(clause);
        }

        [HttpGet("{Id}")]
        public async Task<IActionResult> Get(int Id)
        {
            var clauses = await _auditClauseBusiness.GetAuditItemClauseById(Id);
            return Ok(clauses);
        }

        [HttpPut("{Id}")]
        public async Task<IActionResult> Put(int Id, [FromBody] AuditItemClause clause)
        {
            await _auditClauseBusiness.EditAuditItemClause(Id, clause);
            return NoContent();
        }

        [HttpDelete("{Id}")]
        public async Task<IActionResult> Delete(int Id)
        {
            await _auditClauseBusiness.DeleteAuditItemClause(Id);
            return NoContent();
        }
    }
}