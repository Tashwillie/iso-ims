﻿	using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.Core;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Application.ViewModel.View;
using Mindflur.IMS.Business;
using System.Net;

namespace Mindflur.IMS.API.Controllers.Audit
{
	[ApiVersion("1")]
	[Route("api/v{version:apiVersion}/tenant/{tenantId:int}/internal-audit")]
	[ApiController]
	public class InternalAuditController : BaseController
	{
		private readonly IInternalAuditBusiness _internalAuditBusiness;
		private readonly IParticipantsBusiness _participantBusiness;
		private readonly IChartBusiness _chartBusiness;
		private readonly IAuditPlanBusiness _auditPlanBusiness;
		private readonly ICheckListMasterBusiness _checkListMasterBusiness;

		public InternalAuditController(IInternalAuditBusiness internalAuditBusiness, IParticipantsBusiness participantBusiness, IChartBusiness chartBusiness, IAuditPlanBusiness auditPlanBusiness, ICheckListMasterBusiness checkListMasterBusiness)
		{
			_internalAuditBusiness = internalAuditBusiness;
			_participantBusiness = participantBusiness;
			_chartBusiness = chartBusiness;
			_auditPlanBusiness = auditPlanBusiness;
			_checkListMasterBusiness = checkListMasterBusiness;
		}

		[HttpGet]
		[Route("list")]
		[ProducesResponseType(typeof(PaginatedItems<AuditProgramGridView>), (int)HttpStatusCode.OK)]
		[ProducesResponseType((int)HttpStatusCode.BadRequest)]
		public async Task<IActionResult> GetGrid([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0)
		{
			var request = new GetAuditProgramListRequest()
			{
				ListRequests = new GetListRequest()
				{
					Sort = sort,
					SortColumn = sortColumn,
					PerPage = perPage,
					Page = page
				},
				TenantId = tenantId
			};

			var model = await _internalAuditBusiness.GetAuditProgramList(request);
			return Ok(model);
		}

		[HttpGet]
		[Route("user/list")]
		[ProducesResponseType(typeof(PaginatedItems<AuditProgramGridView>), (int)HttpStatusCode.OK)]
		[ProducesResponseType((int)HttpStatusCode.BadRequest)]
		public async Task<IActionResult> GetGridCreatedBy([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0)
		{
			var request = new GetAuditProgramListRequest()
			{
				ListRequests = new GetListRequest()
				{
					Sort = sort,
					SortColumn = sortColumn,
					PerPage = perPage,
					Page = page
				},
				TenantId = tenantId,
				ForUserId = UserId
			};

			var model = await _internalAuditBusiness.GetAuditProgramList(request);
			return Ok(model);
		}

		[HttpPost]
		public async Task<IActionResult> Post([FromBody] PostAuditProgram pap, [FromRoute] int tenantId)
		{
			await _internalAuditBusiness.AddAuditProgram(pap, tenantId, UserId);

			return Ok();
		}

		[HttpGet("{auditId:int}/preview")]
		public async Task<IActionResult> Preview([FromRoute] int tenantId, [FromRoute] int auditId)
		{
			var rawData = await _internalAuditBusiness.GetPreviewForAudit(auditId, tenantId);
			return Ok(rawData);
		}

		[HttpGet("{auditId:int}")]
		public async Task<IActionResult> Get([FromRoute] int auditId)
		{
			var auditProgram = await _internalAuditBusiness.GetAuditProgramById(auditId);
			return Ok(auditProgram);
		}

		[HttpGet("dropdownlist")]
		public async Task<IActionResult> Dropdown([FromRoute] int tenantId)
		{
			var dropdown = await _internalAuditBusiness.GetAuditDropdownList(tenantId);
			return Ok(dropdown);
		}

		[HttpPut("{auditId:int}")]
		public async Task<IActionResult> Put([FromRoute] int tenantId, [FromRoute] int auditId, [FromBody] PutAuditProgramViewModel putAuditProgram)
		{
			await _internalAuditBusiness.UpdateAuditProgram(auditId, putAuditProgram, UserId, tenantId);
			return NoContent();
		}

		[HttpDelete("{auditId:int}")]
		public async Task<IActionResult> Delete([FromRoute] int tenantId, [FromRoute] int auditId)
		{
			await _internalAuditBusiness.DeleteAuditProgram(auditId, tenantId, UserId);
			return NoContent();
		}

		[HttpPost("{auditId}/participant")]
		public async Task<IActionResult> Post([FromRoute] int tenantId, [FromBody] AddParticipantViewModel addParticipant)
		{
			await _internalAuditBusiness.AddAuditPaticipants(addParticipant, 1, UserId, tenantId);

			return Ok();
		}

		[HttpGet("{auditId:int}/participants")]
		public async Task<IActionResult> GetParticipantsGrid([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, [FromRoute] int auditId = 0)
		{
			var request = new GetParticipantsList()
			{
				ListRequests = new GetListRequest
				{
					Sort = sort,
					SortColumn = sortColumn,
					PerPage = perPage,
					Page = page,
				},
				ModuleEntityId = auditId,
				TenantId = tenantId
			};
			var model = await _participantBusiness.GetAuditParticipantsList(request, 1);
			return Ok(model);
		}

		[HttpPut("{auditId:int}/participant/{participantId:int}")]
		public async Task<IActionResult> UpdateParticipant([FromRoute] int participantId, [FromBody] UpdateParticipantViewModel updateParticipant)
		{
			await _participantBusiness.UpdateParticipants(updateParticipant, participantId, UserId);
			return NoContent();
		}

		[HttpPut("{auditId:int}/participant/{participantId:int}/present")]
		public async Task<IActionResult> MarkPresent([FromRoute] int participantId)
		{
			await _participantBusiness.UpdateParticipantsMarkPresent(participantId);
			return NoContent();
		}

		[HttpDelete("{auditId:int}/participant/{participantId:int}")]
		public async Task<IActionResult> RemoveParticipant([FromRoute] int participantId)
		{
			await _participantBusiness.DeleteParticipants(participantId, UserId);
			return NoContent();
		}

		[HttpPut("{auditId:int}/approve")]
		public async Task<IActionResult> Approve([FromRoute] int tenantId, [FromRoute] int auditId)
		{
			//Write code to perform business logic check before it can approve it.
			//Return errors AuditProgramDetailView > IList<string> BusinessValidation as bad request.

			//ToDo: Write code to approve the meeting get userId from basecontroller.
			//if all business condition met then approve the meeting and return no-content()
			await _auditPlanBusiness.ApproveAudit(tenantId, auditId, UserId);
			return NoContent();
		}

		[HttpPut("{auditId:int}/publish")] //>send invite
		public async Task<IActionResult> Publish([FromRoute] int tenantId, [FromRoute] int auditId)
		{
			//Write code to perform business logic check before it can approve it.
			//Return errors AuditProgramDetailView > IList<string> BusinessValidation as bad request.

			//ToDo: Write code to publish the meeting get userId from basecontroller.
			//if all business condition met then publish the meeting and return no-content()

			await _internalAuditBusiness.UpdateAsPublishForAudit(auditId, tenantId, UserId);
			return NoContent();
		}

		[HttpPut("{auditId:int}/start")]
		public async Task<IActionResult> Start([FromRoute] int tenantId, [FromRoute] int auditId)
		{
			//Write code to perform business logic check before it can approve it.
			//Return errors AuditProgramDetailView > IList<string> BusinessValidation as bad request.

			//ToDo: Write code to publish the meeting get userId from basecontroller.
			//if all business condition met then publish the meeting and return no-content()
			await _internalAuditBusiness.StartAudit(tenantId, auditId, UserId);

			return NoContent();
		}

		[HttpPut("{auditId:int}/complete")]
		public async Task<IActionResult> Complete([FromRoute] int tenantId, [FromRoute] int auditId)
		{
			//Write code to perform business logic check before it can approve it.
			//Return errors AuditProgramDetailView > IList<string> BusinessValidation as bad request.

			//ToDo: Write code to publish the meeting get userId from basecontroller.
			//if all business condition met then publish the meeting and return no-content()
			await _internalAuditBusiness.CompleteAudit(tenantId, auditId, UserId);
			return NoContent();
		}

		[HttpPut("{auditId:int}/report")]
		public async Task<IActionResult> Report([FromRoute] int tenantId, [FromRoute] int auditId)
		{
			//Write code to perform business logic check before it can approve it.
			//Return errors AuditProgramDetailView > IList<string> BusinessValidation as bad request.

			//ToDo: Write code to publish the meeting get userId from basecontroller.
			//if all business condition met then publish the meeting and return no-content()
			await _internalAuditBusiness.AuditReport(tenantId, auditId);

			return NoContent();
		}

		[HttpGet("{auditId:int}/chart/donut")]
		public async Task<IActionResult> getMajorNc([FromRoute] int tenantId, [FromRoute] int auditId)
		{
			var rawData = await _chartBusiness.getInternalAuditNcChart(tenantId, auditId);
			return Ok(rawData);
		}

		[HttpGet("{auditId:int}/compliance/chart/donut")]
		public async Task<IActionResult> getComplianceChart([FromRoute] int tenantId, [FromRoute] int auditId, int category = 0)
		{
			if (category >= 1 && category < 3)
			{
				var rawData = await _chartBusiness.getInternalAuditOverAllCompliance(category, tenantId, auditId);
				return Ok(rawData);
			}

			else
			{
				return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
			}


		}

		[HttpGet("{auditId:int}/complianceBySection/bar/graph")]
		public async Task<IActionResult> GetComplianceSectionBarGraph([FromRoute] int tenantId, [FromRoute] int auditId)
		{
			var rawData = await _chartBusiness.GetAuditComplianceBySectionBarGraph(tenantId, auditId);
			return Ok(rawData);
		}

		[HttpGet("landingPageCharts")]
		public async Task<IActionResult> getLandingPageCharts([FromRoute] int tenantId, int category = 1)
		{
			if (category >= 1 && category < 6)
			{
				var rawData = await _chartBusiness.GetAuditLandingPageCharts(category, tenantId);
				return Ok(rawData);
			}
			else
			{
				return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
			}
		}

        [HttpGet("{auditId:int}/new/chart/donut")]

		public async Task<IActionResult> GetAllDonutChart([FromRoute] int tenantId, [FromRoute] int auditId)
		{
			var InternalAuditNcType = await _chartBusiness.getInternalAuditNcChart(tenantId, auditId);
			var InternalAuditOverAllCompliance = await _chartBusiness.getInternalAuditOverAllCompliance(1, tenantId, auditId);
			var InternalAuditOverAllReviewd = await _chartBusiness.getInternalAuditOverAllCompliance(2, tenantId, auditId);
            return Ok(new { InternalAuditNcType, InternalAuditOverAllCompliance, InternalAuditOverAllReviewd } );

        }


        [HttpGet("new/chart/landingPageCharts")]

        public async Task<IActionResult> GetAllLandingPageCharts([FromRoute] int tenantId)
		{
			var InternalAuditsNCByStatus = await _chartBusiness.GetAuditLandingPageCharts(1, tenantId);
            var InternalAuditsCAByStatus = await _chartBusiness.GetAuditLandingPageCharts(2, tenantId);
            var InternalAuditAuditableItem = await _chartBusiness.GetAuditLandingPageCharts(3, tenantId);
            var InternalAuditByCategories = await _chartBusiness.GetAuditLandingPageCharts(4, tenantId);
            var InternalAuditFindingByDepartment= await _chartBusiness.GetAuditLandingPageCharts(5, tenantId);
			return Ok(new {InternalAuditsNCByStatus,InternalAuditsCAByStatus, InternalAuditAuditableItem, InternalAuditByCategories, InternalAuditFindingByDepartment } );	

        }
		[HttpGet("{masterDataGroupId:int}/Category/dropdown")]
		public async Task<IActionResult> GetcategoryList(int masterDataGroupId)
		{
			var data = await _checkListMasterBusiness.GetcategoryList(masterDataGroupId);
			return Ok(data);
		}


	}
}