﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.ViewModel.View;
using Mindflur.IMS.Data.Models;

namespace Mindflur.IMS.API.Controllers.Audit
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/internal-audit/{auditId:int}/plan")]
    [ApiController]
    public class AuditPlanController : BaseController
    {
        private readonly IInternalAuditBusiness _internalAuditBusiness;
        private readonly IAuditPlanBusiness _auditPlanBusiness;

        public AuditPlanController(IInternalAuditBusiness internalAuditBusiness,IAuditPlanBusiness auditPlanBusiness)
        {
            _internalAuditBusiness = internalAuditBusiness;
            _auditPlanBusiness = auditPlanBusiness;
        }

        [HttpPost()]
        public async Task<IActionResult> Post([FromRoute] int tenantId, [FromBody] AuditPlan auditPlan)
        {
            await _auditPlanBusiness.AddAuditPlan(auditPlan, tenantId, UserId);
            return Ok();
        }

        [HttpGet()]
        public async Task<IActionResult> Get([FromRoute] int tenantId, int auditId)
        {
            var auditPlan = await _auditPlanBusiness.GetAuditPlanById(auditId, tenantId);
            return Ok(auditPlan);
        }

        [HttpPut()]
        public async Task<IActionResult> Put([FromRoute] int tenantId, int auditId, [FromBody] AuditPlanView ap)
        {
            await _auditPlanBusiness.EditAuditPlan(auditId, ap, tenantId, UserId);
            return NoContent();
        }

        [HttpDelete()]
        public async Task<IActionResult> Delete([FromRoute] int tenantId, int auditId)
        {
            await _auditPlanBusiness.DeleteAuditPlan(auditId, tenantId, UserId);
            return NoContent();
        }
    }
}