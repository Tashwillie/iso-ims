﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Data.Models;

namespace Mindflur.IMS.API.Controllers.Audit
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/Clause-Master")]
    [ApiController]
    public class ClauseController : ControllerBase
    {
        private readonly IInternalAuditBusiness _internalAuditBusiness;
        private readonly IAuditClauseBusiness _auditClauseBusiness;

        public ClauseController(IInternalAuditBusiness internalAuditBusiness,IAuditClauseBusiness auditClauseBusiness)
        {
            _internalAuditBusiness = internalAuditBusiness;
            _auditClauseBusiness = auditClauseBusiness;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var getAllClause = await _auditClauseBusiness.GetAllClause();
            return Ok(getAllClause);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] ClauseMaster addClauses)
        {
            await _auditClauseBusiness.AddClausesToMaster(addClauses);
            return Ok("Created");
        }

        [HttpGet("{Id}")]
        public async Task<IActionResult> Get(int Id)
        {
            var clauses = await _auditClauseBusiness.GetClauseMasterById(Id);
            return Ok(clauses);
        }

        [HttpPut("{Id}")]
        public async Task<IActionResult> Post(int Id, [FromBody] ClauseMaster addClauses)
        {
            await _auditClauseBusiness.UpdateClauseMaster(Id, addClauses);
            return NoContent();
        }

        [HttpDelete("{Id}")]
        public async Task<IActionResult> Delete(int Id)
        {
            await _auditClauseBusiness.DeleteClauseMaster(Id);
            return NoContent();
        }
    }
}