﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Application.ViewModel.View;

namespace Mindflur.IMS.API.Controllers.Audit
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/internal-audit/{auditId}/checklist")]
    [ApiController]
    public class AuditChecklistController : BaseController
    {
        private readonly IInternalAuditBusiness _internalAuditBusiness;
        private readonly IChartBusiness _chartBusiness;
        private readonly ICheckListMasterBusiness _checkListMasterBusiness;
        private readonly IAuditClauseBusiness _auditClauseBusiness;

        public AuditChecklistController(IInternalAuditBusiness internalAuditBusiness, IChartBusiness chartBusiness, ICheckListMasterBusiness checkListMasterBusiness)
        {
            _internalAuditBusiness = internalAuditBusiness;
            _chartBusiness = chartBusiness;
            _checkListMasterBusiness = checkListMasterBusiness;
        }



        [HttpGet()]
        public async Task<IActionResult> GetChecklist([FromRoute] int tenantId, [FromQuery] bool? filter, [FromRoute] int auditId = 0)
        {
            IList<AuditChecklistView> auditChecklists = filter.HasValue
                ? await _checkListMasterBusiness.GetAuditChecklistWithComplianceFilter(auditId, filter.Value, tenantId)
                : await _checkListMasterBusiness.GetAuditChecklistByAuditId(auditId, tenantId);
            return Ok(auditChecklists);
        }

        [HttpGet("clause/{clauseId}")]
        public async Task<IActionResult> GetChecklistByclause([FromRoute] int tenantId, [FromRoute] int auditId = 0, [FromRoute] int clauseId = 0)
        {
            var checklistResponce = await _checkListMasterBusiness.GetAuditChecklistForClause(auditId, clauseId, tenantId);

            return checklistResponce.Any() ? Ok(checklistResponce) : NotFound();
        }

        [HttpGet("{checklistId:int}/auditable-items")]
        public async Task<IActionResult> GetAuditDetails([FromRoute] int tenantId, [FromRoute] int auditId = 0, [FromRoute] int checklistId = 0)
        {
            var clauseId = await _checkListMasterBusiness.GetClauseIdFromChecklistId(auditId, checklistId, tenantId);

            var auditdetails = await _checkListMasterBusiness.GetAuditItemsFromClauseId(auditId, clauseId.ClauseId, tenantId);
            return Ok(auditdetails);
        }

        [HttpGet("{checklistId:int}")]
        public async Task<IActionResult> GetChecklistDetailsByChecklistId([FromRoute] int tenantId, [FromRoute] int checklistId = 0)
        {
            var checklistDetails = await _checkListMasterBusiness.GetAuditChecklistDetailsFromChecklistId(checklistId, tenantId);
            return checklistDetails == null ? NotFound() : Ok(checklistDetails);
        }
        [HttpGet("department/{departmentId}")]
        public async Task<IActionResult> GetchecklistDetailsByDepartmentId([FromRoute] int tenantId, [FromRoute] int auditId, [FromRoute] int departmentId)
        {
            var checklistDetails = await _checkListMasterBusiness.GetchecklistDetailsByDepartmentId(auditId, tenantId, departmentId);
            return checklistDetails == null ? NotFound() : Ok(checklistDetails);
        }

        [HttpPut("{Id}")]
        public async Task<IActionResult> Put([FromRoute] int tenantId, int Id, [FromBody] PutAuditChecklistViewModel responce)
        {
            await _checkListMasterBusiness.UpdateChecklistResponce(Id, responce, UserId, tenantId, HttpContext.Request.Path);
            return NoContent();
        }

        [HttpDelete("{Id}")]
        public async Task<IActionResult> Delete(int Id)
        {
            await _checkListMasterBusiness.DeleteChecklistResponse(Id);
            return NoContent();
        }

        [HttpGet("Donutchart")]
        public async Task<IActionResult> GetChart([FromRoute] int tenantId, [FromRoute] int auditId, int category = 1)
        {
            if (category == 1)
            {
                var rawData = await _chartBusiness.GetComplianceDounutChart(auditId, category, tenantId);
                return Ok(rawData);
            }
            else
            {
                return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
            }
        }

        [HttpGet("compliance/cause/chart/bar")]
        public async Task<IActionResult> GetComplianceByClause([FromRoute] int tenantId, [FromRoute] int auditId, int category = 1)
        {
            if (category == 1)
            {
                var rawData = await _chartBusiness.GetComplianceClausesBargarph(auditId, category, tenantId);
                return Ok(rawData);
            }
            else
            {
                return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
            }
        }

        [HttpGet("DepartmentList")]
        public async Task<IActionResult> GetDepartmentListfromAudid([FromRoute] int auditId, [FromRoute] int tenantId)
        {
            var auditProgram = await _internalAuditBusiness.GetDepartmentListfromAudid(auditId, tenantId);
            return Ok(auditProgram);
        }

        [HttpGet("{standardId}/StandardList")]
        public async Task<IActionResult> GetStandardListfromAuditid([FromRoute] int auditId, [FromRoute] int tenantId, [FromRoute] int standardId)
        {
            var auditProgram = await _checkListMasterBusiness.GetchecklistDetailsByStandardId(auditId, tenantId, standardId);

            return auditProgram == null ? NotFound() : Ok(auditProgram);
        }

        [HttpGet("StandardList")]
        public async Task<IActionResult> GetStandardListFromAuditId([FromRoute] int auditId, [FromRoute] int tenantId)
        {
            var auditItem = await _internalAuditBusiness.GetStandardsLitFromAuditId(auditId, tenantId);
            return Ok(auditItem);
        }

    }

}