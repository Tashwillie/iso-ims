﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.View;
using Mindflur.IMS.Data.Models;

namespace Mindflur.IMS.API.Controllers.Incident
{
	[ApiVersion("1")]
	[Route("api/v{version:apiVersion}/tenant/{tenantId}/incident/id/questtionaire")]
	[ApiController]
	public class IncidentQuesttionaireController : ControllerBase
	{
		private readonly IIncidentQuesttionnaireBusiness _incidentQuesttionnaireBusiness;

		public IncidentQuesttionaireController(IIncidentQuesttionnaireBusiness incidentQuesttionnaireBusiness)
		{
			_incidentQuesttionnaireBusiness = incidentQuesttionnaireBusiness;
		}

		[HttpPost]
		public async Task<IActionResult> Post([FromBody] IncidentQuestionPut iq)
		{
			await _incidentQuesttionnaireBusiness.AddIncidentQuestions(iq);
			return Ok(string.Format(ControllerConstants.RecordCreatedMessage));
		}

		[HttpGet("{Id}")]
		public async Task<IActionResult> Get(int Id)
		{
			var incident = await _incidentQuesttionnaireBusiness.GetIncidentQuestionbyId(Id);
			return Ok(incident);
		}

		[HttpPut("{Id}")]
		public async Task<IActionResult> Put(int Id, [FromBody] IncidentQuesttionaire iq)
		{
			await _incidentQuesttionnaireBusiness.UpdateIncidentQuestion(iq, Id);
			return NoContent();
		}

		[HttpDelete("{Id}")]
		public async Task<IActionResult> Delete(int Id)
		{
			await _incidentQuesttionnaireBusiness.DeleteIncidentQuesttion(Id);
			return Ok(string.Format(ControllerConstants.RecordDeletedMessage));
		}
	}
}