﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.View;

namespace Mindflur.IMS.API.Controllers.Incident
{
	[ApiVersion("1")]
	[Route("api/v{version:apiVersion}/tenant/{tenantId}/incident-classification")]
	[ApiController]
	public class IncidentClassificationController : BaseController
	{
		private readonly IIncidentClassificationBusiness _incidentClassificationBusiness;

		public IncidentClassificationController(IIncidentClassificationBusiness incidentClassificationBusiness)
		{
			_incidentClassificationBusiness = incidentClassificationBusiness;
		}

		[HttpGet("{incidentId}")]
		public async Task<IActionResult> Get([FromRoute] int tenantId, int incidentId)
		{
			var incident = await _incidentClassificationBusiness.GetIncidentClassificationById(tenantId, incidentId);
			return Ok(incident);
		}

		[HttpPut("{incidentId}")]
		public async Task<IActionResult> put([FromBody] IncidentClassificationPostView incident, [FromRoute] int tenantId, int incidentId)
		{
			await _incidentClassificationBusiness.UpdateIncidentClassification(incident, tenantId, incidentId);
			return NoContent();
		}

		[HttpDelete("{incidentId}")]
		public async Task<IActionResult> Delete([FromRoute] int tenantId, int incidentId)
		{
			await _incidentClassificationBusiness.DeleteIncidentClassification(tenantId, incidentId);
			return Ok(string.Format(ControllerConstants.RecordDeletedMessage));
		}
	}
}