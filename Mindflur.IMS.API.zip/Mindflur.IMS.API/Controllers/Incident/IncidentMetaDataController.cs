﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Application.ViewModel.View;

namespace Mindflur.IMS.API.Controllers.Incident
{
	[ApiVersion("1")]
	[Route("api/v{version:apiVersion}/tenant/{tenantId}")]
	[ApiController]
	public class IncidentMetaDataController : BaseController
	{
		private readonly IIncidentMasterBusiness _incidentMasterBusiness;
		private readonly IChartBusiness _chartBusiness;

		public IncidentMetaDataController(IIncidentMasterBusiness incidentMasterBusiness, IChartBusiness chartBusiness)
		{
			_incidentMasterBusiness = incidentMasterBusiness;
			_chartBusiness = chartBusiness;
		}

		[HttpGet("incident/chart/donut")]
		public async Task<IActionResult> SiteOfINcidentDonutChart([FromRoute] int tenantId, int category = 1)
		{
			if (category >= 1 && category < 4)
			{
				var rawData = await _chartBusiness.GetChartSiteOfIncidentDounutChart(category, tenantId);
				return Ok(rawData);
			}
			else
			{
				return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
			}
		}

		[HttpPut("incident/{incidentId}/classification")]
		public async Task<IActionResult> PutIncidentDescription([FromRoute] int tenantId, [FromRoute] int incidentId, IncidentMasterDescriptionPutView incidentMaster)
		{
			await _incidentMasterBusiness.UpdateIncidentDescription(incidentMaster, UserId, incidentId, tenantId);
			return NoContent();
		}

		[HttpGet("incident/work-Item/{workItemId}/incident-metaData")]
		public async Task<IActionResult> GetIncidentMetaData([FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			var incident = await _incidentMasterBusiness.GetIncidentMetaData(workItemId, tenantId);
			return Ok(incident);
		}

		[HttpPut("incident/work-Item/{workItemId}/incident-metaData")]
		public async Task<IActionResult> PutIncidentMetaData([FromRoute] int tenantId, [FromRoute] int workItemId, PutIncidentMasterView putIncidentMasterView)
		{
			await _incidentMasterBusiness.UpadteIncidentMetaData(putIncidentMasterView, workItemId, UserId, tenantId);
			return NoContent();
		}

		[HttpGet("incident/new/chart/donut")]
		public async Task<IActionResult> SiteOfINcidentAllDonutChart([FromRoute] int tenantId)
		{
			var SiteOfIncidentByDepartment = await _chartBusiness.GetChartSiteOfIncidentDounutChart(1, tenantId);

			var SiteOfIncidentByStatus = await _chartBusiness.GetChartSiteOfIncidentDounutChart(3, tenantId);

			var SiteOfIncidentCAByStatus = await _chartBusiness.GetChartSiteOfIncidentDounutChart(4, tenantId);

			return Ok(new { SiteOfIncidentByDepartment, SiteOfIncidentByStatus, SiteOfIncidentCAByStatus });
		}

		[HttpPut("Incident/{workItemId}/incident-metaData/Comment")]
		public async Task<IActionResult> AddIncidentComment(Incidentcomments incidentcomments, [FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			await _incidentMasterBusiness.AddIncidentComment(incidentcomments, tenantId, workItemId, UserId);
			return NoContent();
		}

		[HttpPut("incident/{workItemId}/metadata/review")]
		public async Task<IActionResult> ReviewNonConformanceMetadata(ReviewNonconformanceMetadata reviewNonconformanceMetadata, [FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			await _incidentMasterBusiness.ReviewMetadata(reviewNonconformanceMetadata, tenantId, workItemId, UserId);
			return NoContent();
		}

		[HttpPut("incident/{workItemId}/metadata/reject")]
		public async Task<IActionResult> rejectNonConformanceMetadata(RejectNonconformanceMetadata comments, [FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			await _incidentMasterBusiness.RejectMetadata(comments, tenantId, workItemId, UserId);
			return NoContent();
		}

		[HttpPut("incident/{workItemId}/metadata/close")]
		public async Task<IActionResult> CloseNonConformanceMetadata(CloseNonConformanceMetaData closeNonConformanceMetaData, [FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			await _incidentMasterBusiness.CloseMetadata(closeNonConformanceMetaData, tenantId, workItemId, UserId);
			return NoContent();
		}

		[HttpPut("incident/start/{workItemId}")]
		public async Task<IActionResult> open([FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			await _incidentMasterBusiness.StartIncident(UserId, workItemId, tenantId);
			return NoContent();
		}
	}
}