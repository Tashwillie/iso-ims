﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.Application.Contracts.Business;

namespace Mindflur.IMS.API.Controllers.Incident
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/incident-question-master")]
    [ApiController]
    public class IncidentQuestionController : ControllerBase
    {
        private readonly IIncidentQuesttionMasterBusiness _incidentQuesttionMasterBusiness;

        public IncidentQuestionController(IIncidentQuesttionMasterBusiness incidentQuesttionMasterBusiness)
        {
            _incidentQuesttionMasterBusiness = incidentQuesttionMasterBusiness;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var rawData = await _incidentQuesttionMasterBusiness.GetAllQuestionMaster();
            return Ok(rawData);
        }
    }
}