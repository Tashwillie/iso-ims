﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Data.Models;

namespace Mindflur.IMS.API.Controllers.Incident
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/tenant/{tenantId}/question-master")]
    [ApiController]
    public class QuestionController : ControllerBase
    {
        private readonly IQuestionMasterBusiness _questionMasterBusiness;

        public QuestionController(IQuestionMasterBusiness questionMasterBusiness)
        {
            _questionMasterBusiness = questionMasterBusiness;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var question = await _questionMasterBusiness.GetAllQuestionDetails();
            return Ok(question);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] QuestionMaster questionMaster)
        {
            await _questionMasterBusiness.AddQuestionMasterDetails(questionMaster);
            return Ok(string.Format(ControllerConstants.RecordCreatedMessage));
        }

        [HttpDelete]
        public async Task<IActionResult> Delete(int Id)
        {
            await _questionMasterBusiness.DeleteQuestionMasterDetails(Id);
            return Ok(string.Format(ControllerConstants.RecordDeletedMessage));
        }

        [HttpPut]
        public async Task<IActionResult> Put(int Id, [FromBody] PutQuestionMasterView questionMaster)
        {
            await _questionMasterBusiness.UpdateQuestionMasterDetails(questionMaster, Id);
            return Ok(string.Format(ControllerConstants.RecordUpdatedMessage));
        }

        [HttpGet("Id")]
        public async Task<IActionResult> Get(int Id)
        {
            var questions = await _questionMasterBusiness.GetQuestionDetailsById(Id);
            return Ok(questions);
        }
    }
}