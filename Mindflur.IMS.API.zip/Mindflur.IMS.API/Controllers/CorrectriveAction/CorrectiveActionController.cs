﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.Model;
using Mindflur.IMS.Application.ViewModel.View;

namespace Mindflur.IMS.API.Controllers.CorrectriveAction
{
	[ApiVersion("1")]
	[Route("api/v{version:apiVersion}/tenant/{tenantId}")]
	[ApiController]
	public class CorrectiveActionController : BaseController
	{
		private readonly ICorrectiveActionBusiness _correctiveActionBusiness;

		private readonly IChartBusiness _chartBusiness;

		public CorrectiveActionController(ICorrectiveActionBusiness correctiveActionBusiness, IChartBusiness chartBusiness)
		{
			_correctiveActionBusiness = correctiveActionBusiness;

			_chartBusiness = chartBusiness;
		}

		[HttpGet("sourceItemId/{sourceItemId}/tasks/list")]
		public async Task<IActionResult> GetTaskListByCorrectiveAction([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0, int sourceItemId = 0, int workItemTypeId = 0)
		{
			var data = new GetTaskLists()
			{
				ListRequests = new GetListRequest()
				{
					Sort = sort,
					SortColumn = sortColumn,
					PerPage = perPage,
					Page = page
				},

				TenantId = tenantId,
				SourceItemId = sourceItemId,
				WorkItemTypeId = workItemTypeId
			};

			var model = await _correctiveActionBusiness.GetTaskListByCorrectiveAction(data);

			return Ok(model);
		}

		[HttpGet("corrective-action/chart/bar")]
		public async Task<IActionResult> GetAllCorrectiveActionChart([FromRoute] int tenantId, int category = 3)
		{
			if (category >= 1 && category < 4)
			{
				var rawData = await _chartBusiness.GetChartBarGraph(category, tenantId);
				return Ok(rawData);
			}
			else
			{
				return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
			}
		}

		//Donut chart
		[HttpGet("corrective-action/chart/donut")]
		public async Task<IActionResult> CorrectiveActionDonutChart([FromRoute] int tenantId, int category = 1)
		{
			if (category >= 1 && category < 4)
			{
				var rawData = await _chartBusiness.GetChartCorrectiveActionDonuts(category, tenantId);
				return Ok(rawData);
			}
			else
			{
				return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
			}
		}

		

		//in use
		[HttpPut("corrective-action/{workItemId}/metadata")]
		public async Task<IActionResult> PutCorrectiveActionMetadata([FromRoute] int tenantId, [FromRoute] int workItemId, PutCorrectiveActionMetadataViewModel correctiveActionMetadataViewModel)
		{
			await _correctiveActionBusiness.UpsertMetadata(correctiveActionMetadataViewModel, workItemId, UserId, tenantId);
			return NoContent();
		}

		//in use
		[HttpGet("corrective-action/{workItemId}/metadata")]
		public async Task<IActionResult> GetCorrectiveActionMetadata([FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			var metaData = await _correctiveActionBusiness.GetMetadata(workItemId, tenantId);
			return Ok(metaData);
		}

		//in use
		[HttpPut("corrective-action/{workItemId}/metadata/approve")]
		public async Task<IActionResult> ApproveCorrectiveActionMetaData(ApproveCorrectiveActionMetaDataView comments, [FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			await _correctiveActionBusiness.ApproveMetaData(comments, tenantId, workItemId, UserId);
			return NoContent();
		}

		//in use
		[HttpPut("corrective-action/{workItemId}/assign")]
		public async Task<IActionResult> AssignCorrectiveActionMetaData(AssignCorrectiveActionMetaDataView comments, [FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			await _correctiveActionBusiness.AssignCorrectiveActionMetaData(comments, tenantId, workItemId, UserId);
			return NoContent();
		}

		[HttpGet("corrective-action/new/chart/donut")]
		public async Task<IActionResult> CorrectiveActionAllDonutChart([FromRoute] int tenantId)
		{
			var GetCAByStatus = await _chartBusiness.GetChartCorrectiveActionDonuts(1, tenantId);
			var GetCAByAssignTo = await _chartBusiness.GetChartCorrectiveActionDonuts(2, tenantId);
			var GetCAByPriority = await _chartBusiness.GetChartCorrectiveActionDonuts(3, tenantId);
			var TaskListByCA = await _chartBusiness.GetTaskListsCharts(1, tenantId);
			return Ok(new { GetCAByStatus, GetCAByAssignTo, GetCAByPriority, TaskListByCA });
		}

		//in use
		[HttpPut("corrective-action/{workItemId}/metadata/Open")]
		public async Task<IActionResult> OpenCorrectiveActionMetadata([FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			await _correctiveActionBusiness.OpenMetadata(tenantId, workItemId, UserId);
			return NoContent();
		}

		//in use
		[HttpPut("corrective-action/{workItemId}/metadata/Close")]
		public async Task<IActionResult> CloseCorrectiveActionMetadata(CloseCorrectiveActionMetaData closeCorrectiveActionMetaData, [FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			await _correctiveActionBusiness.CloseMetadata(closeCorrectiveActionMetaData, tenantId, workItemId, UserId);
			return NoContent();
		}

		//in use
		[HttpPut("corrective-action/{workItemId}/metadata/Submit")]
		public async Task<IActionResult> SubmitCAMetadata([FromRoute] int tenantId, [FromRoute] int workItemId)
		{
			await _correctiveActionBusiness.SubmitCAMetadata(tenantId, workItemId, UserId);
			return NoContent();
		}
	}
}