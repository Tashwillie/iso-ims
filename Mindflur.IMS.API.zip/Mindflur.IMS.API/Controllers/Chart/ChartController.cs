﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.Application.Contracts.Business;

namespace Mindflur.IMS.API.Controllers.Chart
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/chart")]
    [ApiController]
    public class ChartController : ControllerBase
    {
        

        public ChartController()
        {
            
        }
    }
}