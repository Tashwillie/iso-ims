﻿using Microsoft.AspNetCore.Mvc;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.Application.Contracts.Business;
using Mindflur.IMS.Application.Core.Constants;
using Mindflur.IMS.Application.ViewModel.Core;
using Mindflur.IMS.Application.ViewModel.View;
using System.Net;
using System.Net.Mime;

namespace Mindflur.IMS.API.Controllers.Documents
{
    [Route("api/v{version:apiVersion}/tenant/{tenantId:int}/document")]
    [ApiController]
    public class DocumentController : BaseController
    {
        private readonly IDocumentBusiness _documentBusiness;
        private readonly IChartBusiness _chartBusiness;

        public DocumentController(IDocumentBusiness documentBusiness,IChartBusiness chartBusiness)
        {
            _documentBusiness = documentBusiness;
            _chartBusiness = chartBusiness;
        }

        [HttpGet]
        [Route("list")]
        [ProducesResponseType(typeof(PaginatedItems<DocumentGridView>), (int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public async Task<IActionResult> GetList([FromRoute] int tenantId, [FromQuery] string sort, [FromQuery] string sortColumn, [FromQuery] int perPage = 10, [FromQuery] int page = 0,int documentCategoryId=0)
        {
            var request = new GetDocumentListRequest()
            {
                ListRequests = new GetListRequest()
                {
                    Sort = sort,
                    SortColumn = sortColumn,
                    PerPage = perPage,
                    Page = page
                },
                TenantId = tenantId,
                DocumentCategoryId= documentCategoryId
			};
            var document = await _documentBusiness.GetDocumentList(request);

            return Ok(document);
        }

        [HttpGet()]
        [Route("{id:int}")]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(DocumentPreview), (int)HttpStatusCode.OK)]
        public async Task<IActionResult> GetDocumentById( [FromRoute] int tenantId, [FromRoute] int id)
        {
            var document = await _documentBusiness.GetDocumentsById(id, tenantId, UserId);
            return Ok(document);
        }

        [HttpPost]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Post([FromRoute] int tenantId, PostDocumentView postDocumentView)
        {
            await _documentBusiness.AddDocument(postDocumentView, tenantId, UserId);

            return Ok();
        }

        [HttpPut]
        [Route("{id:int}")]
        public async Task<IActionResult> Put(PutDocumentView putDocument, int id, [FromRoute] int tenantId)
        {
            await _documentBusiness.UpdateDocument(putDocument, id, tenantId, UserId);
            return NoContent();
        }

        [Route("{id:int}")]
        [HttpDelete]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType((int)HttpStatusCode.NotFound)]
        public async Task<IActionResult> Delete(int id, [FromRoute] int tenantId)
        {
            await _documentBusiness.DeleteDocument(id, UserId, tenantId);
            return NoContent();
        }

        [HttpPut("{id}/review")]
        public async Task<IActionResult> Review([FromRoute] int id, [FromRoute] int tenantId, CommentsForDocument document)
        {
            await _documentBusiness.ReviewDocument(id, UserId, tenantId,document);
            return NoContent();
        }

        [HttpPut("{id}/reject")]
        public async Task<IActionResult> Rejected([FromRoute] int id, [FromRoute] int tenantId, CommentsForDocument document)
        {
            await _documentBusiness.RejectDocument(id, UserId, tenantId, document);
            return NoContent();
        }

        [HttpPut("{id}/approve")]
        public async Task<IActionResult> Approve([FromRoute] int id, [FromRoute] int tenantId, CommentsForDocument document)
        {
            await _documentBusiness.ApproveDocument(id, UserId, tenantId, document);
            return NoContent();
        }

        [HttpPut("{id}/publish")]
        public async Task<IActionResult> Publish([FromRoute] int id, [FromRoute] int tenantId, CommentsForDocument document)
        {
            await _documentBusiness.PublishDocument(id, UserId, tenantId, document);
            return NoContent();
        }
        [HttpGet("documents/lists")]
        public async Task<IActionResult> GetTokenByParentTokenId([FromRoute] int tenantId)
        {

            var data = await _documentBusiness.getDatabyMasterGroupId(tenantId);
            if (data == null)
            {
                return BadRequest(string.Format(ControllerConstants.NoRecordsForIdErrorMessage, data));
            }
            else
            {
                return Ok(data);
            }
        }




    
        [HttpGet("donut/chart")]
        public async Task<IActionResult> GetDocumentsDonutChart([FromRoute]int tenantId,int category = 0)
        {
            if (category >= 1 && category < 5)
            {
				var rawData = await _chartBusiness.GetDocumentsDonutChart(category, tenantId);
				return Ok(rawData);
			}
			else
			{
				return BadRequest(string.Format(ControllerConstants.UnsupportedChartCategoryErrorMessage, category));
			}
		}
        [HttpGet("new/chart/donut")]
        public async Task<IActionResult> GetDocumentsAllDonutChart([FromRoute] int tenantId)
        {
            var DocumentByStatus = await _chartBusiness.GetDocumentsDonutChart(1, tenantId);
            var DocumentByCategory = await _chartBusiness.GetDocumentsDonutChart(2, tenantId);
            var DocumentByPriority = await _chartBusiness.GetDocumentsDonutChart(3, tenantId);
            var DocumentByClassification = await _chartBusiness.GetDocumentsDonutChart(4, tenantId);
            return Ok(new { DocumentByStatus, DocumentByCategory, DocumentByPriority, DocumentByClassification });
        }
    }
}