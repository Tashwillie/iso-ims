using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.Extensions.Options;
using Mindflur.IMS.API;
using Mindflur.IMS.API.Authentication;
using Mindflur.IMS.API.Core;
using Mindflur.IMS.API.Core.Middleware;
using Mindflur.IMS.API.Core.Runner;
using Mindflur.IMS.API.Core.Swagger;
using Mindflur.IMS.API.Notification;
using Mindflur.IMS.API.Scheduler;
using Mindflur.IMS.Business;
using Mindflur.IMS.Data;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Quartz;
using Serilog;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.ComponentModel;
using System.Globalization;
using System.Text.Json;
using System.Text.Json.Serialization;

var builder = WebApplication.CreateBuilder(args);

IConfiguration configurationBuilder = new ConfigurationBuilder()
    .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
    .AddJsonFile(
        $"appsettings.{Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")}.json",
        optional: true)
    .Build();

Log.Logger = new LoggerConfiguration()
    .ReadFrom.Configuration(configurationBuilder)
    .CreateBootstrapLogger().Freeze();

builder.Host.UseSerilog((ctx, lc) => lc
        .WriteTo.Console()
        .WriteTo.ApplicationInsights(TelemetryConfiguration.Active, TelemetryConverter.Traces)
        .ReadFrom.Configuration(ctx.Configuration));

IConfiguration Configuration = builder.Configuration;
builder.Services.AddAutoMapper(typeof(Program).Assembly);
builder.Services.AddResponseCaching();

var services = builder.Services;

services.AddApplicationInsightsTelemetry();
services.AddRunnerApplicationServices(Configuration);

/*
services.AddCors(o => o.AddPolicy("MyPolicy", builder =>
{
    builder.WithOrigins(Configuration["FrontendApp"])
           .AllowAnyMethod()
        .AllowAnyHeader()
        .AllowCredentials();
}));
*/

string Urls = Configuration.GetSection("URLWhiteListings").GetSection("URLs").Value;
services.AddCors(options =>
{
    options.AddPolicy("CorsPolicy",
        builder => builder
        .SetIsOriginAllowed((host) => true)
        .AllowAnyMethod()
        .AllowAnyHeader()
        .AllowCredentials());
});

services.AddSignalR();
services.AddPersistanceAutoMapper();
services.AddInfrastructureServices(Configuration);
services.AddPersistenceServices(Configuration);
services.AddBusinessServices(Configuration);
services.AddQuartz(q =>
{
    q.UseMicrosoftDependencyInjectionJobFactory();

    // Just use the name of your job that you created in the Jobs folder.
    var jobKey = new JobKey("SendEmailJob");
    q.AddJob<SendEmailJob>(opts => opts.WithIdentity(jobKey));

    if (!builder.Environment.IsDevelopment())
    {
        //used for qa/stage/production server only!
        q.AddTrigger(opts => opts
            .WithIdentity("SendEmailJob-trigger")
            .WithSchedule(CronScheduleBuilder.DailyAtHourAndMinute(1, 00)// run daily at 1:00am
            .InTimeZone(TimeZoneInfo.FindSystemTimeZoneById("South Africa Standard Time")))
            .ForJob(jobKey)
        );
    }
    else
    {
        // use this only for development
        
           /*   q.AddTrigger(opts => opts
                           .WithIdentity("SendEmailJob-trigger")
                           .StartAt(DateTime.UtcNow)
                           .ForJob(jobKey));*/
        

       q.AddTrigger(opts => opts
          .WithIdentity("SendEmailJob-trigger")
          .WithSchedule(CronScheduleBuilder.DailyAtHourAndMinute(1, 00)// run daily at 1:00am
          .InTimeZone(TimeZoneInfo.FindSystemTimeZoneById("South Africa Standard Time")))
          .ForJob(jobKey)
      );
    }
});

// ASP.NET Core hosting
services.AddQuartzServer(options =>
{
    // when shutting down we want jobs to complete gracefully
    options.WaitForJobsToComplete = true;
});



services.AddWebAPIInfrastructureServices(Configuration);

services.ConfigureJWT(Configuration);
services.AddHostedService<IMSBackgroundService>();
services.AddSwaggerExtension();
services.AddSwaggerVersionedApiExplorer();
services.AddTransient<IConfigureOptions<SwaggerGenOptions>, ConfigureSwaggerOptions>();
services.AddSwaggerGen(options => options.OperationFilter<SwaggerDefaultValues>());
services.AddControllers();
			/*.AddNewtonsoftJson(options =>
			{
				options.SerializerSettings.DateTimeZoneHandling = DateTimeZoneHandling.Utc;
				options.SerializerSettings.DateFormatString = "MM-dd-yyyy";
				options.SerializerSettings.Converters.Add(new StringEnumConverter());
			});*/
services.AddDataProtection()
    .PersistKeysToFileSystem(new DirectoryInfo(@"bin\debug\configuration"));

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle

builder.Services.AddEndpointsApiExplorer();
var app = builder.Build();

// Configure the HTTP request pipeline.
app.UseHttpsRedirection();

app.UseAuthentication();

app.UseSwagger();

// Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.),
// specifying the Swagger JSON endpoint.
IApiVersionDescriptionProvider provider = app.Services.GetRequiredService<IApiVersionDescriptionProvider>();

app.UseSwaggerUI(
        options =>
        {
            // build a swagger endpoint for each discovered API version
            foreach (var description in provider.ApiVersionDescriptions)
            {
                options.SwaggerEndpoint($"/swagger/{description.GroupName}/swagger.json", description.GroupName.ToUpperInvariant());
            }
        });

app.UseCustomExceptionHandler();
app.UseResponseCaching();
app.UseCors("CorsPolicy");

app.UseRouting();
app.UseAuthorization();
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllers();
    endpoints.MapHub<NotificationsHub>("/hub/notificationhub");
});

app.Run();

public partial class Program
{
}

/*public class DateTimeConverter : JsonConverter<DateTime>
{
    private const string DateTimeFormat = "MM-dd-yyyy";

    public override DateTime Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        if (DateTime.TryParseExact(reader.GetString(), DateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out var result))
            return result;

        return default;
    }

    public override void Write(Utf8JsonWriter writer, DateTime value, JsonSerializerOptions options)
    {
        writer.WriteStringValue(value.ToString(DateTimeFormat));
    }
}*/