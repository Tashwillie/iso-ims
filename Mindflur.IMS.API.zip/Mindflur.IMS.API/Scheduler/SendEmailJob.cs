﻿using Mindflur.IMS.Runners;
using Quartz;

namespace Mindflur.IMS.API.Scheduler
{
    public class SendEmailJob : IJob
    {
        private readonly ILogger<SendEmailJob> _logger;
        private readonly IReminders _reminders;

        public SendEmailJob(ILogger<SendEmailJob> logger, IReminders reminders)
        {
            _logger = logger;
            _reminders = reminders;
        }

        public async Task Execute(IJobExecutionContext context)
        {
            // Code that sends a periodic email to the user (for example)
            // Note: This method must always return a value
            // This is especially important for trigger listers watching job execution

            _logger.LogDebug("Send email job started");

            await _reminders.Start();
        }
    }
}