﻿namespace Mindflur.IMS.Data.Models
{
    public partial class IncidentCorrectiveActionMapping
    {
        public int Id { get; set; }
        public int IncidentId { get; set; }
        public int CorrectiveActionId { get; set; }
    }
}