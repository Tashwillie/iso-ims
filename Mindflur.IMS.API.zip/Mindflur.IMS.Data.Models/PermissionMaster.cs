﻿using System.ComponentModel.DataAnnotations;

namespace Mindflur.IMS.Data.Models
{
    public class PermissionMaster
    {
        [Key]
        public int PermissionId { get; set; }

        public int ControllerMasterId { get; set; }
        public int ControllerActionMasterId { get; set; }
    }
}