﻿namespace Mindflur.IMS.Data.Models
{
    public partial class Risk
    {
        public int Id { get; set; }
        public int WorkItemId { get; set; }
        public DateTime InitialDate { get; set; }
      
        public string? CurrentControls { get; set; }
     
        public int? TotalRiskScore { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int? UpdatedBy { get; set; }

        public bool? IsApproved { get; set; }
        public int? ApprovedBy { get; set; }
        public DateTime? ApprovedOn { get; set; }

        public int? ReviewedBy { get; set; }
        public DateTime? ReviewedOn { get; set; }
    }
}