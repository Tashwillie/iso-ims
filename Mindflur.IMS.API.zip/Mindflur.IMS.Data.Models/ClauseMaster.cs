﻿using System.ComponentModel.DataAnnotations;

namespace Mindflur.IMS.Data.Models
{
    public partial class ClauseMaster
    {
        [Key]
        public int Id { get; set; }

        public string ClauseNo { get; set; } = null!;
        public string ClauseName { get; set; } = null!;
        public int ClauseGroup { get; set; }
    }
}