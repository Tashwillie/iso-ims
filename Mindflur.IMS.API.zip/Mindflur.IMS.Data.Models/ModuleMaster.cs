﻿namespace Mindflur.IMS.Data.Models
{
    public partial class ModuleMaster
    {
        public int Id { get; set; }
        public string ModuleName { get; set; } = null!;
        public int SubId { get; set; }
    }
}