﻿

namespace Mindflur.IMS.Data.Models
{
    public class IncidentMetaData
    {
        public int IncidentMetadataId { get; set; }
        public int ?WorkItemId { get; set; }
        public DateTime? DateOfIncident { get; set; }
        public int? OccupationId { get; set; }
        public bool? AllowedToBeClosed { get; set; }
        public bool? WorkResumed { get; set; }
        public bool? WearedPpe { get; set; }
        public string InjuryDescription { get; set; }
        public string HowItOccured { get; set; }
        public string MedicalTreatment { get; set; }
        public string ClassificationDescription { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int? ApprovedBy { get; set; }
        public DateTime? ApprovedOn { get; set; }
		public int? ReviewedBy { get; set; }
		public DateTime? ReviewedOn { get; set; }
		public bool? IsApproved { get; set; }
    }
}
