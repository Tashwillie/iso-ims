﻿namespace Mindflur.IMS.Data.Models
{
    public partial class ProjectMember
    {
        public int ProjectMemberId { get; set; }
        public int ProjectId { get; set; }
        public int UserId { get; set; }
        public int? Role { get; set; }
    }
}