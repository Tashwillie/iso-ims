﻿namespace Mindflur.IMS.Data.Models
{
    public partial class RiskTreatment
    {
        public int Id { get; set; }
        public int RiskId { get; set; }
        public int TreatmentOptionMasterDataId { get; set; }
        public string MitigationPlan { get; set; } = null!;
        public int CurrentStatusMasterDataId { get; set; }
        public int ProbabilityMasterDataId { get; set; }
        public int ConsequenceMasterDataId { get; set; }
        public int RiskRatingMasterDataId { get; set; }
        public int TotalRiskScore { get; set; }
        public DateTime DueDate { get; set; }
        public int ResponsibleUserId { get; set; }
        public int? AssignedToUserId { get; set; }
        public DateTime? ReviewedOn { get; set; }
        public int? ReviewedBy { get; set; }
        public int OpportunityId { get; set; }
        public int? CreatedBy { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int? ApprovedBy { get; set; }
        public DateTime? ApprovedOn { get; set; }
    }
}