﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mindflur.IMS.Data.Models
{
    public class AuditFindingsMapping
    {
        public int Id { get; set; }
        public int? AuditableItemId { get; set; }
        public int? WorkItemId { get; set; }
        public int? AuditChecklistId { get; set; }
        public bool? FollowUp { get; set; }
       
    }
}
