﻿using System.ComponentModel.DataAnnotations;

namespace Mindflur.IMS.Data.Models
{
    public partial class AuditableItem
    {
        [Key]
        public int Id { get; set; }

        public int AuditProgramId { get; set; }

       // public string Department { get; set; } = null!;
        public string? Description { get; set; }
        public int Status { get; set; }
       // public int Type { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int AuditorName { get; set; }
        public int DepartmentId { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
    }
}