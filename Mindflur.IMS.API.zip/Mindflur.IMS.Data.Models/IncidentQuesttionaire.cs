﻿using System.ComponentModel.DataAnnotations;

namespace Mindflur.IMS.Data.Models
{
    public partial class IncidentQuesttionaire
    {
        [Key]
        public int Id { get; set; }

        public int IncidentId { get; set; }
        public int QuestionId { get; set; }

        public bool Response { get; set; }

        public string? Description { get; set; }
    }
}