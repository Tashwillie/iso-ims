﻿namespace Mindflur.IMS.Data.Models
{
    public class OpportunitiesMaster
    {
        public int Id { get; set; }
        public int TenantId { get; set; }
        public int? Source { get; set; }
        public int? SourceId { get; set; }
        public string OpportunitesDescription { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
    }
}