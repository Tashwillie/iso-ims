﻿namespace Mindflur.IMS.Data.Models
{
    public class TenantTheme
    {
        public int ThemeId { get; set; }
        public int TenantId { get; set; }
        public int? SiteLogoPathId { get; set; }
        public int? SiteIconPathId { get; set; }
        public int? CoverPathId { get; set; }
        public string? ApplicationTitle { get; set; }
        public string? ApplicationDescription { get; set; }
        public string? ApplicationFooterTextLeft { get; set; }
        public string? ApplicationFooterTextRight { get; set; }
        public string? ApplicationFooterTextLinkLeft { get; set; }
        public string? ApplicationFooterTextLinkRight { get; set; }
        public string? Primary { get; set; }
        public string? Secondory { get; set; }
        public string? Success { get; set; }
        public string? Danger { get; set; }
        public string? Warning { get; set; }
        public string? Info { get; set; }
        public string? Dark { get; set; }
        public string? Light { get; set; }
        public string? ThemeDarkBodyBg { get; set; }
        public string? ThemeDarkBodyColor { get; set; }
        public string? ThemeDarkBorderColor { get; set; }
        public string? ThemeDarkCustomControlBorderColor { get; set; }
        public string? ThemeDarkHeadingsColor { get; set; }
        public string? ThemeDarkLabelColor { get; set; }
        public string? ThemeDarkTextMutedColor { get; set; }
        public string? ThemeDarkCardBg { get; set; }
        public string? ThemeDarkInputBg { get; set; }
        public string? ThemeDarkInputPlaceholderColor { get; set; }
        public string? ThemeDarkInputBorderColor { get; set; }
        public string? ThemeDarkInputDisabledBg { get; set; }
        public string? ThemeDarkInputDisabledBorderColor { get; set; }
        public string? ThemeDarkSwitchBg { get; set; }
        public string? ThemeDarkSwitchBgDisabled { get; set; }
        public string? ThemeDarkTableBg { get; set; }
        public string? ThemeDarkTableHeaderBg { get; set; }
        public string? ThemeDarkTableRowBg { get; set; }
        public string? ThemeDarkTableHoverBg { get; set; }
        public string? ThemeDarkTableStripedBg { get; set; }
        public string? ThemeDarkModalHeaderBg { get; set; }
        public string? ThemeDarkPaginationBg { get; set; }
        public string? ThemeDarkChartBg { get; set; }
        public string? ThemeDarkWidgetBg { get; set; }
        public DateTime CreatedOn { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int? UpdatedBy { get; set; }
    }
}