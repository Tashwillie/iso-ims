﻿namespace Mindflur.IMS.Data.Models
{
    public partial class TaskComplition
    {
        public int Id { get; set; }
        public int TaskId { get; set; }
        public int Source { get; set; }
        public int SourceId { get; set; }
        public string Comments { get; set; } = null!;
        public DateTime CreatedOn { get; set; }
        public int CreatedBy { get; set; }
    }
}