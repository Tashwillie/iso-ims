﻿namespace Mindflur.IMS.Data.Models
{
    public partial class ProjectTag
    {
        public int ProjectTagId { get; set; }
        public int WorkItemId { get; set; }
        public int MasterDataProjectTagId { get; set; }
    }
}