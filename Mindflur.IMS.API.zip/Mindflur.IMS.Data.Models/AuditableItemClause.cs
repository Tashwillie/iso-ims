﻿namespace Mindflur.IMS.Data.Models
{
    public partial class AuditableItemClause
    {
        public int AuditableItemClauseId { get; set; }
        public int AuditableItemId { get; set; }
        public int MasterDataStandardId { get; set; }
        
    }
}