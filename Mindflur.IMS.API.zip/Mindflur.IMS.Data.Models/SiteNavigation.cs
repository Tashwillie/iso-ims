﻿namespace Mindflur.IMS.Data.Models
{
    public partial class SiteNavigation
    {
        public int Id { get; set; }
        public string? NavigationId { get; set; }
        public string? Header { get; set; }
        public string? Title { get; set; }
        public string? NavigationLink { get; set; }
        public string? Actions { get; set; }
        public string? Resource { get; set; }
    }
}