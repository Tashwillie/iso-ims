﻿namespace Mindflur.IMS.Data.Models
{
    public class Participant
    {
        public int ParticipantId { get; set; }
        public int ModuleId { get; set; }
        public int ModuleEntityId { get; set; }
        public int RoleId { get; set; }
        public int UserId { get; set; }
        public DateTime? MarkPresent { get; set; }
        public bool? IsPresent { get; set; }
        public DateTime CreatedOn { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? DeletedOn { get; set; }
        public int? DeletedBy { get; set; }
    }
}