﻿namespace Mindflur.IMS.Data.Models
{
    public class Comment
    {
        public int CommentId { get; set; }
        public int SourceId { get; set; }
        public int SourceItemId { get; set; }
        public string CommentContent { get; set; }
        public int? ParentCommentId { get; set; }
        public int ContentType { get; set; }
        public DateTime CreatedOn { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? DeletedOn { get; set; }
        public int? DeletedBy { get; set; }
      
    }
}