﻿namespace Mindflur.IMS.Data.Models
{
    public partial class TenanttMaster
    {
        public int TenantId { get; set; }
        public string? Name { get; set; } = null!;
        public string? ShortCode { get; set; } = null!;
        public string? ClientName { get; set; } = null!;
        public string? ClientId { get; set; }
        public string? RSAPublicKey { get; set; }
        public string? Kid { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? DeletedOn { get; set; }
        public int? DeletedBy { get; set; }
    }
}