﻿using System.ComponentModel.DataAnnotations;

namespace Mindflur.IMS.Data.Models
{
    public partial class IncidentQuestionMaster
    {
        [Key]
        public int Id { get; set; }

        public int GroupId { get; set; }
        public string Questions { get; set; } = null!;
    }
}