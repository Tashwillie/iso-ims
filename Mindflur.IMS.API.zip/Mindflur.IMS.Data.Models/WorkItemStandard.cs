﻿namespace Mindflur.IMS.Data.Models
{
    public class WorkItemStandard
    {
        public int WorkItemStandardId { get; set; }
        public int WorkItemId { get; set; }
        public int StandardId { get; set; }
    }
}
