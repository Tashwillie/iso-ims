﻿using System.ComponentModel.DataAnnotations;

namespace Mindflur.IMS.Data.Models
{
    public partial class SurveyMaster
    {
        [Key]
        public int Id { get; set; }

        public string GroupTitle { get; set; } = null!;
        public bool HasComment { get; set; }
        public int ParentId { get; set; }
        public bool? SubGroupHasComment { get; set; }
        public string? Description { get; set; }
    }
}