﻿namespace Mindflur.IMS.Data.Models
{
    public class SurveySupplierMapping
    {
        public int Id { get; set; }
        public int SurveyMasterId { get; set; }
        public int SupplierMasterId { get; set; }
    }
}