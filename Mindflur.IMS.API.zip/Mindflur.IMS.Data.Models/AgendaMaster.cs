﻿namespace Mindflur.IMS.Data.Models
{
    public partial class AgendaMaster
    {
        public int AgendaId { get; set; }
        public string Title { get; set; } = null!;
        public int? ParentAgendaId { get; set; }
        public bool IsInputType { get; set; }
        public bool IsSet { get; set; }
    }
}