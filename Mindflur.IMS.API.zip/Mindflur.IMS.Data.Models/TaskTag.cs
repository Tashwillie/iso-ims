﻿namespace Mindflur.IMS.Data.Models
{
    public partial class TaskTag
    {
        public int TaskTagId { get; set; }
        public int MasterDataTaskTagId { get; set; }
        public int TaskId { get; set; }
    }
}