﻿namespace Mindflur.IMS.Data.Models
{
    public partial class SurveyResponseMaster
    {
        public int SurveyResponseId { get; set; }
        public int SurveyId { get; set; }
        public int SurveyQuestionId { get; set; }
        public int SurveyOfferedAnswerId { get; set; }
        public int UserId { get; set; }
    }
}