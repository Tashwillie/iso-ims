﻿namespace Mindflur.IMS.Data.Models
{
    public class ProcessMaster
    {
        public int ProcessId { get; set; }
        public int? ParentProcessId { get; set; }
        public string ProcessText { get; set; }
        public int TenantId { get; set; }
        public int DepartmentId { get; set; }
        public int OwnedBy { get; set; }
        public int? ProcessGroupMasterDataId { get; set; }
        public int? ProcessCategoryMasterDataId { get; set; }
        public int? StatusMasterDataId { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int? UpdatedBy { get; set; }

    }
    
}
