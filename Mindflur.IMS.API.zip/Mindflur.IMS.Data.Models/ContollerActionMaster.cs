﻿namespace Mindflur.IMS.Data.Models
{
    public class ContollerActionMaster
    {
        public int ActionId { get; set; }
        public string ControllerAction { get; set; }
    }
}