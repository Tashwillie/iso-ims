﻿namespace Mindflur.IMS.Data.Models.Custom
{
    public record CheccklistItemData
    {
        public int ClauseId { get; init; }
        public string ClauseTitle { get; init; }
        public int QuestionId { get; init; }
        public string QuestionText { get; init; }
        public string Comments { get; init; }
        public int ClassificationId { get; init; }
        public string ClassificationTitle { get; init; }

        public bool IsCompliance { get; init; }
        public int SequenceNumber { get; init; }
    }
}