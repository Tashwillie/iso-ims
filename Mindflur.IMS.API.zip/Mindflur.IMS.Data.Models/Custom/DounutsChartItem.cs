﻿namespace Mindflur.IMS.Data.Models.Custom
{
    public class DounutsChartItem
    {
        public string ChartItemKey { get; set; }
        public int ChartItemValue { get; set; }
    }
}