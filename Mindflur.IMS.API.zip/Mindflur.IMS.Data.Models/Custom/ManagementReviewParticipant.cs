﻿namespace Mindflur.IMS.Data.Models.Custom
{
    public class ManagementReviewParticipant
    {
        public int UserId { get; set; }
        public string Name { get; set; }
        public string EmailAddress { get; set; }
        public int MeetingID { get; set; }
        public string MeetingTitle { get; set; }

        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Venue { get; set; }
    }
}