﻿namespace Mindflur.IMS.Data.Models.Custom
{
    public class BarGraphChartItem
    {
        public string ChartItemKey { get; set; }
        public int ChartItemValue { get; set; }
        public string ChartItemDate { get; set; }
    }

    public class ComplianceClause
    {
        public string Clause { get; set; }
        public bool Compliance { get; set; }
        public int Total { get; set; }
    }

    public class AuditFindingChart
    {
        public string Classification { get; set; }

        public string FindingStatus { get; set; }
        public int ChartItemValue { get; set; }
    }

    public class AuditFindingRiskRatingChart
    {
        public string Departments { get; set; }

        public string RiskRatings { get; set; }
        public int Total { get; set; }
    }

    public class AuditComplianceBySectionChart
    {
        public string ClauseName { get; set; }

        public string Compliance { get; set; }
        public int ChartItemValue { get; set; }
    }

    public class surveyResponse
    {
        public string QuestionName { get; set; }

        public string ResponseName { get; set; }
        public int ResponseCount { get; set; }
    }
}