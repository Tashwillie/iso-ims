﻿namespace Mindflur.IMS.Data.Models.Custom
{
	public class MinutesTaks
	{
		public string Name { get; set; }
		public int TaskId { get; set; }
		public int MeetingId { get; set; }
		public string MeetingTitle { get; set; }
		public string TaskTitle { get; set; }
		public string Description { get; set; }
		public string EmailAddress { get; set; }
		public string Status { get; set; }
	}

	public class TaskMetaDataMinutes
	{
		public bool? IsAcknowledge { get; set; }
	}
}