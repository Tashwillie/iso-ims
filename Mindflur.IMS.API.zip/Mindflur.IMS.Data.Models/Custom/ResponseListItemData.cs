﻿namespace Mindflur.IMS.Data.Models.Custom
{
    public record ResponseListItemData
    {
        public int QuestionId { get; set; }
        public string QuestionText { get; set; }
        public string Options { get; set; }
        public int Response { get; set; }
    }
    public record TokenListItemData
    {
        public int TokenId { get; set; }
        public string TokenName { get; set; }
        public int ParentTokenId { get; set; }
        public string Parent { get; set; }
    }
	public record ClausesListItemData
	{
		public int ClauseId { get; set; }
        public int StandardId { get; set; }
		public string ClauseNumberText { get; set; }
		public string DisplayText { get; set; }
		public int ParentId { get; set; }
        public string Parent { get; set; }


	}
    public record CompliancePercentageValue
    {
        public int TotalValue { get; set; }
        public int EvaluatedValue { get; set; }
        public float PercentageValue { get; set; }
    }
	public record ReviewedPercentageValue
	{
        public int TotalValue { get; set; }
        public int EvaluatedValue { get; set; }
        public float PercentageValue { get; set; }
	}
}