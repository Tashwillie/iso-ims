﻿namespace Mindflur.IMS.Data.Models.Custom
{
    public class GetCorrectiveActionForEmail
    {
        public string EmailAddress { get; set; }
        public string Name { get; set; }
        public int NCId { get; set; }
        public string Title { get; set; }
        public string ActionRequired { get; set; }
        public string Description { get; set; }
    }
}