﻿namespace Mindflur.IMS.Data.Models.Custom
{
    public class AuiditItemData
    {
        public int Id { get; set; }

        public int AuditProgramId { get; set; }
        public string AuditableItems { get; set; } = null!;
        public string? Description { get; set; }
        public int Type { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int AuditorId { get; set; }
        public string AuditorName { get; set; }
        public int DepartmentId { get; set; }
        public string DepartmentName { get; set; }
        public int MasterDataStandardId { get; set; }
        public string Standards { get; set; }
        public int ClauseId { get; set; }
        public string ClauseNo { get; set; }
    }
}