﻿namespace Mindflur.IMS.Data.Models.Custom
{
    public class NonConfirmityCorretiveActionTask
    {
        public string Name { get; set; }
        public int NcId { get; set; }

        public string NcTitle { get; set; }
        public string CorrectiveActionRequired { get; set; }
        public string TaskTitle { get; set; }
        public string EmailAddress { get; set; }
    }
}