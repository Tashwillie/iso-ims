﻿namespace Mindflur.IMS.Data.Models
{
    public partial class MeetingAgendaMapping
    {
        public int MappingId { get; set; }
        public int MeetingId { get; set; }
        public int AgendaId { get; set; }
    }
}