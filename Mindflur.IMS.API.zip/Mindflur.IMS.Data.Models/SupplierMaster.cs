﻿namespace Mindflur.IMS.Data.Models
{
    public partial class SupplierMaster
    {
        public int SupplierId { get; set; }
        public int TenantId { get; set; }
        public string SupplierName { get; set; } = null!;
        public string EmailAddress { get; set; } = null!;
        public string? ContactPerson { get; set; }
        public string? ContactNumber { get; set; }
        public string? SupplierLocation { get; set; }
        public int? DepartmentId { get; set; }
        public int MasterDataSupplierStatusId { get; set; }
        public DateTime CreatedOn { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int? UpdatedBy { get; set; }
    }
}