﻿namespace Mindflur.IMS.Data.Models
{
    public partial class AuditSettings
    {
        public int AuditSettingId { get; set; }
        public int? TenantId { get; set; }

        public int? CreateAuditPlanRoleId { get; set; }
        public int? PublishAuditPlanRoleId { get; set; }
        public int? AddAuditScheduleRoleId { get; set; }
        public int? CreateAuditRoleId { get; set; }
        public int? AddFindingsRoleId { get; set; }
        public int? AddCorrectiveActionRoleId { get; set; }
        public int? AcceptResolvedCorrectiveActionRoleId { get; set; }
        public int? AcceptResolvedFindingRoleId { get; set; }

        public DateTime CreatedOn { get; set; }
    }
}