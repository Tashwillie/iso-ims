﻿namespace Mindflur.IMS.Data.Models
{
    public partial class ChecklistMaster
    {
        public int Id { get; set; }
        public int ClauseMasterId { get; set; }
        public int? TenantId { get; set; }
        public string Questions { get; set; } = null!;
        public int? OrderNo { get; set; }
    }
}