﻿namespace Mindflur.IMS.Data.Models
{
    public partial class NonConformity
    {
        public int Id { get; set; }
        public int TenantId { get; set; }
        public int? Source { get; set; }
        public int? SourceId { get; set; }
        public string? Title { get; set; }
        public int? Originator { get; set; }
        public int? Department { get; set; }
        public DateTime? DueDate { get; set; }
        public int? NcTypes { get; set; }
        public int? Category { get; set; }
        public int? Status { get; set; }
        public string? Description { get; set; }

        public int? ResponsiblePerson { get; set; }
        public int? AssignTo { get; set; }
        public int? CreatedBy { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int? ApprovedBy { get; set; }
        public DateTime? ApprovedOn { get; set; }
        public DateTime? CreatedOn { get; set; }
    }
}