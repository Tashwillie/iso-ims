﻿namespace Mindflur.IMS.Data.Models
{
    public partial class AuditFinding
    {
        public int Id { get; set; }
        public int AuditProgramId { get; set; }
        public int AuditableItemId { get; set; }
        public string Title { get; set; }
        public string? Description { get; set; }
        public int? MasterDataFindingCategoryId { get; set; }
        public int MasterDataFindingStatusId { get; set; }
        public int? Department { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
    }
}