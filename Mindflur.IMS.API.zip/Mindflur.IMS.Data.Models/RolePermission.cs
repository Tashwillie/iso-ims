﻿namespace Mindflur.IMS.Data.Models
{
    public class RolePermission
    {
        public int RolePermissionId { get; set; }
        public int TanentId { get; set; }
        public int RoleId { get; set; }
        public int ControllerId { get; set; }
        public int? ActionId { get; set; }
    }
}