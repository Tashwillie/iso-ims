﻿namespace Mindflur.IMS.Data.Models
{
    public partial class ProgramStandard
    {
        public int Id { get; set; }
        public int MasterDataStandardId { get; set; }
        public int AuditProgramId { get; set; }
    }
}