﻿namespace Mindflur.IMS.Data.Models
{
    public partial class MinutesOfMeeting
    {
        public int Id { get; set; }
        public int MeetingId { get; set; }
        public int AgendaId { get; set; }
        public int TaskId { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedOn { get; set; }
    }
}