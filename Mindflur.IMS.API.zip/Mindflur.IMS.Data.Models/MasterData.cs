﻿using System.ComponentModel.DataAnnotations;

namespace Mindflur.IMS.Data.Models
{
    public partial class MasterData
    {
        [Key]
        public int Id { get; set; }

        public int TenantId { get; set; }
        public string Items { get; set; } = null!;
        public int MasterDataGroupId { get; set; }
        public int? ParentId { get; set; }
        public int? OrderId { get; set; }
        public bool Active { get; set; }
    }
}