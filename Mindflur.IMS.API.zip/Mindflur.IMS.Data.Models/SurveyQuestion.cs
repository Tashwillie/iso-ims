﻿namespace Mindflur.IMS.Data.Models
{
    public partial class SurveyQuestion
    {
        public int SurveyQuestionId { get; set; }
        public int QuestionId { get; set; }
        public int SurveyId { get; set; }
        public int OfferedAnswerId { get;set; }
        public string Comments { get; set; }
        public int SequenceNumber { get; set; }
    }
}