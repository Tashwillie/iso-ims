﻿

namespace Mindflur.IMS.Data.Models
{
	public partial class RiskAssesmentMaster
	{
		public int Id { get; set; }

		public int RiskId { get; set; }
		public int? SourceImpact { get; set; }
		public int? SourceProbrability { get; set; }
		public int? CurrentImpact { get; set; }
		public int? CurrentProbability { get; set; }
        public int? ResidualRiskRating { get; set; }
        public int? ResidualRiskScore { get; set; }
        public int? CreatedBy { get; set; }
		public DateTime? CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
    }
}
