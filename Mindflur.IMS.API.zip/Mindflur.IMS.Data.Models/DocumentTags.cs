﻿namespace Mindflur.IMS.Data.Models
{
    public class DocumentTags
    {
        public int DocumentTagId { get; set; }
        public int DocumentId { get; set; }
        public int MasterDataDocumentTagId { get; set; }
    }
}