﻿namespace Mindflur.IMS.Data.Models
{
	public class WorkItemWorkItemToken
	{
		public int Id { get; set; }
		public int WorkItemId { get; set; }
		public int TokenId { get; set; }
	}
}
