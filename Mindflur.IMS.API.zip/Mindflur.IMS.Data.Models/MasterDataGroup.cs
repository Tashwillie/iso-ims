﻿namespace Mindflur.IMS.Data.Models
{
    public partial class MasterDataGroup
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
    }
}