﻿namespace Mindflur.IMS.Data.Models
{
    public partial class MeetingAttendence
    {
        public int Id { get; set; }
        public int MeetingId { get; set; }
        public int DepartmentId { get; set; }
        public int ParticipantsId { get; set; }
    }
}