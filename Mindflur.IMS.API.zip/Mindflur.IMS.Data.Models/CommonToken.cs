﻿namespace Mindflur.IMS.Data.Models
{
    public class CommonToken
    {
       
        public int TokenId { get; set; }
        public int TenantId { get; set; }
        public int? Weightage { get; set; }
        public string? TokenName { get; set; }
        public string? DisplayName { get; set; }
        public int? SeqeunceNumber { get; set; }
        
        public int? ParentTokenId { get; set; }
      
    }
}
