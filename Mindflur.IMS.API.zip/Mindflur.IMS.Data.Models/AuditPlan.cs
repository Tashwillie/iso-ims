﻿using System.ComponentModel.DataAnnotations;

namespace Mindflur.IMS.Data.Models
{
    public partial class AuditPlan
    {
        [Key]
        public int Id { get; set; }

        public int AuditProgramId { get; set; }
        public string Scope { get; set; } = null!;
        public string Objectives { get; set; } = null!;
    }
}