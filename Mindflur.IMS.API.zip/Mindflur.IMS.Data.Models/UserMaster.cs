﻿namespace Mindflur.IMS.Data.Models
{
    public partial class UserMaster
    {
        public int UserId { get; set; }
        public string? KCUserId { get; set; }
        public int TenantId { get; set; }
        public int RoleId { get; set; }
        public string? KCUsername { get; set; } = null!;
        public string FirstName { get; set; } = null!;
        public string LastName { get; set; } = null!;
        public string EmailId { get; set; } = null!;

        public int? DepartmentId { get; set; }

        public int? Status { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? DeletedOn { get; set; }
        public int? DeletedBy { get; set; }
    }
}