﻿namespace Mindflur.IMS.Data.Models
{
    public partial class MasterDatum
    {
        public int Id { get; set; }

        public string Items { get; set; } = null!;
        public int MasterDataGroupId { get; set; }
        public int? ParentId { get; set; }
        public int? OrderId { get; set; }
        public bool Active { get; set; }
    }
}