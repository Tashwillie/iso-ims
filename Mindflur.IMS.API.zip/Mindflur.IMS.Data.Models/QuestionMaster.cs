﻿namespace Mindflur.IMS.Data.Models
{
    public partial class QuestionMaster
    {
        public int QuestionId { get; set; }
        public string Title { get; set; } = null!;
    }
}