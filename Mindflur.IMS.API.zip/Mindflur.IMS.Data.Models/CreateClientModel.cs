﻿using System.Text.Json.Serialization;

namespace Mindflur.IMS.Data.Models
{
    public class CreateClientModel
    {
        [JsonPropertyName("protocol")]
        public string Protocol { get; set; }

        [JsonPropertyName("clientId")]
        public string ClientId { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("description")]
        public string Description { get; set; }

        [JsonPropertyName("publicClient")]
        public bool PublicClient { get; set; }

        [JsonPropertyName("authorizationServicesEnabled")]
        public bool AuthorizationServicesEnabled { get; set; }

        [JsonPropertyName("serviceAccountsEnabled")]
        public bool ServiceAccountsEnabled { get; set; }

        [JsonPropertyName("implicitFlowEnabled")]
        public bool ImplicitFlowEnabled { get; set; }

        [JsonPropertyName("directAccessGrantsEnabled")]
        public bool DirectAccessGrantsEnabled { get; set; }

        [JsonPropertyName("standardFlowEnabled")]
        public bool StandardFlowEnabled { get; set; }

        [JsonPropertyName("frontchannelLogout")]
        public bool FrontchannelLogout { get; set; }

        [JsonPropertyName("alwaysDisplayInConsole")]
        public bool AlwaysDisplayInConsole { get; set; }

        [JsonPropertyName("attributes")]
        public Attributes attributes { get; set; }
    }

    public class Attributes
    {
        [JsonPropertyName("oauth2.device.authorization.grant.enabled")]
        public bool AuthorizationGrantEnabled { get; set; }

        [JsonPropertyName("oidc.ciba.grant.enabled")]
        public bool CibaGrantEnabled { get; set; }
    }

    public class KeyClockRole
    {
        [JsonPropertyName("id")]
        public string Id { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; }
    }

    public class KeyClockUser
    {
        [JsonPropertyName("id")]
        public string Id { get; set; }

        [JsonPropertyName("username")]
        public string userName { get; set; }
    }

    public class KeyClockClient
    {
        [JsonPropertyName("id")]
        public string Id { get; set; }

        [JsonPropertyName("clientId")]
        public string ClientId { get; set; }
    }

    public class KeyClockCreateRealmModel
    {
        [JsonPropertyName("realm")]
        public string Realm { get; set; }

        [JsonPropertyName("enabled")]
        public bool Enabled { get; set; }
    }

    public class KeyClockCreateRoleModel
    {
        [JsonPropertyName("name")]
        public string Name { get; set; }
    }

    public class KeyClockCreateUserModel
    {
        [JsonPropertyName("username")]
        public string UserName { get; set; }

        [JsonPropertyName("email")]
        public string Email { get; set; }

        [JsonPropertyName("firstName")]
        public string FirstName { get; set; }

        [JsonPropertyName("lastName")]
        public string LastName { get; set; }

        [JsonPropertyName("emailVerified")]
        public bool EmailVerified { get; set; }

        [JsonPropertyName("enabled")]
        public bool Enabled { get; set; }

        [JsonPropertyName("requiredActions")]
        public List<string> RequiredActions { get; set; }

        [JsonPropertyName("groups")]
        public List<string> Groups { get; set; }
    }

    public class KeyClockEditUserModel
    {
        [JsonPropertyName("username")]
        public string UserName { get; set; }

        [JsonPropertyName("email")]
        public string Email { get; set; }

        [JsonPropertyName("firstName")]
        public string FirstName { get; set; }

        [JsonPropertyName("lastName")]
        public string LastName { get; set; }

        [JsonPropertyName("emailVerified")]
        public bool EmailVerified { get; set; }

        [JsonPropertyName("enabled")]
        public bool Enabled { get; set; }

        [JsonPropertyName("requiredActions")]
        public List<string> RequiredActions { get; set; }

        [JsonPropertyName("groups")]
        public List<string> Groups { get; set; }
    }

    public class KeyClockCreatePasswordModel
    {
        [JsonPropertyName("temporary")]
        public bool Temporary { get; set; }

        [JsonPropertyName("type")]
        public string Type { get; set; }

        [JsonPropertyName("value")]
        public string Value { get; set; }
    }

    
    public class Active
    {
        public string HS256 { get; set; }

        [JsonPropertyName("RSA-OAEP")]
        public string RSAOAEP { get; set; }

        public string RS256 { get; set; }
        public string AES { get; set; }
    }

    public class Key
    {
        public string providerId { get; set; }
        public int providerPriority { get; set; }
        public string kid { get; set; }
        public string status { get; set; }
        public string type { get; set; }
        public string algorithm { get; set; }
        public string use { get; set; }
        public string publicKey { get; set; }
        public string certificate { get; set; }
    }

    public class KeyClockRealmKeys
    {
        [JsonPropertyName("active")]
        public Active Active { get; set; }

        [JsonPropertyName("keys")]
        public List<Key> Keys { get; set; }
    }

    
    public class Access
    {
        public bool ManageGroupMembership { get; set; }
        public bool View { get; set; }
        public bool MapRoles { get; set; }
        public bool Impersonate { get; set; }
        public bool Manage { get; set; }
    }

    public class UpdateKeyClockUserModelAttributes
    {
        [JsonPropertyName("userId")]
        public List<string> UserId { get; set; }
    }

    public class UpdateKeyClockUserModel
    {
        private UpdateKeyClockUserModelAttributes attributes;

        [JsonPropertyName("id")]
        public string Id { get; set; }

        [JsonPropertyName("createdTimestamp")]
        public long CreatedTimestamp { get; set; }

        [JsonPropertyName("username")]
        public string Username { get; set; }

        [JsonPropertyName("enabled")]
        public bool Enabled { get; set; }

        [JsonPropertyName("totp")]
        public bool Totp { get; set; }

        [JsonPropertyName("emailVerified")]
        public bool EmailVerified { get; set; }

        [JsonPropertyName("firstName")]
        public string FirstName { get; set; }

        [JsonPropertyName("lastName")]
        public string LastName { get; set; }

        [JsonPropertyName("email")]
        public string Email { get; set; }

        [JsonPropertyName("attributes")]
        public UpdateKeyClockUserModelAttributes Attributes { get => attributes; set => attributes = value; }

        [JsonPropertyName("disableableCredentialTypes")]
        public List<object>? DisableableCredentialTypes { get; set; }

        [JsonPropertyName("requiredActions")]
        public List<object>? RequiredActions { get; set; }

        [JsonPropertyName("notBefore")]
        public int NotBefore { get; set; }

        [JsonPropertyName("access")]
        public Access? Access { get; set; }
    }

    public class KeyClockUpdateUserModel
    {
        [JsonPropertyName("username")]
        public string UserName { get; set; }

        [JsonPropertyName("email")]
        public string Email { get; set; }

        [JsonPropertyName("firstName")]
        public string FirstName { get; set; }

        [JsonPropertyName("lastName")]
        public string LastName { get; set; }

        [JsonPropertyName("emailVerified")]
        public bool EmailVerified { get; set; }

        [JsonPropertyName("enabled")]
        public bool Enabled { get; set; }

        [JsonPropertyName("requiredActions")]
        public List<string> RequiredActions { get; set; }
    }
}