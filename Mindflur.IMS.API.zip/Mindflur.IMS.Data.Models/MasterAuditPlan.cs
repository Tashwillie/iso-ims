﻿namespace Mindflur.IMS.Data.Models
{
    public partial class MasterAuditPlan
    {
        public int Id { get; set; }
        public int AuditprogramId { get; set; }
        public int MasterDataExternalCategoryId { get; set; }
        public int AuditLeaderId { get; set; }
        public DateTime From { get; set; }
        public DateTime To { get; set; }
        public string Title { get; set; } = null!;
        public string? Description { get; set; }
        public int AuditeeLeaderId { get; set; }
    }
}