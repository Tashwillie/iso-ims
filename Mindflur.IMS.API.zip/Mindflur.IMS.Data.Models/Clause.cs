﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mindflur.IMS.Data.Models
{
    public partial class Clause
    {
        public int ClauseId { get; set; }
        public int? StandardId { get; set; }
        public string? ClauseNumberText { get; set; }
        public string? DisplayText { get; set; }
        public int? ParentId { get; set; }
        public int? SequenceNumber { get; set; }
    }
}
