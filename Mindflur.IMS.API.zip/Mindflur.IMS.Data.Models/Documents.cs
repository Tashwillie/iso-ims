﻿namespace Mindflur.IMS.Data.Models
{
    public class Documents
    {
		public int DocumentId { get; set; }
		public int TenantId { get; set; }
		public string? DocumentNumber { get; set; }
		public string Title { get; set; }
		public string? Purpose { get; set; }
		public string? HtmlContent { get; set; }
		public int DocumentCategoryMasterDataId { get; set; }
		public int? DocumentPriorityMasterDataId { get; set; }
		public int DocumentStatusMasterDataId { get; set; }
		public int? ReviewFreqencyMasterDataId { get; set; }
		public DateTime? NextReviewDate { get; set; }
		public int? ApprovedBy { get; set; }
		public DateTime? ApprovedOn { get; set; }
		public bool? IsPublish { get; set; }
		public DateTime? PublishedOn { get; set; }
		public DateTime CreatedOn { get; set; }
		public int CreatedBy { get; set; }
		public DateTime? UpdatedOn { get; set; }
		public int? UpdatedBy { get; set; }
		public DateTime? DeletedOn { get; set; }
		public int? DeletedBy { get; set; }
	}
}