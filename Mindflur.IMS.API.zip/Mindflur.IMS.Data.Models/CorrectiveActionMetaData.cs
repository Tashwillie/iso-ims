﻿namespace Mindflur.IMS.Data.Models
{
    public class CorrectiveActionMetadata
    {
        public int Id { get; set; }
        public int? WorkItemId { get; set; }
      
        public string? WhyAnalysis1 { get; set; } = null!;
        public string? WhyAnalysis2 { get; set; } = null!;
        public string? WhyAnalysis3 { get; set; } = null!;
        public string? WhyAnalysis4 { get; set; } = null!;
        public string? WhyAnalysis5 { get; set; } = null!;
        public string? RootCauseAnalysis { get; set; } = null!;
      
        public int? RootCauseAppovedBy { get; set; }
        public DateTime? RootCauseAppovedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public bool? IsApproved { get; set; }

	}
}