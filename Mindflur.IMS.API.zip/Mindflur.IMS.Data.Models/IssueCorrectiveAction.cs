﻿using System.ComponentModel.DataAnnotations;

namespace Mindflur.IMS.Data.Models
{
    public partial class IssueCorrectiveAction
    {
        [Key]
        public int IssueId { get; set; }

        public int ModuleId { get; set; }
        public int ModuleItemId { get; set; }
        public int CorrectiveActionId { get; set; }
    }
}