﻿namespace Mindflur.IMS.Data.Models
{
    public partial class AuditChecklist
    {
        public int Id { get; set; }
        public int AuditProgramId { get; set; }
        public int ChecklistMasterId { get; set; }
        public bool? Compliance { get; set; }
        public int? MasterDataClassificationId { get; set; }
        public bool? Reviewed { get; set; }

        public string? Comments { get; set; }
    }
}