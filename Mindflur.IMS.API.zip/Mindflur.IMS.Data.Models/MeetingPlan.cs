﻿namespace Mindflur.IMS.Data.Models
{
    public partial class MeetingPlan
    {
        public int Id { get; set; }
        public int TenantId { get; set; }
        public string Title { get; set; } = null!;

        public string Location { get; set; } = null!;
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public bool? MeetingType { get; set; }
        public int? PreviousMeetingId { get; set; }
        public int? AuditProgramId { get; set; }
        public bool IsPublished { get; set; }
        public DateTime? ApprovedOn { get; set; }
        public int? ApprovedBy { get; set; }
        public DateTime? ActualStart { get; set; }
        public DateTime? ActualEnd { get; set; }
        public DateTime? PublishedOn { get; set; }
        public int? Status { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
    }
}