﻿namespace Mindflur.IMS.Data.Models
{
    public partial class UserPoints
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int ModuleId { get; set; }
        public int ModuleItemId { get; set; }
        public int Points { get; set; }
        public DateTime CreatedOn { get; set; }
        public string? Comments { get; set; }
    }
}