﻿namespace Mindflur.IMS.Data.Models
{
    public class ObservationMaster
    {
        public int Id { get; set; }
        public int TenantId { get; set; }
        public int? Source { get; set; }
        public int? SourceId { get; set; }
        public string? Description { get; set; }
        public string? Title { get; set; }
        public int CreatedBy { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }
    }
}