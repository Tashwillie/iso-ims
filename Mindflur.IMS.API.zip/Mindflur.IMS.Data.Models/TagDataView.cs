﻿namespace Mindflur.IMS.Data.Models
{
    public class TagDataView
    {
        public int TagId { get; set; }
        public string TagName { get; set; }
    }

    public class StandardDataView
    {
        public int? StandardId { get; set; }
        public string? StandardName { get; set; }
    }

    public class ClausesDataView
    {
        public int ClauseId { get; set; }
        public string ClauseNo { get; set; }
    }

    public class SupplierDataView
    {
        public int SupplierId { get; set; }
        public string SupplierName { get; set; }
    }

    public class CommentDataView
    {
        public int CommentId { get; set; }
        public string CommentContent { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? ParentCommentId { get; set; }
    }

    public class DocumentRoleDataView
    {
        public int DocumentRoleId { get; set;}
        public string DocumentRoleName { get; set;}
    }

    public class DocumentUserDataView
    {
        public int DocumentUserId { get; set; }
        public string DocumentUserName { get; set; }
    }
}