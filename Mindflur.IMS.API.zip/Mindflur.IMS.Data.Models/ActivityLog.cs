﻿namespace Mindflur.IMS.Data.Models
{
    public class ActivityLog
    {
        public int ActivityLogId { get; set; }
        public int? TenantId { get; set; }
        public int ControllerId { get; set; }
        public int ModuleAction { get; set; }
        public int EntityId { get; set; }
        public string Description { get; set; }
        public string Details { get; set; }
        public bool Status { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
    }
}