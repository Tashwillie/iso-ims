﻿using System.ComponentModel.DataAnnotations;

namespace Mindflur.IMS.Data.Models
{
    public partial class AuditItemClause
    {
        [Key]
        public int Id { get; set; }

        public int AuditableItemClauseId { get; set; }
        public int ClauseMasterId { get; set; }
    }
}