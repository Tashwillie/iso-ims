﻿namespace Mindflur.IMS.Data.Models
{
	public partial class ProjectMetaData
	{
		public int ProjectId { get; set; }
		public int? WorkItemId { get; set; }
		public DateTime StartDate { get; set; }
		public DateTime EndDate { get; set; }
		public decimal? Budget { get; set; }
		public DateTime? UpdatedOn { get; set; }
		public int? UpdatedBy { get; set; }
	}
}