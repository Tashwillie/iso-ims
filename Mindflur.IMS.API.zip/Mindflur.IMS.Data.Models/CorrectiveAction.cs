﻿namespace Mindflur.IMS.Data.Models
{
    public partial class CorrectiveAction
    {
        public int Id { get; set; }
        public int? ModuleId { get; set; }
        public int ModuleItemId { get; set; }
        public int TenantId { get; set; }
        public string? Title { get; set; }
        public string? Description { get; set; }
        public string RootCauseAnalysis { get; set; } = null!;
        public string WhyAnalysis1 { get; set; } = null!;
        public string WhyAnalysis2 { get; set; } = null!;
        public string WhyAnalysis3 { get; set; } = null!;
        public string WhyAnalysis4 { get; set; } = null!;
        public string WhyAnalysis5 { get; set; } = null!;
        public int ResponsiblePerson { get; set; }

        public DateTime DueDate { get; set; }
        public string ActionRequired { get; set; } = null!;
        public bool UploadRiskAssesment { get; set; }
        public bool ChangeInQMS { get; set; }
        public string ChangesInQMSDescription { get; set; } = null!;
        public string ActionToPrevent { get; set; } = null!;
        public int CarStatus { get; set; }
        public bool Escalation { get; set; }
        public string RiskAssessmentDescription { get; set; } = null!;
        public DateTime CreatedOn { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? ApprovedOn { get; set; }
        public int? ApprovedBy { get; set; }
    }
}