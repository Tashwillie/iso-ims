﻿namespace Mindflur.IMS.Data.Models
{
    public class ControllerMaster
    {
        public int ControllerId { get; set; }
        public string ControllerName { get; set; }
    }
}