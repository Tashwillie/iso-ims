﻿namespace Mindflur.IMS.Data.Models
{
    public class KCRoleToRoleMapping
    {
        public int KCRoleToRoleMappingId { get; set; }
        public int RoleId { get; set; }
        public int TenantId { get; set; }

        public Guid KCRoleId { get; set; }
    }
}