﻿namespace Mindflur.IMS.Data.Models
{
    public partial class SurveyMasterDatum
    {
        public int SurveyId { get; set; }
        public int TenantId { get; set; }
        public string Title { get; set; } = null!;
        public string? Description { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndTime { get; set; }
        public int MasterDataSurveyStatusId { get; set; }
        public DateTime CreatedOn { get; set; }
        public int CreatedBy { get; set; }
        public DateTime? UpdatedIon { get; set; }
        public int? UpdatedBy { get; set; }
        public string? OverAllComments { get; set; }
        public int? AssignedToUserId { get;set; }
		public int? ResponsiblePersonId { get; set; }

        public DateTime? ApprovedOn { get; set; }
        public int? ApprovedBy { get;set; }

	}
}