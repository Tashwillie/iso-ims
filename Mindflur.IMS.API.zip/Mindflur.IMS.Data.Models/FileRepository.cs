﻿namespace Mindflur.IMS.Data.Models
{
    public class FileRepository
    {
        public int FileRepositoryId { get; set; }
        public int TenantId { get; set; }
        public int SourceItemId { get; set; }
        public int SourceId { get; set; }
        public string BlobStorageFilePath { get; set; }
        public bool IsPrivate { get; set; }
        public string BlobFileName { get; set; }
        public string? Description { get; set; }
        public string FullName { get; set; }
        public DateTime CreatedOn { get; set; }
        public int CreatedBy { get; set; }
        public int? DeletedBy { get; set; }
        public DateTime? DeletedOn { get; set; }
    }
}