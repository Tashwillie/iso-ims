﻿using System.ComponentModel.DataAnnotations;

namespace Mindflur.IMS.Data.Models
{
    public partial class EmailNotification
    {
        [Key]
        public int Id { get; set; }

        public string ModuleName { get; set; } = null!;
        public bool Response { get; set; }
    }
}