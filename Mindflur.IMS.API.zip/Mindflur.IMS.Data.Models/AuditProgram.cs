﻿namespace Mindflur.IMS.Data.Models
{
    public partial class AuditProgram
    {
        public int Id { get; set; }
        public int TenantId { get; set; }
        public string Title { get; set; } = null!;
        public int MasterDataCategoryId { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime DueDate { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public bool IsPublish { get; set; }
        public DateTime? PublishedOn { get; set; }
        public int? ApprovedBy { get; set; }
        public DateTime? ApprovedOn { get; set; }
        public DateTime? ActualStart { get; set; }
        public DateTime? ActualEnd { get; set; }
        public int? Status { get; set; }
        public string? Scope { get; set; }
        public string? Objectives { get; set; }
    }
}