﻿namespace Mindflur.IMS.Data.Models
{
    public partial class NonConformityDBModel
    {
        public int Id { get; set; }
        public string Title { get; set; } = null!;
        public int Originator { get; set; }
        public int Department { get; set; }
        public DateTime Date { get; set; }
        public int NcTypes { get; set; }
        public int Category { get; set; }
        public int Status { get; set; }
        public string Description { get; set; } = null!;
        public string Evidence { get; set; } = null!;
        public string ReviewRecommendation { get; set; } = null!;
    }
}