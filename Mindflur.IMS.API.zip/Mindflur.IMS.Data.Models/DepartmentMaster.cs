﻿namespace Mindflur.IMS.Data.Models
{
    public class DepartmentMaster
    {
        public int DepartmentId { get; set; }
        public int TenantId { get; set; }
        public string DepartmentName { get; set; }
    }
}