﻿namespace Mindflur.IMS.Data.Models
{
    public class WorkItemMaster
    {
        public int WorkItemId { get; set; }
        public int SourceId { get; set; }
        public int SourceItemId { get; set; }
        public int TenantId { get; set; }
        public string Title { get; set; }
        public string? Description { get; set; }
        public int CategoryId { get; set; }

        public int? WorkItemTypeId { get; set; }
        public int? DepartmentId { get; set; }
        public int StatusMasterDataId { get; set; }
        public int? AssignedToUserId { get; set; }
        public int? ResponsibleUserId { get; set; }
        public DateTime? DueDate { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public int? ParentWorkItemId { get; set; }
    }
}

