﻿using System.ComponentModel.DataAnnotations;

namespace Mindflur.IMS.Data.Models
{
    public partial class MeetingRegister
    {
        [Key]
        public int Id { get; set; }

        public int AuditProgramId { get; set; }
        public int MeetingType { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
    }
}