﻿namespace Mindflur.IMS.Data.Models
{
    public partial class AuditChecklistFinding
    {
        public int Id { get; set; }
        public int AuditChecklistId { get; set; }
        public int AuditFindingId { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
    }
}