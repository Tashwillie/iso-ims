﻿namespace Mindflur.IMS.Data.Models
{
    public partial class MeetingParticipant
    {
        public int Id { get; set; }
        public int MeetingId { get; set; }
        public int DepartmentId { get; set; }
        public int UserId { get; set; }
        public string Participants { get; set; } = null!;
    }
}