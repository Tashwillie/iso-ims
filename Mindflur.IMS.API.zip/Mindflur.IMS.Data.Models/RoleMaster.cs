﻿using System.ComponentModel.DataAnnotations;

namespace Mindflur.IMS.Data.Models
{
    public partial class RoleMaster
    {
        [Key]
        public int RoleId { get; set; }

        public string RoleName { get; set; } = null!;
        public int GroupId { get; set; }

        public bool Active { get; set; }
    }
}