﻿namespace Mindflur.IMS.Data.Models
{
    public  class DocumentChangeRequestMaster
    {
       
        public int ChangeRequestId { get; set; }
        public int TenantId { get; set; }   
        public int DocumentId { get; set; }
        public int? ReferenceCode { get; set; }
        public string? Reason { get; set; }
        public string?   Description { get; set; }
        public string? Consequences { get; set; }
        public int? ChangeRequestStatusMasterDataId { get; set; }     
        public int ChangeRequestTypeMasterDataId { get; set; }
        public int? VersionTypeId { get; set; }
        public int? RequestedBy { get; set; }
        public DateTime? RequestedOn { get; set; }
        public int? ApprovedBy { get; set; }
        public DateTime? ApprovedOn { get; set; }
        public int? RejectedBy { get; set; }
        public DateTime? RejectedOn { get;set; }


    }
}
