﻿namespace Mindflur.IMS.Data.Models
{
    public partial class TaskMetaData
    {

        public int TaskId { get; set; }
        public int WorkItemId { get; set; }
        public int? EstimateEffortHours { get; set; }
        public bool? IsAcknowledge { get; set; }  
        public int? RemainingEffortHours { get; set; }
        public int? Reviewer{get;set;}
        public DateTime? StartDate{get;set;}
        public int? ApprovedBy { get; set; }
        public DateTime? ApprovedOn { get; set; }
    }
}