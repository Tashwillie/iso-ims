﻿namespace Mindflur.IMS.Data.Models
{
    public partial class CorrectiveActionTaskMasterMapping
    {
        public int Id { get; set; }
        public int CorrectiveActionId { get; set; }
        public int TaskId { get; set; }
    }
}