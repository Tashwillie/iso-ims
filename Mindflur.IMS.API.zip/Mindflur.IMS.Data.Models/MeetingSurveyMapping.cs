﻿namespace Mindflur.IMS.Data.Models
{
    public class MeetingSupplierMapping
    {
        public int? Id { get; set; }
        public int? TenantId { get; set; }
        public int? MeetingId { get; set; }
        public int? SupplierId { get; set; }
    }
}