﻿namespace Mindflur.IMS.Data.Models
{
    public class IncidentMasterClassificationTag

    {
        public int Id { get; set; }
        public int IncidentId { get; set; }
        public int IncidentClassificationTags { get; set; }
    }
}