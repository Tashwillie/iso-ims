﻿namespace Mindflur.IMS.Data.Models
{
	public class NonConformanceMetadata
	{
		public int Id { get; set; }
		public int? WorkItemId { get; set; }
		public DateTime? StartDate { get; set; }

		public bool? IsApproved { get; set; }
		public string? ImmediateAction { get; set; }
		public string? Documents { get; set; }
		public int? ApprovedBy { get; set; }
		public DateTime? ApprovedOn { get; set; }
		public int? ReviewedBy { get; set; }
		public DateTime? ReviewedOn { get; set; }
		public DateTime? UpdatedOn { get; set; }
		public int? UpdatedBy { get; set; }
		

	}
}