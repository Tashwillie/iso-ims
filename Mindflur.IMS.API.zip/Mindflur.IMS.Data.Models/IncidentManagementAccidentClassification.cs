﻿namespace Mindflur.IMS.Data.Models
{
	public class IncidentManagementAccidentClassification
    {
        public int Id { get; set; }
        public int IncidentId { get; set; }
        public bool? IsAccident { get; set; }
        public string? IsAccidentText { get; set; }
        public bool? IsInjury { get; set; }
        public string? IsInjuryText { get; set; }
        public bool? IsEnvironmentalIncident { get; set; }
        public string? IsEnvironmentalIncidentText { get; set; }
        public bool? IsEquipmentFailure { get; set; }
        public string? IsEquipmentFailureText { get; set; }
        public bool? IsFinancialIncident { get; set; }
        public string? IsFinancialIncidentText { get; set; }
        public bool? IsNaturalEventDisaster { get; set; }
        public string? IsNaturalEventDisasterText { get; set; }
        public bool? IsNonConformanceQuality { get; set; }
        public string? IsNonConformanceQualityText { get; set; }
        public bool? IsProductionInterruption { get; set; }
        public string? IsProductionInterruptionText { get; set; }
        public bool? IsWastage { get; set; }
        public string? IsWastageText { get; set; }
        public string? FirstaidInjury { get; set; }
        public string? LostTimeInjury { get; set; }
        public string? FatalInjury { get; set; }
        public string? ReportableInjury { get; set; }
        public string? MinorInjury { get; set; }
        public string? BriefDescription { get; set; }
    }
}