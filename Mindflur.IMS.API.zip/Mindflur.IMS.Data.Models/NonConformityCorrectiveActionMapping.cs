﻿namespace Mindflur.IMS.Data.Models
{
    public partial class NonConformityCorrectiveActionMapping
    {
        public int Id { get; set; }
        public int NonConformanceId { get; set; }
        public int CorrectiveActionId { get; set; }
    }
}