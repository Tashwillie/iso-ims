﻿namespace Mindflur.IMS.Data.Models
{
    public partial class OfferedAnswerMaster
    {
        public int SurveyOfferedAnswerId { get; set; }
        public string? Title { get; set; }
        public int? Weightage { get; set; }
    }
}