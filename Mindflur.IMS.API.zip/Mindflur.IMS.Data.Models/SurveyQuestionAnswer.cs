﻿namespace Mindflur.IMS.Data.Models
{
    public partial class SurveyQuestionAnswer
    {
        public int SurveyQuestionAnswerId { get; set; }
        public int SurveyQuestionId { get; set; }
        public int OfferedAnswerId { get; set; }
        public int SequenceId { get; set; }
    }
}