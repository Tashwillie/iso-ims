﻿namespace Mindflur.IMS.Data.Models
{
    public partial class ProjectTask
    {
        public int ProjectTaskId { get; set; }
        public int ProjectId { get; set; }
        public int TaskId { get; set; }
    }
}