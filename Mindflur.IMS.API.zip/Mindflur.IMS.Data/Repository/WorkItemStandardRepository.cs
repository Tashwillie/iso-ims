﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Mindflur.IMS.Application.Contracts.Repository;
using Mindflur.IMS.Application.ViewModel.View;
using Mindflur.IMS.Data.Base;
using Mindflur.IMS.Data.Models;
using SkiaSharp;

namespace Mindflur.IMS.Data.Repository
{
    public class WorkItemStandardRepository : BaseRepository<WorkItemStandard>, IWorkItemStandardRepository
    {
        public WorkItemStandardRepository(IMSDEVContext dbContext, ILogger<WorkItemStandard> logger) : base(dbContext, logger)
        {

        }
        public async Task<IList<StandardDataView>> GetWorkItemStandards(int WorkItemId)
        {
            return await (from standard in _context.WorkItemStandards
                          join clause in _context.Clauses on standard.StandardId equals clause.ClauseId
                          where standard.WorkItemId == WorkItemId
                          select new StandardDataView
                          {
                              StandardId = clause.ClauseId,
                              StandardName = clause.ClauseNumberText + " "+clause.DisplayText,


                          }).OrderByDescending(clause => clause.StandardId)
                          .ToListAsync();
        }

        public async Task<WorkItemStarndardsViewModel> GetWorkWorkItemStandardsISO(int WorkItemId)
        {
            var standrds = (from standard in _context.WorkItemStandards
                            join clause in _context.Clauses on standard.StandardId equals clause.ClauseId
                            join md in _context.MasterData on clause.StandardId equals md.Id
                            where standard.WorkItemId == WorkItemId
                            select new WorkItemStarndardsViewModel
                            {
                                StandardNameId = clause.StandardId,
                                StandardName = md.Items,
                            }).AsQueryable();
            return standrds.FirstOrDefault();
        }
    }
}
