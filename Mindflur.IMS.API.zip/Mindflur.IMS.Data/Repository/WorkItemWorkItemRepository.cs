﻿using Microsoft.Extensions.Logging;
using Mindflur.IMS.Application.Contracts.Repository;
using Mindflur.IMS.Data.Base;
using Mindflur.IMS.Data.Models;

namespace Mindflur.IMS.Data.Repository
{
	public class WorkItemWorkItemTokenRepository : BaseRepository<WorkItemWorkItemToken>, IWorkItemWorkItemTokenRepository
	{
		public WorkItemWorkItemTokenRepository(IMSDEVContext dbContext, ILogger<WorkItemWorkItemToken> logger) : base(dbContext, logger)
		{
		}
	}
}
